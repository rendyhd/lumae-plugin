import base64
import gzip
import importlib
import json
import os
import re
import socket
import time
from contextlib import contextmanager, nullcontext
from datetime import datetime, timezone
from html import escape

from flask import Blueprint, Response, g, jsonify, request, url_for

from plugin.api import config, get_db, get_setting, logger, render_page, set_setting, table
import plugin.api as host_api

from .loudness import (
    ProfileAnalysisTimeout,
    ProfileResourceLimitError,
    SilentAudioError,
    analyze_file,
)
from .edge_profiles import (
    analyze_edge_file, edge_runtime_available, edge_runtime_status, opaque_revision,
    METHOD as EDGE_METHOD, SCHEMA_VERSION as EDGE_SCHEMA_VERSION,
)
from .edge_profile_store import (
    migrate_edge_profiles, edge_join, claim_edge_jobs, update_edge_job, fail_edge_job,
    publish_edge_profile, edge_backfill_candidates, edge_profile_status,
    claim_edge_requests, record_edge_runtime, edge_worker_runtime, is_unsupported_failure,
    UNSUPPORTED as EDGE_UNSUPPORTED, mark_edge_jobs_waiting, claim_waiting_edge_jobs,
    edge_queue_counts, next_edge_backfill, update_edge_backfill, arm_edge_backfill,
    park_edge_backfill, edge_backfill_row, edge_statuses, EDGE_BACKFILL_RESWEEP_HOURS,
    ensure_edge_backfill_sources, rewind_edge_backfill, edge_runtime_reported_within,
    edge_payload_sql, edge_schema_v3_ready, upgrade_stored_edges,
    edge_due_among, complete_edge_pass_sql, pyav_reported,
)
from . import action_isolation
from . import analysis_bundle
from . import analysis_download
from . import analysis_isolation
from . import parallel_analysis
from . import migrations
from . import optional_storage
from . import credits_service, credits_store, personal_discovery, music_metadata
from .shelves import (
    SHELVES_SCHEMA_VERSION,
    migrate_shelves,
    purge_expired_shelf_mutations,
    register_shelf_routes,
)
from . import covers, journeys, vibes
from . import file_tags
from . import loudness_backfill, loudness_stream, loudness_v1
from . import runner
from . import shared_pass
from .core_compat import (
    SUPPORTED_CORE_RANGE,
    detect_core,
    get_core_adapter,
    sanitized_server_summaries,
)
from .catalog import (
    CATALOG_FINGERPRINT_SCHEMA_VERSION,
    attempt_legacy_rebind,
    CATALOG_BUILDER_VERSION,
    CatalogScanError,
    bootstrap_page,
    catalog_refresh_clock,
    create_bootstrap_session,
    ensure_catalog_sources,
    migrate_catalog,
    next_wanted_catalog_refresh,
    prune_catalog_storage,
    read_catalog_changes,
    refresh_catalog,
    release_bootstrap_session,
    resolve_catalog_source,
    satisfy_catalog_refresh_wants,
    source_matches_server_id,
    verify_library_scope,
    want_catalog_refresh,
)
from .catalog_analysis import (
    AnalysisProjectionDeferred,
    GenerationExpired,
    dedup_policy,
    project_analysis,
    read_analysis_changes,
    scalar_batch,
    vector_batch,
)
from .catalog_enrichment import (
    RELATIONSHIP_ALGORITHM_VERSION,
    RELATIONSHIP_SCHEMA_VERSION,
    RELATIONSHIP_SCORING_REVISION,
    claim_relationship_preparation,
    compact_enrichment_storage,
    externalize_journal_edges,
    migrate_enrichment,
    prepare_relationships,
    profile_bootstrap_page,
    read_profile_changes,
    read_relationship_changes,
    record_profile_change,
    relationship_bootstrap_page,
    relationship_status,
    serialize_profile,
)
from .catalog_readiness import CONTRACT_REVISION, v3_release_readiness
from . import status_model
from .catalog_providers import (
    ProviderCatalogBridge,
    SUPPORTED_PROVIDER_TYPES,
    provider_display_name,
)
from .database_state import (
    bounded_reads,
    collect_database_state,
    redact_source_errors,
    redact_stored_error,
    render_database_state,
    safe_snapshot_error,
)
from .settings_ui import SETTINGS_STATUS_SCRIPT
from .provider_identity_guard import (
    TRANSITION_BLOCKER,
    claim_identity_recheck,
    complete_projection_reconcile,
    migrate_provider_identity,
    observe_provider_version,
    projection_reconcile_required,
    provider_transition_health,
    require_projection_reconcile,
)
from .provider_identity_rekey import read_transition_manifest, refresh_audiomuse_health
from .profile_publication import (
    RETRY_ARMED_SQL,
    RETRY_LIMIT,
    admit_attempts,
    backfill_due_sql,
    complete_attempt,
    migrate_attempts,
    public_failure_reason,
    published_profile_current,
    release_attempts,
    retry_delay_sql,
    scheduler_params,
)
from . import profile_bootstrap
from .collection_manager import (
    COLLECTIONS_BACKUP_VERSION,
    COLLECTIONS_CONTRACT,
    COLLECTIONS_SCHEMA_VERSION,
    collections_enabled,
    health_scope_mode,
    migrate_collections,
    purge_expired_collection_mutations,
    purge_stale_collection_restores,
    register_collection_routes,
    render_collections_settings_panel,
)
from . import reconcile
from .reconcile import (
    RUNNER_CLAIM_MARKERS,
    RUNNER_WAITING_MARKER,
    WAITING_MARKERS,
    runner_claim_marker,
    TurnReport,
    analysis_projection_sentence,
    begin_event,
    catalog_refresh_sentence,
    collection_retention_sentence,
    defer_work,
    discard_event,
    finish_event,
    identity_recheck_sentence,
    iso as reconcile_iso,
    migrate_reconcile,
    ANALYSIS_QUEUES as RECONCILE_ANALYSIS_QUEUES,
    progress_event,
    queue_throughput as reconcile_queue_throughput,
    read_reconcile_status,
    recover_interrupted_events,
    record_event,
    task_message,
    update_work_retry,
    wake_runners,
)

SCHEMA_VERSION = 1
ANALYZER_VERSION = 1
PLUGIN_VERSION = "1.10.0"
CATALOG_SCHEMA_VERSION = 3
ANALYSIS_SCHEMA_VERSION = 2
CATALOG_FEATURES = (
    "dual_core_compat",
    "stable_catalog_instance",
    "provider_occurrences",
    "rich_metadata",
    "complete_generations",
    "bootstrap_leases",
    "cursor_changes",
    "refresh_on_demand",
    "library_scope",
    "album_ids",
    "artist_credits",
    "soft_deletions",
    "shared_analysis",
    "binary_vectors",
    "v3_release_readiness",
    "contract_admission_v1",
    "independent_stream_admission",
    "automatic_sonic_verification",
    "semantic_contracts_v1",
    "progressive_analysis_admission",
    "repair_flagged_analysis_admission",
    "database_state_dashboard",
    "provider_track_scope_verification",
    "source_scoped_profiles",
    "prepare_lumae",
    "catalog_prepare_api",
    "analysis_run_finalization",
    "catalog_ready_before_profile_backfill",
    "interactive_profile_priority",
    "bounded_profile_backfill",
    "automatic_catalog_preparation",
    "catalog_builder_versioning",
    "durable_catalog_reconciliation",
    "preparation_worker_attestation",
    "profile_cursor_stream",
    "server_album_artist_relationships",
    "relationship_cursor_stream",
    "nonblocking_enrichment",
    "provider_identity_transition_shield_v1",
    "provider_identity_rekey_v1",
    "bounded_storage_retention",
)
CATALOG_FEATURE_ROUTES = {
    "bootstrap_leases": (
        ("/api/catalog/bootstrap-sessions", "POST"),
        ("/api/catalog/bootstrap-sessions", "DELETE"),
        ("/api/catalog/bootstrap", "GET"),
    ),
    "cursor_changes": (("/api/catalog/changes", "GET"),),
    "refresh_on_demand": (("/api/catalog/refresh", "POST"),),
    "provider_track_scope_verification": (("/api/catalog/verify-scope", "POST"),),
    "source_scoped_profiles": (("/api/profiles", "GET"),),
    "shared_analysis": (
        ("/api/catalog/analysis/changes", "GET"),
        ("/api/catalog/analysis/scalars", "POST"),
        ("/api/catalog/analysis/vectors", "POST"),
    ),
    "catalog_prepare_api": (
        ("/api/catalog/prepare", "POST"),
        ("/api/catalog/prepare/<operation_id>", "GET"),
    ),
    "provider_identity_rekey_v1": (
        ("/api/catalog/provider-identity/manifest", "GET"),
    ),
}
CATALOG_REFRESH_TASK_TYPE = "plugin.lumae_analysis.catalog_refresh"
CATALOG_RECONCILE_TASK_TYPE = "plugin.lumae_analysis.catalog_reconcile"
PROVIDER_IDENTITY_RECHECK_TASK_TYPE = "plugin.lumae_analysis.provider_identity_recheck"
# W1 (runner plan 2026-10-25): the recheck is a runner action while a
# provider transition needs it, each source at most every
# IDENTITY_RECHECK_SPACING_SECONDS. Its half-hourly schedule put 48 root
# tasks a day on AudioMuse's queue with nothing pending.
IDENTITY_RECHECK_SPACING_SECONDS = 30 * 60
ANALYSIS_PROJECTION_TASK_TYPE = "plugin.lumae_analysis.analysis_projection"
COLLECTION_RETENTION_TASK_TYPE = "plugin.lumae_analysis.collection_retention"
DEFAULT_BACKFILL_BATCH_SIZE = 3
MAX_BACKFILL_BATCH_SIZE = 10
INTERACTIVE_PROFILE_CHUNK_SIZE = 3
MAX_INTERACTIVE_PROFILE_IDS = 12
PREPARATION_STALE_HOURS = 1
BACKFILL_STALE_MINUTES = 30
ANALYSIS_RUN_SETTLE_GRACE_MINUTES = 2
ANALYSIS_RUN_STALE_MINUTES = 30
PROFILE_JOB_TIMEOUT_SECONDS = 20 * 60
PROFILE_BACKFILL_JOB_TIMEOUT_SECONDS = 30 * 60
CATALOG_JOB_TIMEOUT_SECONDS = 90 * 60
RELATIONSHIP_JOB_TIMEOUT_SECONDS = 60 * 60
COLLECTIONS_MENU_LABEL = "Living Collections"
COLLECTIONS_MENU_ENDPOINT = "lumae_analysis.collection_manager_page"

bp = Blueprint("lumae_analysis", __name__)
register_collection_routes(bp)
register_shelf_routes(bp)
vibes.register_vibe_routes(bp)
journeys.register_journey_routes(bp)
covers.register_cover_routes(bp)
personal_discovery.register_routes(bp)
music_metadata.register_routes(bp)
credits_service.register_routes(bp)


GZIP_MIN_BYTES = 1024
GZIP_LEVEL = 4  # ~99% of level 6 ratio for ~80% of the CPU on edge pages


def _accepts_gzip(header):
    """True when ``Accept-Encoding`` allows gzip. ``q=0`` refuses it (RFC 9110 12.5.3)."""
    explicit = wildcard = None
    for item in str(header or "").split(","):
        name, _, params = item.partition(";")
        name = name.strip().lower()
        if not name:
            continue
        quality = 1.0
        for param in params.split(";"):
            key, _, value = param.partition("=")
            if key.strip().lower() == "q":
                try:
                    quality = float(value.strip())
                except ValueError:
                    quality = 0.0
        if name in ("gzip", "x-gzip"):
            explicit = quality if explicit is None else max(explicit, quality)
        elif name == "*":
            wildcard = quality
    chosen = explicit if explicit is not None else wildcard
    return chosen is not None and chosen > 0


@bp.after_request
def _compress_json_response(response):
    """K1: gzip plugin JSON of at least 1 KiB for clients that accept it.

    Blueprint-scoped, so host routes are never touched. Streamed and
    passthrough bodies, non-200 statuses and already-encoded bodies are left
    as they are.
    """
    if (response.status_code != 200
            or response.mimetype != "application/json"
            or response.direct_passthrough
            or response.is_streamed
            or "Content-Encoding" in response.headers):
        return response
    body = response.get_data()
    if len(body) < GZIP_MIN_BYTES:
        return response
    response.vary.add("Accept-Encoding")
    if not _accepts_gzip(request.headers.get("Accept-Encoding")):
        return response
    compressed = gzip.compress(body, compresslevel=GZIP_LEVEL, mtime=0)
    response.set_data(compressed)
    response.headers["Content-Encoding"] = "gzip"
    response.headers["Content-Length"] = str(len(compressed))
    return response


def sync_collections_menu(enabled, manager=None):
    """Apply the collection page's enabled state to the live Plugins menu."""
    if manager is None:
        try:
            from plugin.manager import plugin_manager as manager
        except (ImportError, AttributeError):
            return False
    record = getattr(manager, "records", {}).get("lumae_analysis")
    if record is None:
        return False
    items = [
        item
        for item in record.get("menu_items", [])
        if item.get("endpoint") != COLLECTIONS_MENU_ENDPOINT
    ]
    if enabled:
        items.append(
            {
                "label": COLLECTIONS_MENU_LABEL,
                "endpoint": COLLECTIONS_MENU_ENDPOINT,
                "admin_only": False,
            }
        )
    record["menu_items"] = items
    return True


class MediaDownloadError(Exception):
    pass


def profiles_table():
    return table("profiles")


def source_profiles_table():
    return table("source_profiles")


def preparation_state_table():
    return table("preparation_state")


def profile_backfill_state_table():
    return table("profile_backfill_state")


def analysis_runs_table():
    return table("analysis_runs")


def utc_now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def media_signature(path):
    try:
        stat = os.stat(path)
    except OSError:
        return None
    return f"{path}|{stat.st_size}|{int(stat.st_mtime)}"


def media_server_download_available():
    fields_by_type = getattr(config, "MEDIASERVER_FIELDS_BY_TYPE", {})
    media_type = str(getattr(config, "MEDIASERVER_TYPE", "") or "").lower()
    required_fields = fields_by_type.get(media_type)
    if not required_fields:
        return False
    return all(str(getattr(config, field, "") or "").strip() for field in required_fields)


def media_server_item(item_id, file_path=None, title=None, author=None):
    track_id = str(item_id)
    path = str(file_path or "")
    name = str(title or track_id)
    item = {
        "id": track_id,
        "Id": track_id,
        "title": name,
        "Name": name,
        "path": path,
        "Path": path,
        "FilePath": path,
    }
    if author:
        item["artist"] = str(author)
        item["AlbumArtist"] = str(author)
    suffix = os.path.splitext(path)[1].lstrip(".")
    if suffix:
        item["suffix"] = suffix
    return item


def download_track_to_temp(item):
    from tasks.mediaserver import download_track

    return download_track(_host_download_directory(), item)


def remove_downloaded_file(path):
    if not path:
        return
    try:
        os.remove(path)
    except OSError:
        logger.warning("lumae_analysis could not remove temporary analysis file %s", path)


def configured_backfill_limit():
    raw = get_setting("backfill_batch_size", DEFAULT_BACKFILL_BATCH_SIZE)
    return normalize_backfill_limit(raw)


def analysis_time_limit_seconds():
    """Per-file time limit (setting ``analysis_time_limit_seconds``).

    It is the analyzers' soft deadline; the analysis child is killed 30 s
    after it (``analysis_isolation.HARD_LIMIT_HEADROOM_SECONDS``).
    """
    return analysis_isolation.normalize_limit(
        get_setting("analysis_time_limit_seconds", analysis_isolation.DEFAULT_LIMIT_SECONDS)
    )


def run_file_analysis(analyzer, path, limit_seconds=None, **kwargs):
    """Run one file analysis in a child process under the hard limit (LUM-018).

    Nothing else puts a time limit on one file, and the
    analyzer's soft deadline cannot interrupt a decoder hung in native code.
    The setting is the analyzer's soft deadline, passed with each file, and
    the child is killed 30 s after it, so a progressing analysis stops at the
    soft deadline first. Failures raise with a LUM-007 category. A parallel
    analysis thread (WP1b) passes ``limit_seconds``, read on the turn's own
    thread: it reads no setting itself.
    """
    if limit_seconds is None:
        limit_seconds = analysis_time_limit_seconds()
    return analysis_isolation.run_isolated(analyzer, path, limit_seconds=limit_seconds, **kwargs)


def configured_background_workers():
    """The setting ``background_workers``: ``auto`` or 1-8 (performance plan WP1b)."""
    return parallel_analysis.normalize_setting(
        get_setting("background_workers", parallel_analysis.DEFAULT_SETTING))


def save_background_workers(form):
    """Store the settings form's ``background_workers`` when it sent one."""
    raw = form.get("background_workers")
    if raw is not None:
        set_setting("background_workers", parallel_analysis.normalize_setting(raw))


def background_sizing():
    """``(K, reason)``: K, the parallel analysis threads of a runner turn
    (setting ``background_workers``; ``auto`` sized from this process's cores
    and memory), and the setting behind it for the turn's log line. One when
    it cannot be read."""
    try:
        setting = configured_background_workers()
        workers = parallel_analysis.resolve_workers(setting)
        reason = f"setting {setting}"
        if runner.ROLE.get() == runner.ROLE_SERVER and setting == parallel_analysis.DEFAULT_SETTING:
            # R5: AudioMuse's web process serves requests from the same machine.
            workers = min(workers, WEB_AUTO_WORKERS)
            reason += f", at most {WEB_AUTO_WORKERS} in AudioMuse's web process"
        return workers, reason
    except Exception:
        logger.warning("lumae_analysis could not size the parallel analysis; analysing one file at a time")
        return 1, "the setting could not be read"


def background_workers():
    """K, the parallel analysis threads of a runner turn (``background_sizing``)."""
    return background_sizing()[0]


def background_batch_limit():
    """Waveform tracks a background batch claims: the admin batch size, or with
    K analysis threads (WP1b) K times MAX_BACKFILL_BATCH_SIZE, so a batch
    keeps every thread busy for several files before it drains."""
    pool = parallel_analysis.current()
    if pool is not None and pool.parallel:
        return max(configured_backfill_limit(), pool.workers * MAX_BACKFILL_BATCH_SIZE)
    return configured_backfill_limit()


def analysis_failure_code(track_id, exc, context="failed"):
    """The LUM-007 category of an analysis failure; logs it.

    A child's failure is logged with its safe diagnostics only. An in-process
    exception is logged as before (its text can name a temporary file).
    """
    code = analysis_isolation.failure_category(exc)
    if code == "silent_audio":
        return code
    if isinstance(exc, analysis_isolation.IsolatedAnalysisError):
        logger.warning(
            "lumae_analysis analysis %s for %s: %s %s",
            context, track_id, exc, exc.diagnostics or {},
        )
    elif code in ("analysis_timeout", "resource_limit"):
        logger.warning("lumae_analysis bounded profile rejection for %s: %s", track_id, exc)
    else:
        logger.exception("lumae_analysis %s for %s", context, track_id)
    return code


def maintenance_paused():
    value = get_setting("maintenance_paused", False)
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on")
    return bool(value)


def normalize_backfill_limit(raw):
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return DEFAULT_BACKFILL_BATCH_SIZE
    return min(max(value, 1), MAX_BACKFILL_BATCH_SIZE)


def format_count(value):
    return f"{int(value):,}"


def track_count_label(value):
    count = int(value)
    suffix = "track" if count == 1 else "tracks"
    return f"{format_count(count)} {suffix}"


# Runner plan R8: Lumae's rows under AudioMuse's Scheduled Tasks, all gone
# with the runners (a downgrade's install recreates its own).
LUMAE_CRON_PREFIX = "plugin.lumae_analysis."
# The name the host gives work an older version queued through
# ``plugin.api.enqueue`` (a phone refresh, an on-demand request, a preparation).
LUMAE_API_TASK_PREFIX = "plugin.audiomuse_plugins.lumae_analysis."
# An administrator's enabled catalogue refresh or analysis projection
# schedule (both shipped off, every six hours) carries over as this cadence.
CATALOG_REFRESH_HOURS_DEFAULT = 6
CADENCE_SETTINGS = (
    (CATALOG_REFRESH_TASK_TYPE, "catalog_refresh_hours"),
    (ANALYSIS_PROJECTION_TASK_TYPE, "analysis_projection_hours"),
)


def retire_lumae_schedules(db):
    """Delete Lumae's cron rows and their pending retries (R8). An enabled
    catalogue refresh or analysis projection row becomes the setting
    ``catalog_refresh_hours`` or ``analysis_projection_hours``, so the server
    runner keeps doing it on its own; an administrator's setting stands."""
    cur = db.cursor()
    for task_type, setting in CADENCE_SETTINGS:
        cur.execute("SELECT enabled FROM cron WHERE task_type=%s", (task_type,))
        row = cur.fetchone()
        if row and row[0] and get_setting(setting, None) in (None, ""):
            set_setting(setting, CATALOG_REFRESH_HOURS_DEFAULT)
    cur.execute("DELETE FROM cron WHERE task_type LIKE %s", (LUMAE_CRON_PREFIX + "%",))
    cur.execute("SELECT to_regclass('cron_retry') IS NOT NULL")
    exists = cur.fetchone()
    if exists and exists[0]:
        cur.execute("DELETE FROM cron_retry WHERE task_type LIKE %s", (LUMAE_CRON_PREFIX + "%",))
    cur.close()


def revoke_stranded_tasks(db):
    """R8: a Lumae root task an older version queued, and no worker started,
    blocks every AudioMuse start (its gate counts a queued plugin task as
    live) until a worker comes: a cron tick, or work queued through the
    plugin API, each under its own name. Lumae queues nothing now, so it is
    revoked: a worker no longer picks it up, and on a host that keeps the job
    elsewhere its shim only wakes the runners. Only ``NEW`` root rows: a
    running task finishes. The caller commits; returns how many."""
    cur = db.cursor()
    try:
        cur.execute("SELECT to_regclass('task_status') IS NOT NULL")
        exists = cur.fetchone()
        if not (exists and exists[0]):
            return 0
        cur.execute(
            "UPDATE task_status SET status='REVOKED' "
            "WHERE parent_task_id IS NULL AND status='NEW' "
            "AND (task_type LIKE %s OR task_type LIKE %s)",
            (LUMAE_CRON_PREFIX + "%", LUMAE_API_TASK_PREFIX + "%"),
        )
        return max(0, cur.rowcount or 0)
    finally:
        cur.close()


def _revoke_stranded_tasks_on_start():
    db = None
    try:
        db = get_db()
        revoked = revoke_stranded_tasks(db)
        db.commit()
        if revoked:
            logger.warning("lumae_analysis revoked %d task(s) an older version left on "
                           "AudioMuse's queue", revoked)
    except Exception:
        if db is not None:
            _rollback_if_possible(db)
        logger.warning("lumae_analysis could not look for tasks an older version left queued")


def _cadence_hours(setting):
    """A cadence setting in hours (0: off, the default; at most 30 days)."""
    try:
        value = float(get_setting(setting, 0) or 0)
    except (TypeError, ValueError):
        return 0.0
    return value if 0 < value <= 24 * 30 else 0.0


def catalog_refresh_hours():
    """``catalog_refresh_hours``: refresh each catalogue this often on the
    runner's own (0: only when asked, the default)."""
    return _cadence_hours("catalog_refresh_hours")


def analysis_projection_hours():
    """``analysis_projection_hours``: project AudioMuse's analysis this often
    on the server runner's own, besides after every analysis run and
    catalogue change (0: the default)."""
    return _cadence_hours("analysis_projection_hours")


def scheduled_projection_task(db):
    """R8: the projection cadence, once per period across the runners: each
    active source's server, bound as the schedule's task was."""
    hours = analysis_projection_hours()
    if not hours or runner.ROLE.get() is None:
        return None
    with db.cursor() as cur:
        claimed = runner.claim_mark(cur, "analysis_projection", hours * 3600)
        if claimed:
            cur.execute(f"SELECT DISTINCT current_core_server_id FROM {table('catalog_sources')} "
                        "WHERE rebind_status='active' AND current_core_server_id IS NOT NULL "
                        "ORDER BY 1")
            servers = [row[0] for row in cur.fetchall()]
    db.commit()
    if not claimed:
        return None
    return _call_action(project_servers_task, None, servers)


def project_servers_task(servers):
    """The projection of each server in ``servers``, bound as the schedule's
    task was."""
    statuses = {}
    for server_id in servers:
        with _source_binding(server_id):
            result = analysis_projection_task(server_id) or {}
        statuses[server_id] = str(result.get("status") or "complete")
    return {"status": "complete", "projected": len(servers), "servers": statuses}


def want_scheduled_catalog_refreshes(db):
    """Keep a refresh request for each catalogue older than
    ``catalog_refresh_hours`` (R8: the schedule's replacement)."""
    hours = catalog_refresh_hours()
    if not hours:
        return 0
    cur = db.cursor()
    cur.execute(
        f"""
        UPDATE {table('catalog_state')} c SET refresh_wanted_at=now(), updated_at=now()
          FROM {table('catalog_sources')} s
         WHERE s.catalog_instance_id=c.catalog_instance_id AND s.rebind_status='active'
           AND c.refresh_wanted_at IS NULL AND c.status='complete'
           AND c.completed_at < now() - make_interval(secs => %s)
        RETURNING c.catalog_instance_id
        """,
        (int(hours * 3600),),
    )
    count = len(cur.fetchall())
    cur.close()
    db.commit()
    return count


def _resolve_task_server_id(adapter, server_id):
    requested = str(server_id or adapter.active_server_id() or "")
    if adapter.mode != "v3_registry" or requested != "legacy-default":
        return requested or None
    if any(
        str(server.get("server_id") or "") == requested
        for server in adapter.list_servers()
    ):
        return requested
    try:
        aliases = [
            source
            for source in resolve_catalog_source(get_db())
            if source.get("rebind_status") == "active"
            and source.get("continuity_from") == requested
        ]
    except Exception:
        aliases = []
    if len(aliases) == 1:
        return aliases[0]["server_id"]
    logger.warning(
        "lumae_analysis skipped stale v2 task for legacy-default while v3 source rebind is pending"
    )
    return None


def wake_profile_backfill_after_catalog_refresh(result, db=None):
    """Keep one exact-source repair wake even if a batch is finishing."""
    source = result["catalog_instance_id"]
    server_id = result["server_id"]
    db = db or get_db()
    force_now = bool(result.get("changes") or
                     result.get("change_reason") == "fingerprint_schema_rebase")
    with db.cursor() as cur:
        cur.execute(
            f"""UPDATE {profile_backfill_state_table()}
                   SET refresh_wake_pending=CASE WHEN %s THEN TRUE
                                                 ELSE refresh_wake_pending END,
                       next_retry_at=CASE WHEN %s AND status='queued' THEN NULL
                                          ELSE next_retry_at END,
                       updated_at=now()
                 WHERE catalog_instance_id=%s AND status IN ('queued', 'running')
                 RETURNING catalog_instance_id""",
            (force_now, force_now, source),
        )
        active = cur.fetchone() is not None
    if active:
        wake_runners(db, "catalog_profile_repair")
        db.commit()
        return True
    db.commit()
    return start_profile_backfill(
        catalog_instance_id=source, server_id=server_id,
    )


def catalog_refresh_task(server_id=None):
    if maintenance_paused():
        return task_message({"status": "paused", "reason": "maintenance_paused"},
                            "Lumae: paused")
    adapter = get_core_adapter()
    resolved_server_id = _resolve_task_server_id(adapter, server_id)
    if not resolved_server_id:
        return task_message({"status": "skipped", "reason": "source_rebind_required"},
                            "Lumae: catalogue refresh skipped; the source awaits rebinding")
    started = _safe_catalog_refresh_clock()
    result = refresh_catalog(server_id=resolved_server_id)
    _satisfy_catalog_refresh_wants(result.get("catalog_instance_id"), started)
    changed = bool(result.get("changes") or
                   result.get("change_reason") == "fingerprint_schema_rebase")
    try:
        source = result["catalog_instance_id"]
        if (changed or
                find_backfill_ids(1, catalog_instance_id=source,
                                  server_id=result["server_id"]) or
                next_profile_retry_at(source)):
            wake_profile_backfill_after_catalog_refresh(result)
        if changed and arm_edge_backfill(get_db(), source):
            wake_runners(get_db(), "edge_backfill_ready", commit=True)
        if changed:
            # LN.4c: new tracks to measure, and loudness records to follow the catalogue.
            loudness_backfill.ensure_sources(get_db())
            loudness_backfill.arm(get_db(), source)
            wake_runners(get_db(), "loudness_backfill_ready", commit=True)
    except Exception:
        _rollback_if_possible(get_db())
        logger.exception("Could not arm source profile repair after catalogue publication")
    if changed:
        # SQ.1: a new song goes out with the analysis AudioMuse already has;
        # without this an app read it with none until an analysis run's
        # finalization or another trigger projected.
        result["analysis"] = _project_after_catalog_refresh(resolved_server_id)
    try:
        db = get_db()
        optional_storage.prune(db)
        db.commit()
    except Exception:
        _rollback_if_possible(get_db())
        logger.exception("Optional measurement retention will retry on the next catalogue refresh")
    # The publication may have withdrawn profiles; /settings/status reads
    # these counts (P2-1).
    refresh_status_snapshot(get_db(), result.get("catalog_instance_id"))
    return task_message(result, catalog_refresh_sentence(result))


def _safe_catalog_refresh_clock():
    try:
        return catalog_refresh_clock(get_db())
    except Exception:
        _rollback_if_possible(get_db())
        logger.debug("lumae_analysis could not read the database clock", exc_info=True)
        return None


def _satisfy_catalog_refresh_wants(catalog_instance_id, started):
    """A finished scan serves every refresh request kept before it started."""
    if not catalog_instance_id:
        return
    try:
        satisfy_catalog_refresh_wants(get_db(), catalog_instance_id, started)
    except Exception:
        _rollback_if_possible(get_db())
        logger.exception("lumae_analysis could not clear the kept catalogue refresh request")


def _project_after_catalog_refresh(server_id):
    """Project AudioMuse's analysis after a catalogue change (SQ.1). This task
    already owns a root slot, so the projection runs inline; it admits the
    relationship work itself."""
    try:
        projection = analysis_projection_task(server_id)
    except Exception as exc:
        _rollback_if_possible(get_db())
        logger.exception(
            "lumae_analysis could not project analysis after the catalogue refresh; "
            "the next analysis run or projection does"
        )
        return {"status": "failed", "error": str(exc)}
    projection = projection or {}
    return {
        "status": projection.get("status") or "projected",
        **{key: projection[key]
           for key in ("reason", "generation", "changes", "ready_count", "unchanged")
           if key in projection},
    }


def wanted_catalog_refresh_task(server_id, catalog_instance_id):
    """A refresh an app asked for, run by the server runner (SQ.1, R6); ``{"status": "failed"}`` when the scan raised. A finished
    scan serves the request (``catalog_refresh_task``). A failed one marks the
    catalogue for repair itself (``refresh_required``), and the repair
    retries, so the request is not kept for another try either."""
    started = _safe_catalog_refresh_clock()
    try:
        result = catalog_refresh_task(server_id)
    except Exception as exc:
        _rollback_if_possible(get_db())
        logger.exception("lumae_analysis could not run the requested catalogue refresh")
        _satisfy_catalog_refresh_wants(catalog_instance_id, started)
        return {"status": "failed", "catalog_instance_id": catalog_instance_id,
                "error": str(exc)[:500]}
    status = str((result or {}).get("status") or "")
    if status in ("paused", "skipped"):
        return result
    return {**(result or {}), "status": "complete"}


def next_settled_analysis_run(db=None, server_id=None):
    """Return one durable run whose AudioMuse parent can no longer emit hooks."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT r.server_id, r.catalog_instance_id, r.run_id, r.retry_count
          FROM {analysis_runs_table()} r
          LEFT JOIN task_status parent
            ON parent.task_id=r.run_id AND parent.task_type='main_analysis'
         WHERE (r.status IN ('pending', 'registering', 'queued',
                             'enqueue_failed', 'failed')
                OR (r.status='running' AND r.updated_at
                    < now() - interval '{ANALYSIS_RUN_STALE_MINUTES} minutes'))
           AND (r.next_retry_at IS NULL OR r.next_retry_at <= now())
           AND (%s IS NULL OR r.server_id=%s)
           AND (
                parent.status IN ('SUCCESS', 'FAILURE', 'FAIL', 'REVOKED')
                OR (
                    parent.task_id IS NULL
                    AND r.last_seen_at
                        < now() - interval '{ANALYSIS_RUN_SETTLE_GRACE_MINUTES} minutes'
                    AND NOT EXISTS (
                        SELECT 1 FROM task_status live
                         WHERE live.parent_task_id IS NULL
                           AND live.task_type='main_analysis'
                           AND live.status IN (
                               'NEW', 'QUEUED', 'PENDING', 'STARTED',
                               'RUNNING', 'PROGRESS'
                           )
                    )
                )
           )
         ORDER BY r.last_seen_at, r.catalog_instance_id, r.run_id
         LIMIT 1
        """,
        (server_id, server_id),
    )
    row = cur.fetchone()
    cur.close()
    if row is None:
        return None
    return {
        "server_id": str(row[0]),
        "catalog_instance_id": str(row[1]),
        "run_id": str(row[2]),
        "retry_count": int(row[3] or 0) if len(row) > 3 else 0,
    }


def next_preparation_run(db=None, server_id=None):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT server_id, catalog_instance_id, retry_count
          FROM {preparation_state_table()}
         WHERE (status='queued'
            OR (status='failed' AND (next_retry_at IS NULL OR next_retry_at <= now()))
            OR (status='running' AND updated_at
                < now() - interval '{PREPARATION_STALE_HOURS} hours'))
           AND (%s IS NULL OR server_id=%s)
         ORDER BY updated_at, catalog_instance_id
         LIMIT 1
        """,
        (server_id, server_id),
    )
    row = cur.fetchone()
    cur.close()
    return (str(row[0]), str(row[1]), int(row[2] or 0)) if row else None


def next_relationship_run(db=None, server_id=None):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT s.current_core_server_id, r.catalog_instance_id, r.retry_count
          FROM {table('relationship_state')} r
          JOIN {table('catalog_sources')} s USING (catalog_instance_id)
         WHERE s.rebind_status='active'
           AND ((r.status='queued'
                 AND (r.next_retry_at IS NULL OR r.next_retry_at <= now()))
                OR (r.status IN ('failed', 'waiting_for_index')
                    AND (r.next_retry_at IS NULL OR r.next_retry_at <= now()))
                OR (r.status='running' AND r.updated_at
                    < now() - interval '2 minutes'))
           AND (%s IS NULL OR s.current_core_server_id=%s)
         ORDER BY r.updated_at, r.catalog_instance_id
         LIMIT 1
        """,
        (server_id, server_id),
    )
    row = cur.fetchone()
    cur.close()
    return (str(row[0]), str(row[1]), int(row[2] or 0)) if row else None


def next_profile_backfill_run(db=None, server_id=None):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT server_id, catalog_instance_id, retry_count
          FROM {profile_backfill_state_table()}
         WHERE ((status='queued' AND (next_retry_at IS NULL OR next_retry_at <= now()))
            OR (status='failed' AND (next_retry_at IS NULL OR next_retry_at <= now()))
            OR (status='running' AND updated_at
                < now() - interval '{BACKFILL_STALE_MINUTES} minutes'))
           AND (%s IS NULL OR server_id=%s)
         ORDER BY updated_at, catalog_instance_id
         LIMIT 1
        """,
        (server_id, server_id),
    )
    row = cur.fetchone()
    cur.close()
    return (str(row[0]), str(row[1]), int(row[2] or 0)) if row else None


def _rollback_if_possible(db):
    rollback = getattr(db, "rollback", None)
    if callable(rollback):
        rollback()


def _safe_progress(phase, current=None, total=None):
    try:
        progress_event(phase, current=current, total=total)
    except Exception:
        db = get_db()
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not update reconcile progress")


def _reconcile_result_summary(result):
    if not isinstance(result, dict):
        return {"status": str(result)[:200]}
    allowed = (
        "status",
        "songs_seen",
        "processed",
        "attempted",
        "ready",
        "failed",
        "skipped",
        "deferred",
        "already_ready",
        "promoted",
        "queued_next",
        "queued_profiles",
        "generation",
        "changes",
        "album_count",
        "artist_count",
        "track_count",
        "served",
        "match_status",
        "credits",
        "retry_seconds",
        "upgraded",
        "flagged",
    )
    return {key: result[key] for key in allowed if key in result}


def _source_binding(server_id):
    """The AudioMuse server binding a queued task had (R3): a runner thread
    starts without one, and an unbound host call uses the default server. In
    a runner turn only; elsewhere the caller's binding stands."""
    if not server_id or runner.ROLE.get() is None:
        return nullcontext()
    bind = getattr(get_core_adapter(), "bind", None)
    if not callable(bind):
        return nullcontext()
    try:
        return bind(server_id)
    except Exception:
        logger.warning("lumae_analysis runs %s's work without its server binding", server_id)
        return nullcontext()


# R5: the catalogue actions, which load whole catalogues, run in a child
# process in a runner turn (action_isolation); everything else in the runner's
# thread. Names of this module's functions; child_action runs no other.
ISOLATED_ACTIONS = frozenset((
    "wanted_catalog_refresh_task", "prepare_lumae_task", "finalize_analysis_run_task",
    "project_servers_task", "provider_identity_recheck_task", "relationship_preparation_task",
))
# A child that cannot start is logged at most this often.
CHILD_UNAVAILABLE_LOG_SECONDS = 15 * 60
_child_unavailable_logged_at = None


def _call_action(function, server_id, *args):
    """``function(*args)`` bound to ``server_id``'s server (R3). In a runner
    turn under AudioMuse a catalogue action (``ISOLATED_ACTIONS``) runs in a
    child process (R5): in AudioMuse's web process it held the interpreter for
    seconds and kept up to 3 GB after (RN.8). A child that cannot start leaves
    the action to this thread; one that died or ran too long fails it."""
    role = runner.ROLE.get()
    name = getattr(function, "__name__", "")
    if role is not None and name in ISOLATED_ACTIONS and action_isolation.available():
        call = {"name": name, "args": list(args), "role": role, "server_id": server_id,
                "event_id": reconcile._current_event_id.get()}
        try:
            return action_isolation.run("child_action", call)
        except action_isolation.ChildRaised as exc:
            if exc.type_name == "AnalysisProjectionDeferred":
                raise AnalysisProjectionDeferred(exc.message, exc.reason) from None
            raise
        except action_isolation.ChildUnavailable as exc:
            _note_child_unavailable(name, exc)
    with _source_binding(server_id):
        return function(*args)


def _note_child_unavailable(name, exc):
    global _child_unavailable_logged_at
    now = time.monotonic()
    if (_child_unavailable_logged_at is not None
            and now - _child_unavailable_logged_at < CHILD_UNAVAILABLE_LOG_SECONDS):
        return
    _child_unavailable_logged_at = now
    logger.warning("lumae_analysis runs %s in the runner's thread: no child process (%s)",
                   name, exc)


def child_action(name, args, role, server_id=None, event_id=None):
    """A catalogue action in its child process (``_call_action``): the
    parent's runner role, journal event and server binding, then
    ``name(*args)``."""
    if name not in ISOLATED_ACTIONS:
        raise ValueError(f"{name} does not run in a child process")
    function = globals()[name]
    role_token = runner.ROLE.set(role)
    event_token = reconcile._current_event_id.set(event_id)
    try:
        with _source_binding(server_id):
            return function(*args)
    finally:
        reconcile._current_event_id.reset(event_token)
        runner.ROLE.reset(role_token)


def _run_reconcile_action(
    db,
    action,
    server_id,
    catalog_instance_id,
    work_key,
    retry_count,
    function,
    *args,
):
    event_id = None
    try:
        event_id = begin_event(
            db,
            action,
            server_id,
            catalog_instance_id,
            work_key=work_key,
            attempt=int(retry_count or 0) + 1,
        )
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not start the reconcile status event")
    try:
        _safe_progress("starting")
        result = _call_action(function, server_id, *args)
        result_status = str((result or {}).get("status") or "complete")
        if result_status in ("coalesced", "already_finalized", "paused"):
            try:
                discard_event(db, event_id)
            except Exception:
                _rollback_if_possible(db)
            return result
        if result_status == "waiting_for_index":
            next_retry_at = None
            try:
                next_retry_at = defer_work(
                    db,
                    action,
                    catalog_instance_id,
                    work_key=work_key,
                    minutes=60,
                )
                finish_event(
                    db,
                    event_id,
                    "deferred",
                    phase="waiting for AudioMuse index",
                    summary=_reconcile_result_summary(result),
                    next_retry_at=next_retry_at,
                )
            except Exception:
                _rollback_if_possible(db)
                logger.exception("lumae_analysis could not record deferred reconcile work")
            return result
        if action == "relationships" and result_status == "queued":
            # A committed checkpoint is continuation work, not a failed build
            # or a published generation. Keep minute cadence without backoff.
            update_work_retry(db, action, catalog_instance_id, failed=False)
            finish_event(db, event_id, "deferred", phase="relationship build checkpointed",
                         summary=_reconcile_result_summary(result))
            return result
        if result_status in ("failed", "failure", "error"):
            raise RuntimeError(str((result or {}).get("error") or result_status))
        if action in ("edge_backfill", "loudness_backfill"):
            # The pass keeps its own next_retry_at (the re-sweep after a
            # finished pass); resetting it here would make it due at once.
            finish_event(db, event_id, "success", phase=result_status,
                         summary=_reconcile_result_summary(result))
            return result
        # Track failures do not mean the batch itself crashed. Keep its normal
        # retry lifecycle, but persist a warning verdict for the journal.
        has_track_failures = (
            action == "profile_backfill" and int((result or {}).get("failed") or 0) > 0
        )
        try:
            update_work_retry(
                db,
                action,
                catalog_instance_id,
                work_key=work_key,
                failed=False,
                # A finished backfill stored its soonest track retry (or
                # none); clearing it made the row due at once and held
                # minute cadence after the backfill (AUD-15).
                keep_next_retry=(
                    (action == "profile_backfill"
                     and result_status in ("waiting_retry", "complete"))
                    # W2: a published generation stores when the next build
                    # of newer inputs may start.
                    or action == "relationships"
                ),
            )
            finish_event(
                db,
                event_id,
                "success",
                phase="completed with warnings" if has_track_failures else "complete",
                summary=_reconcile_result_summary(result),
            )
        except Exception:
            _rollback_if_possible(db)
            logger.exception("lumae_analysis could not finish reconcile success state")
        return result
    except Exception as exc:
        _rollback_if_possible(db)
        retry = {"next_retry_at": None}
        try:
            retry = update_work_retry(
                db,
                action,
                catalog_instance_id,
                work_key=work_key,
                failed=True,
            )
        except Exception:
            _rollback_if_possible(db)
            logger.exception("lumae_analysis could not record reconcile retry state")
        try:
            finish_event(
                db,
                event_id,
                "failed",
                phase="failed",
                error=exc,
                next_retry_at=retry.get("next_retry_at"),
            )
        except Exception:
            _rollback_if_possible(db)
            logger.exception("lumae_analysis could not finish the reconcile status event")
        raise


def _safe_edge_v3_upgrade(db, budget_seconds=None):
    """One bounded batch of the stored-edge v3 upgrade (SF.3) while any edge
    lacks its v3 digest: ``(upgraded, flagged)``, or None when there is nothing
    to do or it failed (logged; the next turn tries again). It works for
    ``budget_seconds``, EDGE_V3_UPGRADE_BUDGET_SECONDS by default."""
    try:
        if edge_schema_v3_ready(db):
            return None
        if budget_seconds is None:
            budget_seconds = EDGE_V3_UPGRADE_BUDGET_SECONDS
        upgraded, flagged = upgrade_stored_edges(db, budget_seconds=budget_seconds)
        return (upgraded, flagged) if upgraded else None
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis stored edge v3 upgrade unavailable")
        return None


def _safe_want_scheduled_catalog_refreshes(db):
    try:
        return want_scheduled_catalog_refreshes(db)
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not schedule a catalogue refresh")
        return 0


def _safe_claim_collection_retention(db):
    """Whether today's retention is this runner's to run (R8); False on error
    and outside a runner."""
    if runner.ROLE.get() is None:
        return False
    try:
        with db.cursor() as cur:
            claimed = runner.claim_mark(cur, "collection_retention", COLLECTION_RETENTION_SECONDS)
        db.commit()
        return claimed
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not check the collection retention")
        return False


def _safe_claim_identity_recheck(db, server_id):
    """W1: the server whose identity recheck is due, taken; None on any error."""
    try:
        server = claim_identity_recheck(db, IDENTITY_RECHECK_SPACING_SECONDS, server_id)
        db.commit()
        return server
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not check for a provider identity recheck")
        return None


def _safe_credits_reconcile(db, server_id, before_background, deadline=None):
    try:
        return credits_service.reconcile(db, server_id, before_background=before_background,
                                         deadline=deadline)
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis credits reconciliation unavailable")
        return None


def _safe_metadata_reconcile(db, before_background, deadline=None):
    try:
        return music_metadata.reconcile(db, before_background=before_background,
                                        deadline=deadline)
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis MusicBrainz lookups unavailable")
        return None


def _safe_next_wanted_catalog_refresh(db, server_id):
    try:
        return next_wanted_catalog_refresh(db, server_id=server_id)
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not read the kept catalogue refresh request")
        return None


def _elapsed_ms(started):
    return int((time.monotonic() - started) * 1000)


def _record_turn(db, report, action, server_id, catalog_instance_id, result, started):
    """Report and journal a credits, MusicBrainz or on-demand turn (AUD-18)."""
    duration_ms = _elapsed_ms(started)
    report.add(action, result, duration_ms)
    status = str((result or {}).get("status") or "complete")
    event_status = (
        "failed" if status in ("failed", "failure", "error")
        else "deferred" if status == "deferred" else "success"
    )
    try:
        record_event(db, action, server_id, catalog_instance_id, event_status,
                     phase=status, duration_ms=duration_ms,
                     summary=_reconcile_result_summary(result))
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not record the reconcile event")


def _reconcile_step(db, report, action, *args):
    started = time.monotonic()
    try:
        result = _run_reconcile_action(db, action, *args)
    except Exception:
        report.add(action, {"status": "failed"}, _elapsed_ms(started))
        raise
    report.add(action, result, _elapsed_ms(started))
    return result


def catalog_reconcile_task():
    """1.8.0's watchdog tick, for a job queued before the upgrade: the runners
    do its work now (R8), so it wakes them and returns. Kept one release."""
    db = get_db()
    try:
        wake_runners(db, "queued_tick", commit=True)
    except Exception:
        _rollback_if_possible(db)
    return {"status": "runner", "plugin_version": PLUGIN_VERSION,
            "catalog_builder_version": CATALOG_BUILDER_VERSION}


# A result in one of these says the action has nothing more to do now: it is
# not run again in the same turn.
_SETTLED_STATUSES = frozenset((
    "current", "coalesced", "paused", "deferred", "failed", "failure", "error",
    "waiting_retry", "waiting_for_index", "already_finalized", "superseded",
))
# Actions whose "complete" ends their work for now (an analysis run's
# "complete" is one run of several).
_COMPLETE_SETTLES = frozenset(("catalog_preparation", "relationships", "profile_backfill",
                               "edge_backfill", "loudness_backfill"))
# Results that moved nothing on. A turn of only these sleeps until the soonest
# retry instead of turning again at once: with MusicBrainz unreachable, credits
# deferred one album, the next turn took the next album, every 2 s, forever.
_NO_PROGRESS_STATUSES = _SETTLED_STATUSES - {"superseded"}


def _moved_on(status, result):
    """Whether an action's result moved its work on: a status that does not
    say otherwise, or tracks done on the way (a batch that analysed songs and
    then waits for a retry)."""
    if status not in _NO_PROGRESS_STATUSES:
        return True
    counts = result if isinstance(result, dict) else {}
    for key in ("processed", "ready", "served", "upgraded"):
        try:
            if int(counts.get(key) or 0) > 0:
                return True
        except (TypeError, ValueError):
            continue
    return False


# Actions whose work changes the waveform counts the settings page shows.
_PROFILE_STATE_ACTIONS = frozenset((
    "interactive", "analysis_run", "catalog_preparation", "profile_backfill",
))
STATUS_SNAPSHOT_IDLE_SECONDS = 300


def _changed_profile_state(report):
    return any(entry["action"] in _PROFILE_STATE_ACTIONS for entry in report.actions)


def _next_reconcile_action(db, report, budget, server_id, done, shared=False, slots=None):
    """Run the first due action the budget fits; ``(action, result)`` or
    ``(None, None)`` when none ran. ``done`` collects actions with nothing
    more to do this turn. ``shared`` (multi-worker plan R4): the per-track
    passes are walked with the helpers. ``slots`` (R6): a shared leader's
    ``_LeaderSlots``, held while a per-track pass runs and only then."""

    def due(action):
        return action not in done and budget.fits(action)

    if due("interactive"):
        start = time.monotonic()
        served = serve_interactive()
        if served:
            budget.start()
            result = {"status": "served", "served": served}
            _record_turn(db, report, "interactive", server_id, None, result, start)
            return "interactive", result
        done.add("interactive")
    # SF.3: stored edges still without a v3 digest, one bounded batch a turn.
    if due("edge_schema_v3"):
        done.add("edge_schema_v3")
        start = time.monotonic()
        upgrade = _safe_edge_v3_upgrade(
            db, min(EDGE_V3_UPGRADE_BUDGET_SECONDS, budget.remaining()))
        if upgrade:
            budget.start()
            result = {"status": "processed", "upgraded": upgrade[0], "flagged": upgrade[1]}
            _record_turn(db, report, "edge_schema_v3", None, None, result, start)
            return "edge_schema_v3", result
    if due("analysis_run"):
        run = next_settled_analysis_run(db=db, server_id=server_id)
        if run:
            budget.start()
            return "analysis_run", _reconcile_step(
                db, report, "analysis_run", run["server_id"], run["catalog_instance_id"],
                run["run_id"], run.get("retry_count", 0), finalize_analysis_run_task,
                run["server_id"], run["catalog_instance_id"], run["run_id"],
            )
        done.add("analysis_run")
    if due("catalog_preparation"):
        preparation = next_preparation_run(db=db, server_id=server_id)
        if preparation:
            budget.start()
            return "catalog_preparation", _reconcile_step(
                db, report, "catalog_preparation", preparation[0], preparation[1],
                preparation[1], preparation[2] if len(preparation) > 2 else 0,
                prepare_lumae_task, *preparation[:2],
            )
        done.add("catalog_preparation")
    # SQ.1: a catalogue refresh an app asked for (R6), or one the refresh
    # cadence wants. One a turn; a refresh task on the queue serves it instead.
    if due("catalog_refresh"):
        done.add("catalog_refresh")
        _safe_want_scheduled_catalog_refreshes(db)
        wanted = _safe_next_wanted_catalog_refresh(db, server_id)
        if wanted:
            budget.start()
            start = time.monotonic()
            result = _call_action(wanted_catalog_refresh_task, None, *wanted)
            _record_turn(db, report, "catalog_refresh", wanted[0], wanted[1], result, start)
            return "catalog_refresh", result
    # R8: expired collection receipts, once a day.
    if due("collection_retention"):
        done.add("collection_retention")
        if _safe_claim_collection_retention(db):
            budget.start()
            start = time.monotonic()
            result = collection_retention_task()
            _record_turn(db, report, "collection_retention", None, None, result, start)
            return "collection_retention", result
    # R8: the projection cadence an administrator kept.
    if due("analysis_projection"):
        done.add("analysis_projection")
        start = time.monotonic()
        try:
            result = scheduled_projection_task(db)
        except Exception as exc:
            _rollback_if_possible(db)
            logger.warning("lumae_analysis scheduled projection failed", exc_info=True)
            result = {"status": "failed", "error": str(exc)}
        if result is not None:
            budget.start()
            _record_turn(db, report, "analysis_projection", None, None, result, start)
            return "analysis_projection", result
    # W1: the provider identity recheck, while a transition needs it.
    if due("identity_recheck"):
        done.add("identity_recheck")
        recheck_server = _safe_claim_identity_recheck(db, server_id)
        if recheck_server:
            budget.start()
            start = time.monotonic()
            result = _call_action(provider_identity_recheck_task, None, recheck_server)
            _record_turn(db, report, "identity_recheck", recheck_server, None, result, start)
            return "identity_recheck", result
    # A share-gated turn each, checked once a turn: the check sweeps.
    for action, call in (("credits", _safe_credits_reconcile),
                         ("music_metadata", _safe_metadata_reconcile)):
        slot = f"{action}:before_background"
        if slot in done or action in done or not budget.fits(action):
            continue
        done.add(slot)
        start = time.monotonic()
        result = (call(db, server_id, before_background=True, deadline=budget.deadline)
                  if action == "credits"
                  else call(db, before_background=True, deadline=budget.deadline))
        if result:
            budget.start()
            _record_turn(db, report, action, server_id,
                         result.get("catalog_instance_id"), result, start)
            return action, result
    if due("relationships"):
        relationship = next_relationship_run(db=db, server_id=server_id)
        if relationship:
            budget.start()
            return "relationships", _reconcile_step(
                db, report, "relationships", relationship[0], relationship[1],
                relationship[1], relationship[2] if len(relationship) > 2 else 0,
                relationship_preparation_task, *relationship[:2], budget.remaining(),
            )
        done.add("relationships")
    if due("profile_backfill"):
        profile = next_profile_backfill_run(db=db, server_id=server_id)
        if profile:
            with _pass_slots(slots, done) as free:
                if free:
                    budget.start()
                    return "profile_backfill", _reconcile_step(
                        db, report, "profile_backfill", profile[0], profile[1], profile[1],
                        profile[2] if len(profile) > 2 else 0, profile_backfill_task, *profile[:2],
                        budget.deadline, *((True,) if shared else ()),
                    )
        done.add("profile_backfill")
    # Multi-worker plan R4: only a shared turn passes ``shared`` on, so a
    # one-runner turn calls the passes exactly as 1.9 did.
    sharing = {"shared": True} if shared else {}
    if due("edge_backfill"):
        # R5: a shared pass is offered to a leader without a runtime too: it
        # parks the pass when no runner can make edges.
        edge = (next_edge_backfill(db, server_id=server_id, **sharing)
                if edge_profiles_enabled() or shared else None)
        if edge:
            with _pass_slots(slots, done) as free:
                if free:
                    budget.start()
                    return "edge_backfill", _reconcile_step(
                        db, report, "edge_backfill", edge[0], edge[1], edge[1], 0,
                        edge_backfill_task, edge[0], edge[1], budget.deadline,
                        *((True,) if shared else ()),
                    )
        done.add("edge_backfill")
    # LN.4c: last of the track work, so it measures only when nothing else waits.
    if due("loudness_backfill"):
        loudness = next_loudness_backfill(db, server_id=server_id, **sharing)
        if loudness:
            with _pass_slots(slots, done) as free:
                if free:
                    budget.start()
                    return "loudness_backfill", _reconcile_step(
                        db, report, "loudness_backfill", loudness[0], loudness[1], loudness[1], 0,
                        loudness_backfill_task, loudness[0], loudness[1], budget.deadline,
                        *((True,) if shared else ()),
                    )
        done.add("loudness_backfill")
    for action, call in (("credits", _safe_credits_reconcile),
                         ("music_metadata", _safe_metadata_reconcile)):
        if not due(action):
            continue
        start = time.monotonic()
        result = (call(db, server_id, before_background=False, deadline=budget.deadline)
                  if action == "credits"
                  else call(db, before_background=False, deadline=budget.deadline))
        if result:
            budget.start()
            _record_turn(db, report, action, server_id,
                         result.get("catalog_instance_id"), result, start)
            return action, result
        done.add(action)
    return None, None


def analysis_projection_task(server_id=None):
    if maintenance_paused():
        return task_message({"status": "paused", "reason": "maintenance_paused"},
                            "Lumae: paused")
    adapter = get_core_adapter()
    resolved_server_id = _resolve_task_server_id(adapter, server_id)
    if not resolved_server_id:
        return task_message({"status": "skipped", "reason": "source_rebind_required"},
                            "Lumae: analysis projection skipped; the source awaits rebinding")
    try:
        result = project_analysis(server_id=resolved_server_id, adapter=adapter)
    except AnalysisProjectionDeferred as exc:
        # Held back by design, and a retry seconds later cannot change that:
        # the published projection stays, and the next trigger (this
        # schedule, an analysis run, catalogue preparation or the identity
        # recheck) projects. Raising made AudioMuse retry twice and mark the
        # task FAIL (1.5.0 and earlier).
        _rollback_if_possible(get_db())
        # A server Lumae does not mirror (not Navidrome or Jellyfin) is skipped on every
        # all-servers run; its task row says so, which is enough.
        if exc.reason != "catalog_source_missing":
            logger.warning(
                "lumae_analysis deferred the analysis projection for %s (%s): %s",
                resolved_server_id,
                exc.reason,
                exc,
            )
        return task_message({
            "status": "deferred",
            "reason": exc.reason,
            "server_id": resolved_server_id,
        }, f"Lumae: analysis projection deferred: {exc}")
    if not result.get("catalog_instance_id"):
        return result
    complete_projection_reconcile(get_db(), result["catalog_instance_id"])
    try:
        result["relationships"] = start_relationship_preparation(
            catalog_instance_id=result["catalog_instance_id"],
            server_id=resolved_server_id,
        )
    except Exception as exc:
        logger.exception(
            "lumae_analysis could not request album and artist relationship preparation"
        )
        result["relationships"] = {
            "queued": False,
            "coalesced": False,
            "error": str(exc),
        }
    return task_message(result, analysis_projection_sentence(result))


def enqueue_required_catalog_preparations(db=None, server_id=None):
    """Durably request first-run and builder-upgrade preparation.

    The historical name remains API-compatible. No queue operation occurs;
    the server runner executes admitted work on its next pass.
    """
    if maintenance_paused():
        return 0
    db = db or get_db()
    try:
        sources = resolve_catalog_source(db)
    except Exception:
        logger.exception(
            "lumae_analysis could not discover catalogues requiring post-install preparation"
        )
        return 0
    requested = 0
    for source in sources:
        if server_id is not None and str(source.get("server_id") or "") != str(server_id):
            continue
        catalog = source.get("catalog") or {}
        if source.get("rebind_status") != "active":
            continue
        state = preparation_state(source["catalog_instance_id"], db=db)
        requires_publication = (
            int(catalog.get("generation") or 0) <= 0
            or bool(catalog.get("refresh_required", False))
            or not preparation_attestation_is_current(state)
        )
        if not requires_publication:
            continue
        try:
            if not claim_preparation(source, db=db):
                continue
            requested += 1
        except Exception:
            logger.exception(
                "lumae_analysis could not record required catalogue preparation"
            )
    return requested


def provider_identity_recheck_task(server_id=None):
    """Advance pending ID proofs and hand completed AudioMuse migrations off."""

    db = get_db()
    bridge = ProviderCatalogBridge()
    adapter = get_core_adapter()
    candidates = [
        server
        for server in bridge.list_servers()
        if server.get("supported") and (not server_id or server["server_id"] == server_id)
    ]
    results = []
    for server in candidates:
        sources = resolve_catalog_source(db, server_id=server["server_id"])
        transition = (
            provider_transition_health(db, sources[0]["catalog_instance_id"])
            if len(sources) == 1
            else None
        )
        if not transition:
            continue
        if transition.get("state") == "transition_pending":
            results.append(refresh_catalog(server_id=server["server_id"], db=db, bridge=bridge))
            continue
        if transition.get("state") != "applied":
            continue
        previous_health = transition.get("audiomuse_health")
        reconcile_required = projection_reconcile_required(
            db, sources[0]["catalog_instance_id"]
        )
        if previous_health == "ready" and not reconcile_required:
            continue
        result = {
            "catalog_instance_id": sources[0]["catalog_instance_id"],
            "server_id": server["server_id"],
            "previous_health": previous_health,
            "reconcile_required": reconcile_required,
            "projection_queued": False,
            "projection_processed": False,
        }
        try:
            health = previous_health
            if health != "ready":
                health = refresh_audiomuse_health(
                    db,
                    sources[0]["catalog_instance_id"],
                    server["server_id"],
                    adapter,
                    commit=False,
                )
            result["audiomuse_health"] = health
            if health == "ready":
                # Persist the transition-health verdict before projection does
                # its own transactional publication. This task already owns a
                # root worker slot, so it must not enqueue another root task.
                db.commit()
                projection = analysis_projection_task(server["server_id"])
                result["projection"] = projection
                # A projection that did not run (deferred: e.g. the provider
                # stopped answering since the health check) leaves the durable
                # reconcile request set, so the next recheck projects again.
                result["projection_processed"] = (projection or {}).get("status") not in (
                    "deferred",
                    "paused",
                    "skipped",
                )
            else:
                db.commit()
        except Exception as exc:
            rollback = getattr(db, "rollback", None)
            if callable(rollback):
                rollback()
            logger.exception(
                "lumae_analysis could not reconcile AudioMuse provider migration for %s",
                server["server_id"],
            )
            result["error"] = str(exc)
        results.append(result)
    summary = {"checked": len(results), "results": results}
    return task_message(summary, identity_recheck_sentence(summary))


def collection_retention_task():
    """Delete idempotency receipts and stale restore progress past their
    retention window, in bounded batches (F2, docs/plan P3-4 item 6:
    collections growth). The server runner runs it once a day (R8); see
    collection_manager and shelves for the retention windows, batch limits
    and lock order."""
    if maintenance_paused():
        return task_message({"status": "paused", "reason": "maintenance_paused"},
                            "Lumae: paused")
    db = get_db()
    try:
        mutations_deleted = purge_expired_collection_mutations(db)
        restores_deleted = purge_stale_collection_restores(db)
        shelf_deleted = purge_expired_shelf_mutations(db)
        vibe_deleted = vibes.purge_expired_vibe_mutations(db)
        journey_deleted = journeys.purge_expired_journey_mutations(db)
        cover_deleted = covers.purge_expired_cover_mutations(db)
        cover_images_deleted = covers.purge_unused_cover_images(db)
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis collection retention cleanup failed")
        return task_message({"status": "error"}, collection_retention_sentence({"status": "error"}))
    result = {
        "status": "ok",
        "collection_mutations_deleted": mutations_deleted,
        "collection_restores_deleted": restores_deleted,
        "shelf_mutations_deleted": shelf_deleted,
        "vibe_mutations_deleted": vibe_deleted,
        "journey_mutations_deleted": journey_deleted,
        "cover_mutations_deleted": cover_deleted,
        "cover_images_deleted": cover_images_deleted,
    }
    return task_message(result, collection_retention_sentence(result))


def observe_provider_identities_on_start():
    """Bounded, best-effort observation that never delays Flask startup indefinitely."""

    db = get_db()
    if db is None:
        return
    try:
        # AudioMuse records a plugin update even when an install hook fails. In
        # that case PostgreSQL rolls the hook transaction back while the new
        # plugin code remains active. Re-running this additive migration here
        # repairs the provider-identity tables before any startup read needs
        # them, including upgrades from releases that predate the transition
        # shield.
        migrate_provider_identity(db)
        db.commit()
    except Exception:
        rollback = getattr(db, "rollback", None)
        if callable(rollback):
            rollback()
        logger.exception("lumae_analysis could not ensure provider identity schema")
        return
    try:
        migrate_reconcile(db)
        db.commit()
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not ensure reconcile schema")
    try:
        # The P2-1 status summary, repaired the same way. Only generations
        # without a summary are counted, so this is normally a few lookups.
        cur = db.cursor()
        try:
            status_model.migrate_status_summary(cur)
            db.commit()
            status_model.backfill_publication_summaries(cur, commit=db.commit)
        finally:
            cur.close()
        db.commit()
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not ensure the status summary")
    try:
        log_integrity_on_start(db)
    except Exception:
        logger.exception("lumae_analysis could not check upgrade integrity")
    bridge = ProviderCatalogBridge()
    for server in bridge.list_servers():
        if not server.get("supported"):
            continue
        try:
            observe_provider_version(db, bridge, server["server_id"], commit=True)
        except Exception:
            rollback = getattr(db, "rollback", None)
            if callable(rollback):
                rollback()
            logger.exception(
                "lumae_analysis could not observe provider identity for %s",
                server["server_id"],
            )
    enqueue_required_catalog_preparations(db=db)
    # The runners' identity recheck consumes durable transition state.
    # Startup never creates root work.


def _drop_dj_tables(db):
    with db.cursor() as cur:
        for name in (
            "dj_worker_capability",
            "dj_analyses",
            "dj_analysis_jobs",
            "dj_analyses_v3",
            "dj_analysis_jobs_v3",
            "dj_control",
        ):
            cur.execute(f"DROP TABLE IF EXISTS {table(name)} CASCADE")
        # Match only the retired registrations; LIKE treats underscores as wildcards.
        # Let failures abort the migration transaction instead of hiding them.
        cur.execute(
            "DELETE FROM cron WHERE task_type IN (%s, %s)",
            ("plugin.lumae_analysis.dj_analysis", "plugin.lumae_analysis.dj_reconcile"),
        )


def migrate(db):
    cur = db.cursor()
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {profiles_table()} (
            track_id TEXT PRIMARY KEY,
            sample_rate INTEGER NOT NULL,
            duration_ms INTEGER NOT NULL,
            ref_lufs REAL NOT NULL,
            start_ramp BYTEA NOT NULL,
            end_ramp BYTEA NOT NULL,
            analyzer_ver INTEGER NOT NULL,
            profile_schema_ver INTEGER NOT NULL,
            media_signature TEXT,
            analyzed_at TIMESTAMP NOT NULL DEFAULT now(),
            status TEXT NOT NULL,
            last_error TEXT
        )
        """
    )
    cur.close()
    migrate_catalog(db)
    ensure_catalog_sources(db)
    migrate_provider_identity(db)
    require_projection_reconcile(db)
    cur = db.cursor()
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {source_profiles_table()} (
            catalog_instance_id TEXT NOT NULL REFERENCES {table('catalog_sources')}(catalog_instance_id)
                ON DELETE CASCADE,
            track_id TEXT NOT NULL,
            sample_rate INTEGER NOT NULL,
            duration_ms INTEGER NOT NULL,
            ref_lufs REAL NOT NULL,
            start_ramp BYTEA NOT NULL,
            end_ramp BYTEA NOT NULL,
            analyzer_ver INTEGER NOT NULL,
            profile_schema_ver INTEGER NOT NULL,
            media_signature TEXT,
            analyzed_at TIMESTAMP NOT NULL DEFAULT now(),
            status TEXT NOT NULL,
            last_error TEXT,
            PRIMARY KEY (catalog_instance_id, track_id)
        )
        """
    )
    migrations.ensure_index(
        cur,
        f"CREATE INDEX IF NOT EXISTS {table('source_profiles_status_idx')} "
        f"ON {source_profiles_table()} (catalog_instance_id, status)",
    )
    migrate_attempts(cur)
    # On-demand attempts waiting for a runner (R6); 1.8.0's index named only
    # the refused ones.
    migrations.ensure_index(
        cur,
        f"CREATE INDEX IF NOT EXISTS {source_profiles_table()}_waiting_idx "
        f"ON {source_profiles_table()} (analyzed_at) "
        f"WHERE status='pending_interactive' "
        f"AND last_error IN ('{WAITING_MARKERS[0]}', '{WAITING_MARKERS[1]}')",
    )
    migrations.ensure_no_index(cur, source_profiles_table(),
                               f"{source_profiles_table()}_deferred_idx")
    migrate_edge_profiles(db)
    _drop_dj_tables(db)
    optional_storage.migrate(db)
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {table('profile_migrations')} (
            name TEXT PRIMARY KEY,
            completed_at TIMESTAMP NOT NULL DEFAULT now()
        )
        """
    )
    # Releases before 0.8 could only analyze the default provider. Preserve
    # those expensive waveform results only when exactly one active source
    # makes their ownership unambiguous. Record the one-shot attempt even on a
    # multi-source install so a later default-provider change cannot misassign
    # legacy rows.
    cur.execute(
        f"""
        WITH migration AS (
            INSERT INTO {table('profile_migrations')} (name)
            VALUES ('legacy_default_profiles_v1')
            ON CONFLICT (name) DO NOTHING
            RETURNING name
        ), active_sources AS (
            SELECT catalog_instance_id
              FROM {table('catalog_sources')}
             WHERE rebind_status='active' AND provider_type='navidrome'
        ), default_source AS (
            SELECT catalog_instance_id
              FROM active_sources
             WHERE (SELECT COUNT(*) FROM active_sources)=1
        )
        INSERT INTO {source_profiles_table()}
            (catalog_instance_id, track_id, sample_rate, duration_ms, ref_lufs,
             start_ramp, end_ramp, analyzer_ver, profile_schema_ver,
             media_signature, analyzed_at, status, last_error)
        SELECT d.catalog_instance_id, p.track_id, p.sample_rate, p.duration_ms,
               p.ref_lufs, p.start_ramp, p.end_ramp, p.analyzer_ver,
               p.profile_schema_ver, p.media_signature, p.analyzed_at,
               p.status, p.last_error
          FROM migration CROSS JOIN default_source d CROSS JOIN {profiles_table()} p
        ON CONFLICT (catalog_instance_id, track_id) DO NOTHING
        """
    )
    # P3-6 (LUM-007): before 1.3.0 a stale transition kept the category of an
    # earlier failure, and the scheduler selects a stale row only without one
    # (or a released one after its cooldown), so such rows were never retried.
    # Stale transitions now clear it; clear it once on the rows left behind
    # with attempts left, keeping retry_count (an exhausted row stays so). The marker is read first, so a re-run takes no
    # lock on source_profiles.
    cur.execute(
        f"SELECT 1 FROM {table('profile_migrations')} WHERE name='stale_retry_category_v1'"
    )
    if cur.fetchone() is None:
        cur.execute(
            f"""
            WITH migration AS (
                INSERT INTO {table('profile_migrations')} (name)
                VALUES ('stale_retry_category_v1')
                ON CONFLICT (name) DO NOTHING
                RETURNING name
            )
            UPDATE {source_profiles_table()} p
               SET retry_category=NULL, failure_diagnostics=NULL
              FROM migration
             WHERE p.status='stale' AND p.retry_category IS NOT NULL
               AND p.retry_category <> 'queue_unavailable'
               AND p.retry_count < %s
            """,
            (RETRY_LIMIT,),
        )
    # Published validity is independent of the current analysis attempt. This
    # additive table is seeded once; runtime routing is introduced separately.
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {table('published_source_profiles')} (
            catalog_instance_id TEXT NOT NULL REFERENCES {table('catalog_sources')}(catalog_instance_id)
                ON DELETE CASCADE,
            track_id TEXT NOT NULL,
            sample_rate INTEGER NOT NULL,
            duration_ms INTEGER NOT NULL,
            ref_lufs REAL NOT NULL,
            start_ramp BYTEA NOT NULL,
            end_ramp BYTEA NOT NULL,
            analyzer_ver INTEGER NOT NULL,
            profile_schema_ver INTEGER NOT NULL,
            media_signature TEXT,
            analyzed_at TIMESTAMP NOT NULL,
            PRIMARY KEY (catalog_instance_id, track_id)
        )
        """
    )
    # Use a distinct durable marker, even when there are no ready rows.
    # The marker and copy share one SQL statement and the migration transaction:
    # a later default-source change or deleted publication cannot trigger a copy.
    cur.execute(
        f"""
        WITH migration AS (
            INSERT INTO {table('profile_migrations')} (name)
            VALUES ('published_source_profiles_seed_v1')
            ON CONFLICT (name) DO NOTHING
            RETURNING name
        )
        INSERT INTO {table('published_source_profiles')}
            (catalog_instance_id, track_id, sample_rate, duration_ms, ref_lufs,
             start_ramp, end_ramp, analyzer_ver, profile_schema_ver,
             media_signature, analyzed_at)
        SELECT p.catalog_instance_id, p.track_id, p.sample_rate, p.duration_ms,
               p.ref_lufs, p.start_ramp, p.end_ramp, p.analyzer_ver,
               p.profile_schema_ver, p.media_signature, p.analyzed_at
          FROM migration CROSS JOIN {source_profiles_table()} p
         WHERE p.status='ready'
        ON CONFLICT (catalog_instance_id, track_id) DO NOTHING
        """
    )
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {preparation_state_table()} (
            catalog_instance_id TEXT PRIMARY KEY REFERENCES {table('catalog_sources')}(catalog_instance_id)
                ON DELETE CASCADE,
            server_id TEXT NOT NULL,
            status TEXT NOT NULL,
            phase TEXT NOT NULL,
            queued_profiles INTEGER NOT NULL DEFAULT 0,
            profile_jobs INTEGER NOT NULL DEFAULT 0,
            target_plugin_version TEXT,
            target_catalog_builder_version INTEGER,
            worker_plugin_version TEXT,
            worker_catalog_builder_version INTEGER,
            last_error TEXT,
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT now()
        )
        """
    )
    migrations.ensure_columns(
        cur, preparation_state_table(),
        "target_plugin_version TEXT",
        "target_catalog_builder_version INTEGER",
        "worker_plugin_version TEXT",
        "worker_catalog_builder_version INTEGER",
    )
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {profile_backfill_state_table()} (
            catalog_instance_id TEXT PRIMARY KEY REFERENCES {table('catalog_sources')}(catalog_instance_id)
                ON DELETE CASCADE,
            server_id TEXT NOT NULL,
            status TEXT NOT NULL,
            processed_profiles INTEGER NOT NULL DEFAULT 0,
            queued_profiles INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT now()
        )
        """
    )
    migrations.ensure_columns(
        cur, profile_backfill_state_table(),
        "refresh_wake_pending BOOLEAN NOT NULL DEFAULT FALSE",
    )
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {analysis_runs_table()} (
            catalog_instance_id TEXT NOT NULL REFERENCES {table('catalog_sources')}(catalog_instance_id)
                ON DELETE CASCADE,
            run_id TEXT NOT NULL,
            server_id TEXT NOT NULL,
            status TEXT NOT NULL,
            songs_seen INTEGER NOT NULL DEFAULT 0,
            finalizer_job_id TEXT,
            queued_profiles INTEGER NOT NULL DEFAULT 0,
            profile_jobs INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            first_seen_at TIMESTAMP NOT NULL DEFAULT now(),
            last_seen_at TIMESTAMP NOT NULL DEFAULT now(),
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT now(),
            PRIMARY KEY (catalog_instance_id, run_id)
        )
        """
    )
    migrations.ensure_index(
        cur,
        f"CREATE INDEX IF NOT EXISTS {table('analysis_runs_status_idx')} "
        f"ON {analysis_runs_table()} (status, updated_at)",
    )
    # Releases through 1.1.6 could strand rows while importing AudioMuse/RQ
    # queue internals. Re-admit them to the database-driven reconciler.
    cur.execute(
        f"""
        UPDATE {analysis_runs_table()}
           SET status='pending', finalizer_job_id=NULL, last_error=NULL,
               completed_at=NULL, updated_at=now()
         WHERE status IN ('registering', 'queued', 'enqueue_failed', 'failed')
            OR (status='running' AND updated_at
                < now() - interval '{ANALYSIS_RUN_STALE_MINUTES} minutes')
        """
    )
    # Retarget work admitted by an older plugin process so a reloaded worker can
    # attest and execute it. The claim remains coalesced in SQL.
    cur.execute(
        f"""
        UPDATE {preparation_state_table()}
           SET status='queued', phase='queued',
               target_plugin_version=%s,
               target_catalog_builder_version=%s,
               worker_plugin_version=NULL,
               worker_catalog_builder_version=NULL,
               last_error=NULL, completed_at=NULL, updated_at=now()
         WHERE status IN ('queued', 'running', 'failed')
        """,
        (PLUGIN_VERSION, CATALOG_BUILDER_VERSION),
    )
    cur.close()
    migrate_enrichment(db)
    loudness_stream.migrate_loudness(db)
    loudness_backfill.migrate_backfill(db)
    credits_store.migrate(db)
    prune_catalog_storage(db)
    # Must run after the published-profile seed above (marker
    # published_source_profiles_seed_v1): its edge sweep deletes every edge
    # no published profile reaches, which before the seed is every edge of a
    # 1.2.5 install (P2-3). After that sweep it withdraws the seed's
    # orphans and republishes ready-but-unpublished profiles (P3-7).
    compact_enrichment_storage(db, profile_versions=(ANALYZER_VERSION, SCHEMA_VERSION))
    migrate_collections(db)
    refresh_integrity_snapshot(db)
    refresh_status_summaries(db)
    migrate_shelves(db)
    vibes.migrate_vibes(db)
    journeys.migrate_journeys(db)
    covers.migrate_covers(db)
    personal_discovery.migrate(db)
    music_metadata.migrate(db)
    # The reconcile tables (the journal, runner_state, the work tables'
    # retry columns); R8: no schedule of Lumae's stays.
    migrate_reconcile(db)
    retire_lumae_schedules(db)
    revoke_stranded_tasks(db)
    db.commit()
    # Installation is schema work, not a reason to rebuild the full analysis
    # and relationship projections. Only a missing/stale catalogue publication
    # is admitted here; ordinary analysis hooks and explicit prepare requests
    # own later enrichment.
    enqueue_required_catalog_preparations(db=db)
    # The runners consume the durable requests above. Install hooks remain
    # schema-only and never queue root work.
    # Storage reclaimed after the migration commits, in short transactions:
    # MusicBrainz responses an older version cached for 30 days, and edges
    # that pre-K6 journal rows still embed.
    credits_store.purge_http_cache_fully(db)
    externalize_journal_edges(db)
    # SF.3: v3 digests (and music-end recheck flags) for the stored edges,
    # within a budget here; runner turns finish the rest.
    _safe_edge_v3_upgrade(db)


def parse_ids(value):
    if not value:
        return []
    ids = []
    seen = set()
    for raw in str(value).split(","):
        track_id = raw.strip()
        if track_id and track_id not in seen:
            ids.append(track_id)
            seen.add(track_id)
    return ids[:500]


def fetch_profile_rows(ids, catalog_instance_id=None):
    if not ids:
        return []
    db = get_db()
    cur = db.cursor()
    if catalog_instance_id:
        cur.execute(
            f"""
            SELECT p.track_id, p.sample_rate, p.duration_ms, p.ref_lufs, p.start_ramp, p.end_ramp,
                   p.analyzer_ver, p.analyzed_at, p.media_signature, p.status, p.last_error,
                   edge.payload AS edge_profile
              FROM {source_profiles_table()} p {edge_join()}
             WHERE p.catalog_instance_id=%s AND p.track_id = ANY(%s)
            """,
            (catalog_instance_id, ids),
        )
    else:
        # Compatibility path for pre-0.8 clients on a single-provider install.
        cur.execute(
            f"""
            SELECT track_id, sample_rate, duration_ms, ref_lufs, start_ramp, end_ramp,
                   analyzer_ver, analyzed_at, media_signature, status, last_error
              FROM {profiles_table()}
             WHERE track_id = ANY(%s)
            """,
            (ids,),
        )
    columns = [desc[0] for desc in cur.description]
    rows = [dict(zip(columns, row)) for row in cur.fetchall()]
    cur.close()
    return rows


def fetch_published_profile_rows(ids, catalog_instance_id, edge_schema=2):
    if not ids:
        return []
    db = get_db()
    cur = db.cursor()
    # SF.3: ``edge_schema`` 3 serves each edge's v3 projection (contract §4.5).
    edge_columns = edge_payload_sql("e", edge_schema) + " AS payload"
    cur.execute(
        f"""SELECT p.track_id, p.sample_rate, p.duration_ms, p.ref_lufs,
                  p.start_ramp, p.end_ramp, p.analyzer_ver, p.analyzed_at,
                  p.media_signature, edge.payload AS edge_profile
             FROM {table('published_source_profiles')} p {edge_join(columns=edge_columns)}
            WHERE p.catalog_instance_id=%s AND p.track_id=ANY(%s)""",
        (catalog_instance_id, ids),
    )
    columns = [desc[0] for desc in cur.description]
    rows = [dict(zip(columns, row)) for row in cur.fetchall()]
    cur.close()
    return rows


def _bytes(value):
    if value is None:
        return b""
    if isinstance(value, memoryview):
        return value.tobytes()
    if isinstance(value, bytes):
        return value
    return bytes(value)


def serialize_ready_profile(row):
    return serialize_profile(
        row["track_id"], row["sample_rate"], row["duration_ms"], row["ref_lufs"],
        row["start_ramp"], row["end_ramp"], row["analyzer_ver"], row["analyzed_at"],
        row.get("media_signature"), edge_profile=row.get("edge_profile"),
    )


def split_analyze_ids(ids, catalog_instance_id=None):
    rows = fetch_profile_rows(ids, catalog_instance_id=catalog_instance_id)
    by_id = {row["track_id"]: row for row in rows}
    accepted = []
    already_ready = []
    already_pending = []
    for track_id in ids:
        row = by_id.get(track_id)
        status = row.get("status") if row else None
        if status == "ready":
            current_signature = (
                catalog_media_signature(
                    track_id, catalog_instance_id=catalog_instance_id
                )
                if catalog_instance_id else None
            )
            if current_signature and row.get("media_signature") != current_signature:
                accepted.append(track_id)
            else:
                already_ready.append(track_id)
        elif is_pending_profile_status(status):
            already_pending.append(track_id)
        else:
            accepted.append(track_id)
    return accepted, already_ready, already_pending


def is_pending_profile_status(status):
    return str(status or "") in ("pending", "pending_interactive")


def arm_profile_claim_recovery(catalog_instance_id, db=None, commit=True):
    """Keep a durable wake for an abandoned token, including hook-only work."""
    db = db or get_db()
    cur = db.cursor()
    try:
        cur.execute(
            f"""INSERT INTO {profile_backfill_state_table()}
                    (catalog_instance_id, server_id, status, next_retry_at)
                   SELECT s.catalog_instance_id, s.current_core_server_id,
                          'queued', now() + interval '{PREPARATION_STALE_HOURS} hours'
                     FROM {table('catalog_sources')} s
                    WHERE s.catalog_instance_id=%s AND s.rebind_status='active'
                   ON CONFLICT (catalog_instance_id) DO UPDATE SET
                       status=CASE WHEN {profile_backfill_state_table()}.status='running'
                                   THEN 'running' ELSE 'queued' END,
                       next_retry_at=CASE
                           WHEN {profile_backfill_state_table()}.status='running'
                               THEN {profile_backfill_state_table()}.next_retry_at
                           WHEN {profile_backfill_state_table()}.status='queued'
                                AND {profile_backfill_state_table()}.next_retry_at IS NULL
                               THEN NULL
                           ELSE LEAST(
                               COALESCE({profile_backfill_state_table()}.next_retry_at,
                                        EXCLUDED.next_retry_at),
                               EXCLUDED.next_retry_at)
                           END,
                       refresh_wake_pending=CASE
                           WHEN {profile_backfill_state_table()}.status='running'
                               THEN TRUE
                           ELSE {profile_backfill_state_table()}.refresh_wake_pending END,
                       updated_at=now()
                   RETURNING catalog_instance_id""",
            (catalog_instance_id,),
        )
        armed = cur.fetchone() is not None
        if armed:
            wake_runners(db, "profile_claim_recovery")
        if commit:
            db.commit()
        return armed
    except Exception:
        db.rollback()
        raise
    finally:
        cur.close()


def mark_pending(ids, catalog_instance_id=None, priority="background", keep_live=False):
    if not ids:
        return {}
    if catalog_instance_id:
        db = get_db()
        return admit_attempts(
            db, catalog_instance_id, ids, priority=priority,
            analyzer_version=ANALYZER_VERSION, schema_version=SCHEMA_VERSION,
            recovery_arm=arm_profile_claim_recovery, keep_live=keep_live,
        )
    pending_status = "pending_interactive" if priority == "interactive" else "pending"
    db = get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {profiles_table()}
            (track_id, sample_rate, duration_ms, ref_lufs, start_ramp, end_ramp,
             analyzer_ver, profile_schema_ver, analyzed_at, status, last_error)
        SELECT unnest(%s::text[]), 0, 0, 0, decode('', 'hex'), decode('', 'hex'),
               %s, %s, now(), %s, NULL
        ON CONFLICT (track_id) DO UPDATE SET
            analyzed_at = EXCLUDED.analyzed_at,
            status = EXCLUDED.status,
            last_error = NULL
        """,
        (ids, ANALYZER_VERSION, SCHEMA_VERSION, pending_status),
    )
    db.commit()
    cur.close()
    return {}

def release_pending(ids, catalog_instance_id=None,
                    reason="Profile job could not be queued", tokens=None,
                    count_failure=True):
    """Release admitted attempts. ``count_failure=False`` for a release that
    never tried the analysis (pause, legacy migration, batch abort), so it
    does not use up the retry budget (LUM-007)."""
    if not ids:
        return
    if catalog_instance_id:
        return release_attempts(
            get_db(), catalog_instance_id,
            {track_id: tokens[track_id] for track_id in ids if tokens and track_id in tokens},
            reason,
            count_failure=count_failure,
        )
    db = get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        UPDATE {profiles_table()}
           SET status='stale', last_error=%s, analyzed_at=now()
         WHERE track_id=ANY(%s) AND status IN ('pending', 'pending_interactive')
        """,
        (str(reason)[:2000], ids),
    )
    db.commit()
    cur.close()


def record_interactive_profiles(ids, catalog_instance_id):
    """On-demand waveforms for the runners: pending attempts marked as
    waiting, and a wake (R6). Returns the attempt tokens."""
    tokens = mark_pending(ids, catalog_instance_id=catalog_instance_id, priority="interactive")
    if tokens:
        db = get_db()
        mark_profiles_waiting(db, catalog_instance_id, tokens)
        wake_runners(db, "interactive_profiles", commit=True)
    return tokens


def load_track_file(track_id, catalog_instance_id=None, server_id=None, defer=False):
    """The track's file for analysis: ``{track_id, file_path, media_signature,
    cleanup_path}``, or None when it is not in the published catalogue.

    WP2: Lumae's own download of the original file first (``_own_download``),
    the host's download when that is not possible. ``defer``: a parallel
    pass's turn thread resolves the download here and an analysis thread
    fetches it (``fetch_track_file``); the host's download never defers.
    """
    db = get_db()
    adapter = get_core_adapter()
    server_id = server_id or adapter.active_server_id()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT t.track_id, t.title, t.artist_display, t.media_fp,
               s.current_core_server_id, s.provider_type, s.catalog_instance_id
          FROM {table('catalog_sources')} s
          JOIN {table('catalog_state')} c USING (catalog_instance_id)
          JOIN {table('catalog_tracks')} t
            ON t.catalog_instance_id=s.catalog_instance_id
           AND t.published_generation=c.published_generation
         WHERE t.track_id=%s AND t.available=TRUE
           AND s.rebind_status='active'
           AND (%s IS NULL OR s.catalog_instance_id=%s)
           AND (%s IS NULL OR s.current_core_server_id=%s)
         ORDER BY s.is_default DESC
         LIMIT 1
        """,
        (track_id, catalog_instance_id, catalog_instance_id, server_id, server_id),
    )
    row = cur.fetchone()
    cur.close()
    if not row:
        return None
    if len(row) < 5:
        # Rollback-compatible path for a pre-catalogue profile migration. New
        # installations and completed catalogue refreshes always use the rich
        # five-column provider occurrence row below.
        item_id = row[0]
        file_path = row[1] if len(row) > 1 else None
        title = row[2] if len(row) > 2 else None
        author = row[3] if len(row) > 3 else None
        if file_path and os.path.exists(file_path):
            return {
                "track_id": str(item_id),
                "file_path": file_path,
                "media_signature": media_signature(file_path),
                "cleanup_path": None,
            }
        if not media_server_download_available():
            return None
        item = media_server_item(item_id, file_path, title, author)
        downloaded_path = download_track_to_temp(item)
        if not downloaded_path or not os.path.exists(downloaded_path):
            raise MediaDownloadError("media server download failed")
        return {
            "track_id": str(item_id),
            "file_path": downloaded_path,
            "media_signature": media_signature(downloaded_path),
            "cleanup_path": downloaded_path,
        }
    item_id = row[0]
    title = row[1] if len(row) > 1 else None
    author = row[2] if len(row) > 2 else None
    media_fp = row[3] if len(row) > 3 else None
    source_server_id = row[4] if len(row) > 4 else server_id
    provider_type = str(row[5] or "").lower() if len(row) > 5 else None
    source_catalog = row[6] if len(row) > 6 else catalog_instance_id
    if media_fp and provider_type:
        own = _own_download(item_id, source_catalog, source_server_id, provider_type, media_fp, defer)
        if own is not None:
            return own

    try:
        item = media_server_item(item_id, None, title, author)
        downloaded_path = ProviderCatalogBridge(adapter).download_track(
            source_server_id, _host_download_directory(), item
        )
    except Exception as exc:
        logger.warning("lumae_analysis could not download %s for analysis: %s", track_id, exc)
        raise MediaDownloadError("media server download failed") from exc

    if not downloaded_path or not os.path.exists(downloaded_path):
        raise MediaDownloadError("media server download failed")
    return {
        "track_id": str(item_id),
        "file_path": downloaded_path,
        "media_signature": f"catalog-media:{media_fp}" if media_fp else media_signature(downloaded_path),
        "cleanup_path": downloaded_path,
    }


# WP2: sources whose own download failed, with when; the host downloads for
# them for OWN_DOWNLOAD_RETRY_SECONDS, then Lumae tries its own again. A runner
# lives for days, so a refusal is not kept for its life (R8).
_own_download_refused = {}
OWN_DOWNLOAD_RETRY_SECONDS = 600


def _host_download_directory():
    """Where AudioMuse's own download puts a file: its TEMP_DIR in its jobs,
    Lumae's download directory in a runner (R5): every analysis run empties
    TEMP_DIR at its start, and the web process never downloads there."""
    if runner.ROLE.get() is None:
        return config.TEMP_DIR
    return analysis_download.task_directory(getattr(config, "TEMP_DIR", None))


def _refuse_own_download(catalog_instance_id, reason):
    if not _own_download_refused_now(catalog_instance_id):
        logger.warning("lumae_analysis downloads %s through AudioMuse for now: %s",
                       catalog_instance_id, reason)
    _own_download_refused[catalog_instance_id] = time.monotonic()


def _own_download_refused_now(catalog_instance_id):
    refused_at = _own_download_refused.get(catalog_instance_id)
    if refused_at is None:
        return False
    if time.monotonic() - refused_at >= OWN_DOWNLOAD_RETRY_SECONDS:
        _own_download_refused.pop(catalog_instance_id, None)
        return False
    return True


def _own_download(item_id, catalog_instance_id, server_id, provider_type, media_fp, defer):
    """The original file through Lumae's own stream target (WP2), or None
    for the host's download.

    The URL and credentials are resolved here, under the host's binding of
    the catalogue's server (the workbench preview's target; Navidrome with
    ``format=raw``). The file goes to this task's directory outside
    ``TEMP_DIR``. A failure falls back to the host for the rest of the task.
    """
    if not catalog_instance_id or _own_download_refused_now(catalog_instance_id):
        return None
    from . import collection_library

    try:
        with collection_library._provider_bridge().bound_module(server_id) as (server, module):
            if str((server or {}).get("provider_type") or "").lower() != provider_type:
                raise ValueError("the server's provider type changed")
            target, error = collection_library._resolve_stream_target(str(item_id), provider_type, module)
        if not target:
            raise ValueError((error or ("no stream target",))[0])
        directory = analysis_download.task_directory(getattr(config, "TEMP_DIR", None))
        resolved = analysis_download.resolve(target, provider_type, str(item_id), directory)
    except Exception as exc:
        _refuse_own_download(catalog_instance_id, f"no original-file stream ({type(exc).__name__}: {exc})")
        return None
    info = {"track_id": str(item_id), "file_path": resolved.path,
            "media_signature": f"catalog-media:{media_fp}", "cleanup_path": resolved.path}
    if defer:
        info["download"] = resolved
        return info
    try:
        analysis_download.fetch(resolved)
    except analysis_download.DownloadError as exc:
        _refuse_own_download(catalog_instance_id, exc)
        return None
    return info


def fetch_track_file(info):
    """Fetch a deferred download (an analysis thread; no host or database
    call); returns the file's path. Raises ``DownloadError``."""
    target = info.get("download")
    if target is not None:
        analysis_download.fetch(target, cancelled=analysis_isolation.current_cancelled)
    return info["file_path"]


def upsert_profile(
    track_id,
    result,
    status,
    last_error=None,
    media_sig=None,
    catalog_instance_id=None,
    attempt_token=None,
    failure_code=None,
    diagnostics=None,
):
    if catalog_instance_id:
        return complete_attempt(
            get_db(), catalog_instance_id, track_id, attempt_token,
            result, status, last_error, media_sig, ANALYZER_VERSION, SCHEMA_VERSION,
            failure_code=failure_code, diagnostics=diagnostics,
        )
    # The pre-source compatibility table has no public profile stream.
    db = get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {profiles_table()}
            (track_id, sample_rate, duration_ms, ref_lufs, start_ramp, end_ramp,
             analyzer_ver, profile_schema_ver, media_signature, analyzed_at, status, last_error)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, now(), %s, %s)
        ON CONFLICT (track_id) DO UPDATE SET
            sample_rate=EXCLUDED.sample_rate, duration_ms=EXCLUDED.duration_ms,
            ref_lufs=EXCLUDED.ref_lufs, start_ramp=EXCLUDED.start_ramp,
            end_ramp=EXCLUDED.end_ramp, analyzer_ver=EXCLUDED.analyzer_ver,
            profile_schema_ver=EXCLUDED.profile_schema_ver,
            media_signature=EXCLUDED.media_signature, analyzed_at=EXCLUDED.analyzed_at,
            status=EXCLUDED.status, last_error=EXCLUDED.last_error
        """,
        (track_id, int(getattr(result, "sample_rate", 0)),
         int(getattr(result, "duration_ms", 0)),
         float(getattr(result, "ref_lufs", 0.0)),
         getattr(result, "start_ramp_blob", b""),
         getattr(result, "end_ramp_blob", b""),
         ANALYZER_VERSION, SCHEMA_VERSION, media_sig, status, last_error),
    )
    db.commit()
    cur.close()
    return True


def catalog_capability():
    return {
        "contract_revision": CONTRACT_REVISION,
        "catalog_schema_version": CATALOG_SCHEMA_VERSION,
        "analysis_schema_version": ANALYSIS_SCHEMA_VERSION,
        "catalog_builder_version": CATALOG_BUILDER_VERSION,
        "supported_core_range": SUPPORTED_CORE_RANGE,
        "supported_provider_types": sorted(SUPPORTED_PROVIDER_TYPES),
        "features": list(CATALOG_FEATURES),
    }


def sync_contract(compatibility):
    """Describe breaking schemas and semantic formats independently of core version."""
    return {
        "revision": CONTRACT_REVISION,
        "producer": "lumae_analysis",
        "core_api_contract": compatibility.api_contract,
        "streams": {
            "catalog": {
                "schema_version": CATALOG_SCHEMA_VERSION,
                "semantic_contracts": [
                    "provider_track_ids_v1",
                    "complete_catalog_generation_v1",
                    "contiguous_change_journal_v1",
                ],
            },
            "analysis": {
                "schema_version": ANALYSIS_SCHEMA_VERSION,
                "semantic_contracts": [
                    "analysis_link_evidence_v1",
                    "musicnn_f32le_200_v1",
                    "clap_f32le_512_v1",
                    "audiomuse_musicnn_scalars_v1",
                ],
            },
            "profiles": {
                "schema_version": SCHEMA_VERSION,
                "analyzer_version": ANALYZER_VERSION,
                "semantic_contracts": ["lumae_playback_profile_v1"],
            },
            "credits": credits_service.capability(),
            "relationships": {
                "schema_version": RELATIONSHIP_SCHEMA_VERSION,
                "algorithm_version": RELATIONSHIP_ALGORITHM_VERSION,
                "semantic_contracts": ["lumae_album_artist_relationships_v1"],
            },
            "loudness": {"schema_version": loudness_stream.SCHEMA_VERSION},
        },
    }


def resolve_profile_source(catalog_instance_id=None, server_id=None, db=None):
    """Resolve one exact profile namespace; never fall through across providers."""
    sources = resolve_catalog_source(
        db or get_db(),
        server_id=str(server_id) if server_id else None,
        catalog_instance_id=str(catalog_instance_id) if catalog_instance_id else None,
    )
    if len(sources) != 1:
        raise ValueError(
            "An explicit catalog_instance_id is required when multiple music servers are configured."
        )
    source = sources[0]
    if catalog_instance_id and source["catalog_instance_id"] != str(catalog_instance_id):
        raise ValueError("Profile catalogue source identity changed")
    if server_id and not source_matches_server_id(source, server_id):
        raise ValueError("Profile music-server identity changed")
    return source


def profiles_unpublished_ready_count(db):
    """Current 'ready' source profiles that have no published row (AUD-05).

    A 1.2.5 worker wrote 'ready' rows and journal events but never a
    published_source_profiles row, and 1.3.0 then treats the track as current.
    "Current" means what ``published_profile_current`` checks: an active
    source, the track available in the published generation with the same
    media fingerprint, and the current analyzer and schema versions. An
    anti-join, then one key lookup per unpublished row; the repair is in
    docs/runbooks/UPGRADE_1.3.md (repair D).
    Returns None before the publication table exists.
    """
    cur = db.cursor()
    try:
        cur.execute("SELECT to_regclass(%s)", (table("published_source_profiles"),))
        exists = cur.fetchone()
        if not exists or exists[0] is None:
            return None
        # Anti-join first (normally empty), then check currency by key.
        cur.execute(
            f"""
            WITH unpublished AS MATERIALIZED (
                SELECT s.catalog_instance_id, s.track_id, s.media_signature
                  FROM {source_profiles_table()} s
                 WHERE s.status='ready'
                   AND s.analyzer_ver=%s AND s.profile_schema_ver=%s
                   AND NOT EXISTS (
                       SELECT 1 FROM {table('published_source_profiles')} p
                        WHERE p.catalog_instance_id=s.catalog_instance_id
                          AND p.track_id=s.track_id
                   )
            )
            SELECT count(*)
              FROM unpublished s
              JOIN {table('catalog_sources')} src
                ON src.catalog_instance_id=s.catalog_instance_id
               AND src.rebind_status='active'
              JOIN {table('catalog_state')} c
                ON c.catalog_instance_id=s.catalog_instance_id
             CROSS JOIN LATERAL (
                   -- One key lookup per row (P3-7). As a plain join on the
                   -- source the planner compared every unpublished row with
                   -- every track: 1,000 rows took 20 s at 132k tracks.
                   SELECT 1 FROM {table('catalog_tracks')} t
                    WHERE t.catalog_instance_id=s.catalog_instance_id
                      AND t.published_generation=c.published_generation
                      AND t.track_id=s.track_id
                      AND t.available=TRUE AND COALESCE(t.media_fp, '') <> ''
                      AND s.media_signature='catalog-media:' || t.media_fp
                    LIMIT 1) t
            """,
            (ANALYZER_VERSION, SCHEMA_VERSION),
        )
        row = cur.fetchone()
        return int(row[0]) if row and row[0] is not None else None
    finally:
        cur.close()


def integrity_state_table():
    return table("integrity_state")


def refresh_integrity_snapshot(db):
    """Recount ``profiles_unpublished_ready`` and ``profiles_orphaned`` (AUD-05, P3-7).

    The anti-joins read every 'ready' and every published profile (together
    about 250 ms at 94k profiles and 132k tracks), so health never runs them:
    install, web-worker start and the publication repair refresh these rows
    and health reads them by primary key. Runs in the caller's transaction. Returns the
    unpublished-ready count.
    """
    from .profile_publication import orphaned_publication_count

    cur = db.cursor()
    try:
        cur.execute(
            f"""
            CREATE TABLE IF NOT EXISTS {integrity_state_table()} (
                name TEXT PRIMARY KEY,
                value BIGINT,
                checked_at TIMESTAMPTZ NOT NULL DEFAULT now()
            )
            """
        )
        count = profiles_unpublished_ready_count(db)
        orphaned = None if count is None else orphaned_publication_count(cur)
        cur.execute(
            f"""
            INSERT INTO {integrity_state_table()} (name, value, checked_at)
            VALUES ('profiles_unpublished_ready', %s, now()),
                   ('profiles_orphaned', %s, now())
            ON CONFLICT (name) DO UPDATE
               SET value=EXCLUDED.value, checked_at=EXCLUDED.checked_at
            """,
            (count, orphaned),
        )
        return count
    finally:
        cur.close()


def upgrade_fences_installed(cur):
    """True when every AUD-05 fence is in the schema (one catalogue lookup).

    ``profile_changes.writer_generation`` and ``catalog_changes.writer_generation``
    are NOT NULL without a default, and ``collection_changes.seq`` has no
    default. False means the 1.3.0 migration has not (fully) run, so 1.2.5
    workers are not fenced.
    """
    cur.execute(
        """
        SELECT
          (SELECT count(*) FROM pg_attribute
            WHERE attrelid IN (to_regclass(%s), to_regclass(%s))
              AND attname='writer_generation' AND attnotnull
              AND NOT atthasdef AND NOT attisdropped) = 2
          AND EXISTS (
            SELECT 1 FROM pg_attribute
             WHERE attrelid = to_regclass(%s) AND attname='seq'
               AND NOT atthasdef AND NOT attisdropped)
        """,
        (table("profile_changes"), table("catalog_changes"),
         table("collection_changes")),
    )
    row = cur.fetchone()
    return bool(row[0]) if row else None


def _persisted_profile_integrity(cur):
    """The persisted profile counts and when they were taken ({} before any)."""
    cur.execute("SELECT to_regclass(%s)", (integrity_state_table(),))
    if cur.fetchone()[0] is None:
        return {}
    cur.execute(
        f"SELECT name, value, checked_at FROM {integrity_state_table()} "
        "WHERE name IN ('profiles_unpublished_ready', 'profiles_orphaned')"
    )
    result = {}
    for name, value, checked_at in cur.fetchall():
        result[name] = int(value) if value is not None else None
        if name == "profiles_unpublished_ready":
            result["profiles_checked_at"] = (
                checked_at.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
                if checked_at is not None else None
            )
    return result


def edge_profiles_stored(db=None):
    """Health ``edge_profiles.stored``: whether any edge profile is stored.

    ``available``/``enabled`` describe this process's PyAV runtime and the
    setting; edges are computed by the analysis worker, so a web process
    without PyAV still serves them (``served``). ``stored`` answers whether
    profile transfers can carry edges at all: True when at least one edge row
    exists, False when none does, None when unknown (no database or an older
    schema). One ``LIMIT 1`` probe; never raises.
    """
    try:
        db = db or get_db()
    except Exception:
        db = None
    if db is None:
        return None
    try:
        cur = db.cursor()
        try:
            cur.execute(f"SELECT 1 FROM {table('edge_profiles')} LIMIT 1")
            return cur.fetchone() is not None
        finally:
            cur.close()
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis could not probe stored edge profiles")
        return None


def edge_profiles_capability():
    """Health ``capabilities.edge_profiles``.

    ``available``/``enabled`` describe the answering process; ``analyzable``
    whether queued edge jobs will be computed (a worker reported a qualified
    runtime); ``worker_runtime`` that report; ``server_backfill`` that the
    server walks the library itself; ``queue`` the job counts (null unknown).
    """
    worker_analyzable, worker = edge_worker_state()
    if not edge_setting_enabled():
        analyzable = False
    elif worker_analyzable or edge_runtime_available():
        analyzable = True
    else:
        analyzable = worker_analyzable
    try:
        queue = edge_queue_counts(get_db())
    except Exception:
        queue = None
        try:
            _rollback_if_possible(get_db())
        except Exception:
            pass
    return {"schema_version": EDGE_SCHEMA_VERSION, "method": EDGE_METHOD,
            "available": edge_runtime_available(), "enabled": edge_profiles_enabled(),
            "analyzable": analyzable, "worker_runtime": worker,
            "served": True, "stored": edge_profiles_stored(),
            "server_backfill": True, "edge_status": True, "deferred_requests": True,
            # Runner plan R6: on-demand requests are recorded and served by
            # the runners; the deferred lists stay, empty.
            "pending_requests": True,
            "queue": queue, "schema_versions": edge_schema_versions()}


def edge_schema_versions(db=None):
    """Health ``edge_profiles.schema_versions`` (SF.3, contract §4.5): ``[2, 3]``
    once every stored edge has its v3 digest (``upgrade_stored_edges``), so a
    client that converts its own edges never meets a missing one; ``[2]``
    before then or when unknown.
    """
    try:
        return [2, 3] if edge_schema_v3_ready(db or get_db()) else [2]
    except Exception:
        try:
            _rollback_if_possible(db or get_db())
        except Exception:
            pass
        return [2]


def integrity_status(db=None):
    """Health ``integrity``: fail-closed invariants of the 1.3.0 upgrade (AUD-05).

    ``collections_feed_ok`` is live: False when a collection change row sits
    past the feed head (collection writes then return 503
    ``collection_feed_invariant``). ``profiles_unpublished_ready`` and
    ``profiles_orphaned`` (P3-7: published profiles whose track the current
    catalogue generation lacks) are the counts persisted by the last install,
    web-worker start or publication repair, and ``profiles_checked_at`` is
    when they were taken. ``fences_installed`` is False
    until the 1.3.0 migration has installed every old-writer fence. Values are
    None when unknown. All reads are index or catalogue lookups.
    """
    from .collection_manager import collection_feed_integrity

    result = {
        "collections_feed_ok": None,
        "profiles_unpublished_ready": None,
        "profiles_orphaned": None,
        "profiles_checked_at": None,
        "fences_installed": None,
    }
    try:
        db = db or get_db()
    except Exception:
        db = None
    if db is None:
        return result
    try:
        cur = db.cursor()
        try:
            result["collections_feed_ok"] = collection_feed_integrity(cur)
            result["fences_installed"] = upgrade_fences_installed(cur)
            result.update(_persisted_profile_integrity(cur))
        finally:
            cur.close()
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not read upgrade integrity")
    return result


def log_integrity_on_start(db):
    """Refresh the persisted profile count and log any violated invariant."""
    try:
        refresh_integrity_snapshot(db)
        db.commit()
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not refresh upgrade integrity")
    status = integrity_status(db)
    _rollback_if_possible(db)
    if status["fences_installed"] is False:
        logger.error(
            "lumae_analysis 1.3.0 migration is incomplete: 1.2.5 writers are not "
            "fenced. Re-run the plugin install before starting RQ workers "
            "(docs/runbooks/UPGRADE_1.3.md)"
        )
    if status["collections_feed_ok"] is False:
        logger.error(
            "lumae_analysis collection feed invariant violated (MAX(seq) > head_seq); "
            "collection writes return 503 until repaired: docs/runbooks/UPGRADE_1.3.md"
        )
    if status["profiles_unpublished_ready"]:
        logger.warning(
            "lumae_analysis found %s ready source profiles without a published row; "
            "repair: docs/runbooks/UPGRADE_1.3.md",
            status["profiles_unpublished_ready"],
        )
    if status["profiles_orphaned"]:
        logger.warning(
            "lumae_analysis found %s published profiles whose tracks are no longer "
            "in the catalogue; the next catalogue refresh withdraws them, or repair: "
            "docs/runbooks/UPGRADE_1.3.md",
            status["profiles_orphaned"],
        )
    return status


def repair_profile_publications(db=None):
    """Repair D (P3-7): make the published profiles agree with the catalogue.

    For each active source, bounded per run: withdraw published profiles
    whose track the current catalogue generation lacks (delete events), and
    republish 'ready' profiles that have no published row (upsert events,
    through complete_attempt's checks). Each batch is a short transaction
    under the source's catalog_state row lock, so it is safe while analysis
    and catalogue refreshes run, and running it again changes nothing. Then
    recounts the persisted integrity counts, which health reports.
    """
    from .profile_publication import republish_ready_profiles, withdraw_orphaned_profiles

    db = db or get_db()
    cur = db.cursor()
    try:
        cur.execute(
            f"SELECT catalog_instance_id FROM {table('catalog_sources')} "
            "WHERE rebind_status='active' ORDER BY catalog_instance_id"
        )
        sources = [str(row[0]) for row in cur.fetchall()]
    finally:
        cur.close()
    db.commit()
    withdrawn = republished = 0
    for source in sources:
        withdrawn += len(withdraw_orphaned_profiles(db, source))
        republished += len(
            republish_ready_profiles(db, source, ANALYZER_VERSION, SCHEMA_VERSION)
        )
    try:
        refresh_integrity_snapshot(db)
        db.commit()
        cur = db.cursor()
        try:
            counts = _persisted_profile_integrity(cur)
        finally:
            cur.close()
        db.commit()
    except Exception:
        _rollback_if_possible(db)
        raise
    return {
        "withdrawn": withdrawn,
        "republished": republished,
        "profiles_unpublished_ready": counts.get("profiles_unpublished_ready"),
        "profiles_orphaned": counts.get("profiles_orphaned"),
    }


@bp.get("/api/health")
def health():
    compatibility = detect_core()
    return jsonify(
        {
            "plugin": "lumae_analysis",
            "plugin_version": PLUGIN_VERSION,
            "core_version": compatibility.core_version,
            "core_adapter": compatibility.adapter,
            "supported_core_range": SUPPORTED_CORE_RANGE,
            "sync_contract": sync_contract(compatibility),
            "schema_version": SCHEMA_VERSION,
            "analyzer_version": ANALYZER_VERSION,
            "capabilities": {
                "profile_bootstrap": {
                    "protocol_version": 2,
                    "schema_version": 1,
                    "auth": "host_authenticated",
                    "auth_enabled": _host_auth_enabled(),
                    "transfer_contract": profile_bootstrap.TRANSFER_CONTRACT,
                    "available": profile_bootstrap.availability(),
                    "sliding_expiry": True,
                    "idempotent_create": True,
                    "create_adoption": True,
                },
                "edge_profiles": edge_profiles_capability(),
                "personal_discovery": {"schema_version": 1, "enabled": collections_enabled(), "scope": health_scope_mode(), "features": ["album_memory_context", "enjoyment_feedback"]},
                "music_metadata": {"schema_version": 1, "enabled": not maintenance_paused(), "provider": "musicbrainz", "daily_request_limit": 80, "recording_membership": True},
                "shelves": {
                    "schema_version": SHELVES_SCHEMA_VERSION,
                    "enabled": collections_enabled(),
                    "scope": health_scope_mode(),
                },
                "vibes": vibes.capability(collections_enabled(), health_scope_mode()),
                "journeys": journeys.capability(collections_enabled(), health_scope_mode()),
                "covers": covers.capability(collections_enabled(), health_scope_mode()),
                "collections": {
                    "schema_version": COLLECTIONS_SCHEMA_VERSION,
                    "backup_version": COLLECTIONS_BACKUP_VERSION,
                    "enabled": collections_enabled(),
                    "scope": health_scope_mode(),
                    "feed_epoch": True,
                    "contract": COLLECTIONS_CONTRACT,
                    "source_scoped_items": True,
                },
                "catalog_mirror": catalog_capability(),
                "credits": credits_service.capability(),
                "loudness": loudness_stream.capability(),
                "transport": {"gzip": True},
                "profile_stream": {"edge_refs": True},
                "analysis_vectors": {"generation_fallback": True, "missing": True, "strict_generation": True},
            },
            "integrity": integrity_status(),
            "status": "ok" if compatibility.supported else compatibility.status,
        }
    )


@bp.get("/api/catalog/health")
def catalog_health():
    compatibility = detect_core()
    db = None
    try:
        servers = sanitized_server_summaries(compatibility)
    except Exception as exc:
        logger.exception("lumae_analysis could not enumerate AudioMuse servers")
        payload = compatibility.as_dict()
        payload.update(
            {
                "plugin": "lumae_analysis",
                "plugin_version": PLUGIN_VERSION,
                "catalog_schema_version": CATALOG_SCHEMA_VERSION,
                "analysis_schema_version": ANALYSIS_SCHEMA_VERSION,
                "capability": catalog_capability(),
                "sync_contract": sync_contract(compatibility),
                "servers": [],
                "status": "server_discovery_failed",
                "reason": redact_stored_error(str(exc)),
            }
        )
        return jsonify(payload), 503

    persisted = []
    if compatibility.supported:
        try:
            db = get_db()
        except Exception:
            db = None
            logger.exception("lumae_analysis could not open catalogue health database")
        if db is not None:
            try:
                bridge = ProviderCatalogBridge()
                for candidate in bridge.list_servers():
                    if candidate.get("supported"):
                        # Pinged on every request, written only when the state
                        # or version changed (P2-1). An applied transition's
                        # AudioMuse health is refreshed by the
                        # provider_identity_recheck cron, not by this GET.
                        observation = observe_provider_version(
                            db,
                            bridge,
                            candidate["server_id"],
                            commit=False,
                            refresh_health=False,
                        )
                        if (observation or {}).get("written"):
                            # The route owns its transaction: a changed
                            # identity is durable before the next server or
                            # the readiness below is read.
                            db.commit()
            except Exception:
                _rollback_if_possible(db)
                logger.exception("lumae_analysis could not observe provider identity")
        try:
            if db is not None:
                persisted = resolve_catalog_source(db)
        except Exception:
            logger.exception("lumae_analysis could not read persisted catalogue health")
    if persisted:
        servers = persisted
        for server in servers:
            catalog_instance_id = server.get("catalog_instance_id")
            if not catalog_instance_id:
                continue
            try:
                state = preparation_state(catalog_instance_id, db=db)
                server["preparation"] = state
                if not preparation_attestation_is_current(state):
                    server["catalog"]["refresh_required"] = True
                    server["catalog"]["refresh_reason"] = "worker_version_mismatch"
            except Exception:
                logger.exception(
                    "lumae_analysis could not read catalogue preparation health"
                )
    servers = [
        {
            **server,
            "supported": str(server.get("provider_type") or "").strip().lower()
            in SUPPORTED_PROVIDER_TYPES,
            **(
                {"status": "provider_unsupported"}
                if str(server.get("provider_type") or "").strip().lower()
                not in SUPPORTED_PROVIDER_TYPES
                else {}
            ),
        }
        for server in servers
    ]
    policy = dedup_policy()
    if compatibility.adapter == "v3_registry":
        servers = [
            {
                **server,
                **(
                    {
                        "v3_readiness": v3_release_readiness(
                            db,
                            compatibility,
                            server,
                            policy,
                        )
                    }
                    if server["supported"]
                    else {}
                ),
            }
            for server in servers
        ]
    if db is not None:
        guarded_servers = []
        for server in servers:
            transition = None
            catalog_instance_id = server.get("catalog_instance_id")
            if catalog_instance_id:
                try:
                    transition = provider_transition_health(db, catalog_instance_id)
                except Exception:
                    logger.exception(
                        "lumae_analysis could not read provider transition health for %s",
                        catalog_instance_id,
                    )
            if transition:
                server = {
                    **server,
                    "provider_identity_transition": transition,
                    "catalog_sync_allowed": transition["catalog_sync_allowed"],
                    "analysis_sync_allowed": transition["analysis_sync_allowed"],
                    "audiomuse_projection_ingest_allowed": transition[
                        "audiomuse_projection_ingest_allowed"
                    ],
                    "provider_mutations_allowed": transition["provider_mutations_allowed"],
                    "audiomuse_health": transition.get("audiomuse_health"),
                }
                if not transition["catalog_sync_allowed"] and server.get("v3_readiness"):
                    readiness = dict(server["v3_readiness"])
                    readiness["ready"] = False
                    readiness["fully_verified"] = False
                    readiness["analysis_sync_allowed"] = False
                    readiness["blockers"] = list(
                        dict.fromkeys([*(readiness.get("blockers") or []), TRANSITION_BLOCKER])
                    )
                    admission = dict(readiness.get("admission") or {})
                    for stream in ("catalog", "analysis"):
                        stream_admission = dict(admission.get(stream) or {})
                        stream_admission["admitted"] = False
                        stream_admission["status"] = "denied"
                        stream_admission["blockers"] = list(
                            dict.fromkeys(
                                [*(stream_admission.get("blockers") or []), TRANSITION_BLOCKER]
                            )
                        )
                        admission[stream] = stream_admission
                    readiness["admission"] = admission
                    server["v3_readiness"] = readiness
            # 1.6.0 (JF.8), additive: the server Id bound to this catalogue
            # (Jellyfin) and the version the identity guard last verified, so
            # the app can cross-check the server it signed in to.
            server = {
                **server,
                "provider_server_id": server.get("provider_server_id"),
                "provider_version": (transition or {}).get("current_provider_version"),
            }
            guarded_servers.append(server)
        servers = guarded_servers
    payload = compatibility.as_dict()
    payload.update(
        {
            "plugin": "lumae_analysis",
            "plugin_version": PLUGIN_VERSION,
            "catalog_schema_version": CATALOG_SCHEMA_VERSION,
            "analysis_schema_version": ANALYSIS_SCHEMA_VERSION,
            "catalog_builder_version": CATALOG_BUILDER_VERSION,
            "capability": catalog_capability(),
            "sync_contract": sync_contract(compatibility),
            "dedup_policy": policy,
            "servers": [redact_source_errors(server) for server in servers],
        }
    )
    response = jsonify(payload)
    response.headers["Cache-Control"] = "private, no-cache"
    response.headers["Vary"] = "Authorization, Cookie"
    return response, 200 if compatibility.supported else 409


def _catalog_principal_key():
    username = getattr(g, "auth_user", None)
    if username:
        return f"user:{username}"
    return f"client:{request.remote_addr or 'unknown'}"


def _private_json(payload, status=200, no_store=True):
    response = jsonify(payload)
    response.status_code = status
    response.headers["Cache-Control"] = "private, no-store" if no_store else "private, no-cache"
    response.headers["Vary"] = "Authorization, Cookie"
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


def _catalog_error(code, message, status):
    return _private_json({"error": code, "message": message}, status)


def _json_body(max_bytes=16_384):
    if request.content_length and request.content_length > max_bytes:
        raise ValueError("Request body is too large")
    body = request.get_json(silent=True)
    if body is None:
        return {}
    if not isinstance(body, dict):
        raise ValueError("JSON body must be an object")
    return body


def _preparation_api_payload(source, state=None):
    catalog = source.get("catalog") or {}
    analysis = source.get("analysis") or {}
    state = state if state is not None else preparation_state(source["catalog_instance_id"])
    catalog_ready = int(catalog.get("generation") or 0) > 0
    fingerprint_schema_version = int(
        catalog.get("fingerprint_schema_version", 1) or 1
    )
    fingerprint_current = (
        fingerprint_schema_version == CATALOG_FINGERPRINT_SCHEMA_VERSION
    )
    attestation_current = preparation_attestation_is_current(state)
    effective_refresh_required = (
        bool(catalog.get("refresh_required", False))
        or not fingerprint_current
        or not attestation_current
    )
    effective_refresh_reason = (
        "fingerprint_schema_rebase"
        if not fingerprint_current
        else (
            "worker_version_mismatch"
            if not attestation_current
            else catalog.get("refresh_reason")
        )
    )
    current = (
        catalog_ready
        and int(catalog.get("builder_version") or 0) >= CATALOG_BUILDER_VERSION
        and not effective_refresh_required
    )
    active = preparation_is_active(state)
    if active:
        status = state["status"]
        phase = state["phase"]
    elif current:
        status = "ready"
        phase = "ready"
    elif state and state.get("status") == "failed":
        status = "failed"
        phase = state.get("phase") or "failed"
    else:
        status = "required"
        phase = (
            effective_refresh_reason
            or ("analysis_projection" if catalog_ready else "catalog_refresh")
        )
    attestation_error = None
    if not attestation_current and not active:
        attestation_error = (
            "The catalogue worker did not attest the plugin version requested by the "
            "AudioMuse API. Restart AudioMuse workers; repair will retry automatically."
        )
    return {
        "operation_id": source["catalog_instance_id"],
        "status": status,
        "phase": phase,
        "server_id": source["server_id"],
        "catalog_instance_id": source["catalog_instance_id"],
        "catalog_ready": catalog_ready,
        "publication_current": current,
        "generation": int(catalog.get("generation") or 0),
        "counts": catalog.get("entity_counts") or {},
        "published_builder_version": int(catalog.get("builder_version") or 0),
        "current_builder_version": CATALOG_BUILDER_VERSION,
        "fingerprint_schema_version": fingerprint_schema_version,
        "current_fingerprint_schema_version": CATALOG_FINGERPRINT_SCHEMA_VERSION,
        "snapshot_estimated_bytes": int(
            catalog.get("snapshot_estimated_bytes", 0) or 0
        ),
        "last_scan_change_counts": catalog.get("last_scan_change_counts") or {},
        "last_scan_change_reason": catalog.get("last_scan_change_reason"),
        "last_scan_duration_ms": catalog.get("last_scan_duration_ms"),
        "refresh_required": effective_refresh_required,
        "refresh_reason": effective_refresh_reason,
        "analysis_ready": analysis.get("status") == "complete",
        "target_plugin_version": (state or {}).get("target_plugin_version"),
        "target_catalog_builder_version": (state or {}).get(
            "target_catalog_builder_version"
        ),
        "worker_plugin_version": (state or {}).get("worker_plugin_version"),
        "worker_catalog_builder_version": (state or {}).get(
            "worker_catalog_builder_version"
        ),
        "worker_attested": attestation_current,
        "last_error": redact_stored_error(
            (state or {}).get("last_error")
            or attestation_error
            or catalog.get("last_error")
        ),
        "updated_at": (state or {}).get("updated_at"),
    }


def _resolve_preparation_source(body):
    sources = resolve_catalog_source(
        get_db(),
        server_id=body.get("server_id"),
        catalog_instance_id=body.get("catalog_instance_id"),
    )
    if len(sources) != 1:
        raise ValueError(
            "An explicit server_id is required when multiple music servers are configured."
        )
    source = sources[0]
    if source.get("rebind_status") != "active":
        raise CatalogScanError(
            "AudioMuse was upgraded; confirm source continuity before preparing Lumae."
        )
    return source


@bp.post("/api/catalog/prepare")
def catalog_prepare_api():
    try:
        body = _json_body()
        source = _resolve_preparation_source(body)
        initial = _preparation_api_payload(source)
        if initial["publication_current"]:
            return _private_json(initial, 200)
        if not preparation_is_active(preparation_state(source["catalog_instance_id"])):
            # R6: the claim records the work and wakes the runners.
            claim_preparation(source)
        payload = _preparation_api_payload(
            source, preparation_state(source["catalog_instance_id"])
        )
        response = _private_json(payload, 202)
        response.headers["Retry-After"] = "2"
        response.headers["Location"] = (
            f"/plugins/lumae_analysis/api/catalog/prepare/{source['catalog_instance_id']}"
        )
        return response
    except KeyError:
        return _catalog_error("source_not_found", "Catalogue source was not found.", 404)
    except CatalogScanError as exc:
        return _catalog_error("preparation_blocked", str(exc), 409)
    except ValueError as exc:
        return _catalog_error("invalid_preparation", str(exc), 400)
    except Exception:
        logger.exception("lumae_analysis could not queue catalogue preparation")
        return _catalog_error(
            "preparation_queue_failed",
            "Catalogue preparation could not be queued. Try again in a moment.",
            503,
        )


@bp.get("/api/catalog/prepare/<operation_id>")
def catalog_prepare_status_api(operation_id):
    try:
        sources = resolve_catalog_source(get_db(), catalog_instance_id=operation_id)
        if len(sources) != 1:
            raise KeyError("Unknown catalogue source")
        source = sources[0]
        payload = _preparation_api_payload(
            source, preparation_state(source["catalog_instance_id"])
        )
        response = _private_json(payload, 200, no_store=False)
        if payload["status"] in ("queued", "running"):
            response.headers["Retry-After"] = "2"
        return response
    except KeyError:
        return _catalog_error("source_not_found", "Catalogue source was not found.", 404)


@bp.post("/api/catalog/refresh")
def catalog_refresh_api():
    try:
        body = _json_body()
        server_id = body.get("server_id")
        catalog_instance_id = body.get("catalog_instance_id")
        sources = resolve_catalog_source(
            get_db(), server_id=server_id, catalog_instance_id=catalog_instance_id
        )
        if len(sources) != 1:
            return _catalog_error(
                "source_required",
                "An explicit server_id is required when multiple music servers are configured.",
                409,
            )
        source = sources[0]
        if catalog_instance_id and source["catalog_instance_id"] != catalog_instance_id:
            return _catalog_error("source_mismatch", "Catalogue source identity changed.", 409)
        if source.get("rebind_status") != "active":
            return _catalog_error(
                "rebind_required",
                "AudioMuse was upgraded; confirm source continuity before refreshing.",
                409,
            )
        stale_for = max(0, min(int(body.get("if_stale_for_seconds", 0) or 0), 604_800))
        completed_at = source["catalog"].get("completed_at")
        if stale_for and completed_at and source["catalog"]["status"] == "complete":
            try:
                completed = datetime.fromisoformat(completed_at.replace("Z", "+00:00"))
                age = (datetime.now(timezone.utc) - completed).total_seconds()
                if age < stale_for:
                    return _private_json(
                        {
                            "status": "fresh",
                            "server_id": source["server_id"],
                            "catalog_instance_id": source["catalog_instance_id"],
                            "generation": source["catalog"]["generation"],
                        },
                        200,
                    )
            except ValueError:
                pass
        queued = {
            "status": "queued",
            "server_id": source["server_id"],
            "catalog_instance_id": source["catalog_instance_id"],
        }
        # R6: the request is kept, and the runner's next pass refreshes; a
        # scan that starts after it serves it (SQ.1).
        db = get_db()
        want_catalog_refresh(db, source["catalog_instance_id"])
        wake_runners(db, "catalog_refresh_wanted")
        db.commit()
        return _private_json(queued, 202)
    except (KeyError, ValueError, CatalogScanError) as exc:
        return _catalog_error("invalid_refresh", str(exc), 400)


@bp.post("/api/catalog/rebind")
def catalog_rebind_api():
    """Prove and accept an exact v2-to-v3 source continuity match."""
    try:
        body = _json_body()
        catalog_instance_id = str(body.get("catalog_instance_id") or "").strip()
        server_id = str(body.get("server_id") or "").strip()
        if not catalog_instance_id or not server_id:
            return _catalog_error(
                "identity_required", "Catalogue instance and candidate server are required.", 400
            )
        result = attempt_legacy_rebind(get_db(), catalog_instance_id, server_id)
        if result["status"] != "active":
            return _catalog_error(
                "continuity_not_proven",
                "The v3 provider catalogue does not exactly match the stored v2 source.",
                409,
            )
        return _private_json(result)
    except KeyError:
        return _catalog_error("source_not_found", "Catalogue source was not found.", 404)
    except (ValueError, CatalogScanError) as exc:
        return _catalog_error("invalid_rebind", str(exc), 409)


@bp.post("/api/catalog/verify-scope")
def catalog_verify_scope_api():
    try:
        body = _json_body()
        catalog_instance_id = str(body.get("catalog_instance_id") or "").strip()
        if not catalog_instance_id:
            return _catalog_error("identity_required", "Catalogue instance is required.", 400)
        result = verify_library_scope(
            get_db(),
            catalog_instance_id,
            body.get("library_ids"),
            body.get("provider_track_ids") if "provider_track_ids" in body else None,
        )
        return _private_json(result)
    except KeyError:
        return _catalog_error("source_not_found", "Catalogue source was not found.", 404)
    except ValueError as exc:
        return _catalog_error("invalid_scope", str(exc), 400)


@bp.post("/api/catalog/bootstrap-sessions")
def catalog_bootstrap_session_api():
    try:
        body = _json_body()
        result = create_bootstrap_session(
            get_db(),
            _catalog_principal_key(),
            stream=str(body.get("stream") or "catalog"),
            server_id=body.get("server_id"),
            catalog_instance_id=body.get("catalog_instance_id"),
        )
        return _private_json(result, 201)
    except KeyError:
        return _catalog_error("source_not_found", "Catalogue source was not found.", 404)
    except (ValueError, CatalogScanError) as exc:
        return _catalog_error("bootstrap_unavailable", str(exc), 409)


@bp.delete("/api/catalog/bootstrap-sessions")
def catalog_bootstrap_release_api():
    token = request.headers.get("X-Lumae-Bootstrap-Token")
    if not token:
        return _catalog_error("token_required", "Bootstrap token header is required.", 400)
    released = release_bootstrap_session(get_db(), token, _catalog_principal_key())
    return _private_json({"released": released})


@bp.get("/api/catalog/bootstrap")
def catalog_bootstrap_api():
    token = request.headers.get("X-Lumae-Bootstrap-Token")
    if not token:
        return _catalog_error("token_required", "Bootstrap token header is required.", 400)
    try:
        result = bootstrap_page(
            get_db(),
            token,
            _catalog_principal_key(),
            stream=str(request.args.get("stream") or "catalog"),
            page_token=request.args.get("page_token"),
            limit=request.args.get("limit", 500),
        )
        return _private_json(result)
    except KeyError:
        return _catalog_error(
            "bootstrap_required", "Bootstrap lease expired or was released.", 410
        )
    except ValueError as exc:
        return _catalog_error("invalid_page", str(exc), 400)


@bp.get("/api/catalog/changes")
def catalog_changes_api():
    cursor = request.args.get("cursor")
    if not cursor:
        return _catalog_error("cursor_required", "Catalogue cursor is required.", 400)
    try:
        result = read_catalog_changes(
            get_db(),
            cursor,
            server_id=request.args.get("server_id"),
            catalog_instance_id=request.args.get("catalog_instance_id"),
            limit=request.args.get("limit", 500),
        )
        return _private_json(result, no_store=False)
    except KeyError:
        return _catalog_error(
            "bootstrap_required", "Catalogue cursor expired or belongs to an old epoch.", 410
        )
    except ValueError as exc:
        return _catalog_error("invalid_cursor", str(exc), 400)


@bp.get("/api/catalog/provider-identity/manifest")
def provider_identity_manifest_api():
    try:
        manifest = read_transition_manifest(
            get_db(),
            transition_id=request.args.get("transition_id"),
            catalog_instance_id=request.args.get("catalog_instance_id"),
        )
    except KeyError:
        return _catalog_error(
            "transition_manifest_not_found",
            "No retained provider identity manifest was found.",
            404,
        )
    except ValueError as exc:
        return _catalog_error("identity_required", str(exc), 400)
    payload = json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2)
    response = Response(payload, mimetype="application/json")
    response.headers["Content-Disposition"] = (
        f'attachment; filename="lumae-provider-rekey-{manifest["transition_id"]}.json"'
    )
    response.headers["Cache-Control"] = "private, no-store"
    response.headers["Vary"] = "Authorization, Cookie"
    return response


@bp.get("/api/catalog/analysis/changes")
def analysis_changes_api():
    cursor = request.args.get("cursor")
    if not cursor:
        return _catalog_error("cursor_required", "Analysis cursor is required.", 400)
    try:
        result = read_analysis_changes(
            get_db(),
            cursor,
            server_id=request.args.get("server_id"),
            catalog_instance_id=request.args.get("catalog_instance_id"),
            limit=request.args.get("limit", 500),
        )
        return _private_json(result, no_store=False)
    except KeyError:
        return _catalog_error(
            "bootstrap_required", "Analysis cursor expired or belongs to an old epoch.", 410
        )
    except ValueError as exc:
        return _catalog_error("invalid_cursor", str(exc), 400)


@bp.post("/api/catalog/analysis/scalars")
def analysis_scalars_api():
    try:
        body = _json_body(max_bytes=64_000)
        catalog_instance_id = str(body.get("catalog_instance_id") or "")
        ids = body.get("provider_track_ids") or []
        if not catalog_instance_id or not isinstance(ids, list):
            raise ValueError("catalog_instance_id and provider_track_ids are required")
        return _private_json(
            {
                "catalog_instance_id": catalog_instance_id,
                "items": scalar_batch(get_db(), catalog_instance_id, ids),
            }
        )
    except (KeyError, ValueError) as exc:
        return _catalog_error("invalid_batch", str(exc), 400)


@bp.post("/api/catalog/analysis/vectors")
def analysis_vectors_api():
    try:
        body = _json_body(max_bytes=64_000)
        catalog_instance_id = str(body.get("catalog_instance_id") or "")
        ids = body.get("analysis_ids") or []
        family = str(body.get("family") or "musicnn")
        generation = body.get("generation")
        strict_generation = body.get("strict_generation") is True
        if not catalog_instance_id or not isinstance(ids, list):
            raise ValueError("catalog_instance_id and analysis_ids are required")
        payload = vector_batch(
            get_db(), catalog_instance_id, ids, family=family, generation=generation,
            strict_generation=strict_generation,
        )
        response = Response(payload, mimetype="application/vnd.lumae.f32le-v1")
        response.headers["Cache-Control"] = "private, no-store"
        response.headers["Vary"] = "Authorization, Cookie"
        response.headers["X-Content-Type-Options"] = "nosniff"
        return response
    except GenerationExpired as exc:
        return _private_json(
            {
                "error": "generation_expired",
                "message": str(exc),
                "requested_generation": exc.requested_generation,
                "current_generation": exc.current_generation,
            },
            410,
        )
    except (KeyError, ValueError, CatalogScanError) as exc:
        return _catalog_error("invalid_batch", str(exc), 400)


def _edge_schema_requested():
    """SF.3 (contract §4.5): ``edge_schema=3`` serves every edge in schema v3;
    ``2`` or none, v2 as in 1.6.1. Any other value raises ValueError, which the
    profile routes answer with 400 ``invalid_edge_schema``.
    """
    value = request.args.get("edge_schema")
    if value in (None, "", "2"):
        return 2
    if value == "3":
        return 3
    raise ValueError("edge_schema must be 2 or 3")


def _invalid_edge_schema(exc):
    return _catalog_error("invalid_edge_schema", str(exc), 400)


@bp.get("/api/profiles")
def profiles():
    try:
        edge_schema = _edge_schema_requested()
    except ValueError as exc:
        return _invalid_edge_schema(exc)
    try:
        source = resolve_profile_source(
            catalog_instance_id=request.args.get("catalog_instance_id")
        )
    except (KeyError, ValueError, CatalogScanError) as exc:
        return _catalog_error("source_required", str(exc), 409)
    ids = parse_ids(request.args.get("ids", ""))
    source_id = source["catalog_instance_id"]
    published = {
        row["track_id"]: row
        for row in fetch_published_profile_rows(ids, source_id, edge_schema)
    }
    attempts = {
        row["track_id"]: row
        for row in fetch_profile_rows(ids, catalog_instance_id=source_id)
    }
    ready = []
    failed = []
    missing = []
    for track_id in ids:
        row = published.get(track_id)
        if row is not None:
            try:
                ready.append(serialize_ready_profile(row))
            except Exception as exc:
                failed.append({"track_id": track_id, "reason": str(exc)})
        elif attempts.get(track_id, {}).get("status") in ("failed", "skipped_no_file"):
            failed.append({
                "track_id": track_id,
                "reason": public_failure_reason(attempts[track_id].get("last_error")) or "failed",
            })
        else:
            missing.append(track_id)
    body = {
        "schema_version": SCHEMA_VERSION,
        "analyzer_version": ANALYZER_VERSION,
        "catalog_instance_id": source["catalog_instance_id"],
        "profiles": ready,
        "missing": missing,
        "failed": failed,
    }
    if str(request.args.get("edge_status") or "").strip().lower() in ("1", "true"):
        # Opt-in (capabilities.edge_profiles.edge_status): without it the
        # response is unchanged.
        body["edge_status"] = edge_statuses(get_db(), source_id, ids)
    return _private_json(body)


@bp.get("/api/profiles/bootstrap")
def profiles_bootstrap_api():
    try:
        edge_schema = _edge_schema_requested()
    except ValueError as exc:
        return _invalid_edge_schema(exc)
    try:
        catalog_instance_id = str(request.args.get("catalog_instance_id") or "")
        if not catalog_instance_id:
            raise ValueError("catalog_instance_id is required")
        return _private_json(
            profile_bootstrap_page(
                get_db(),
                catalog_instance_id,
                page_token=request.args.get("page_token"),
                limit=request.args.get("limit", 250),
                edge_schema=edge_schema,
            ),
            no_store=False,
        )
    except KeyError:
        return _catalog_error(
            "bootstrap_required", "Profile bootstrap cursor expired.", 410
        )
    except (CatalogScanError, ValueError) as exc:
        return _catalog_error("invalid_profile_bootstrap", str(exc), 400)


def _edge_refs_requested():
    """K6 (P3-2): ``edge_refs=1`` (or ``true``) on a profile stream route.

    Any other value, or none, keeps the default: every edge in full.
    """
    return str(request.args.get("edge_refs") or "").strip().lower() in ("1", "true")


@bp.get("/api/profiles/changes")
def profile_changes_api():
    try:
        edge_schema = _edge_schema_requested()
    except ValueError as exc:
        return _invalid_edge_schema(exc)
    cursor = request.args.get("cursor")
    if not cursor:
        return _catalog_error("cursor_required", "Profile cursor is required.", 400)
    try:
        return _private_json(
            read_profile_changes(
                get_db(),
                cursor,
                catalog_instance_id=request.args.get("catalog_instance_id"),
                limit=request.args.get("limit", 250),
                edge_refs=_edge_refs_requested(),
                edge_schema=edge_schema,
            ),
            no_store=False,
        )
    except KeyError:
        return _catalog_error(
            "bootstrap_required", "Profile cursor expired or belongs to an old epoch.", 410
        )
    except (CatalogScanError, ValueError) as exc:
        return _catalog_error("invalid_cursor", str(exc), 400)


def _host_auth_enabled():
    """The host's live AUTH_ENABLED (K4); health ``auth`` stays the design string."""
    value = getattr(host_api.config, "AUTH_ENABLED", False)
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    return bool(value)


def _bootstrap_caller():
    """Who a v2 create counts against for the per-source rate limit."""
    username = getattr(g, "auth_user", None)
    if username:
        return f"user:{username}"
    if getattr(g, "auth_method", None) == "bearer":
        return "bearer"
    return profile_bootstrap.ANONYMOUS_CALLER


V2_BODY_MAX_BYTES = 16_384


def _v2_body(max_bytes=V2_BODY_MAX_BYTES):
    """The v2 JSON body, reading at most ``max_bytes`` + 1 bytes from the stream.

    ``Content-Length`` is checked first; a chunked body has none, so the read
    itself is bounded too. Non-JSON content types read as an empty body, like
    ``request.get_json(silent=True)``.
    """
    if request.content_length is not None and request.content_length > max_bytes:
        raise ValueError("Request body is too large")
    # A host hook may already have read (and cached) the body.
    raw = getattr(request, "_cached_data", None)
    if raw is None:
        # Read until EOF or one byte past the cap: a stream may return short reads.
        chunks, size = [], 0
        while size <= max_bytes:
            chunk = request.stream.read(max_bytes + 1 - size)
            if not chunk:
                break
            chunks.append(chunk)
            size += len(chunk)
        raw = b"".join(chunks)
    if len(raw) > max_bytes:
        raise ValueError("Request body is too large")
    if not request.is_json or not raw:
        return {}
    try:
        body = json.loads(raw)
    except ValueError:
        return {}
    if body is None:
        return {}
    if not isinstance(body, dict):
        raise ValueError("JSON body must be an object")
    return body


def _bootstrap_error(code, message, status, retry_after=None):
    response = _catalog_error(code, message, status)
    if status == 503:
        retry_after = retry_after or profile_bootstrap.UNAVAILABLE_RETRY_AFTER_S
    if status in (429, 503) and retry_after:
        response.headers["Retry-After"] = str(int(retry_after))
    return response


def _profile_bootstrap_v2(operation, **options):
    if not getattr(host_api.config, "DATABASE_URL", None):
        return _bootstrap_error("bootstrap_unavailable", "bootstrap_unavailable", 503)
    try:
        body = _v2_body()
    except ValueError:
        return _bootstrap_error("invalid_profile_bootstrap", "Invalid bootstrap request.", 400)
    try:
        result = operation(body, **options)
        return _private_json(result)
    except profile_bootstrap.BootstrapError as exc:
        return _bootstrap_error(exc.code, exc.code, exc.status, exc.retry_after)
    except Exception as exc:
        logger.exception("lumae_analysis profile bootstrap route failed (%s)", type(exc).__name__)
        return _bootstrap_error("bootstrap_unavailable", "bootstrap_unavailable", 503)


@bp.post("/api/profiles/bootstrap/sessions")
def profile_bootstrap_sessions_api():
    return _profile_bootstrap_v2(profile_bootstrap.create_session, caller=_bootstrap_caller())


@bp.post("/api/profiles/bootstrap/sessions/page")
def profile_bootstrap_sessions_page_api():
    return _profile_bootstrap_v2(profile_bootstrap.snapshot_page)


@bp.post("/api/profiles/bootstrap/sessions/catchup")
def profile_bootstrap_sessions_catchup_api():
    return _profile_bootstrap_v2(profile_bootstrap.catchup_page)


@bp.post("/api/profiles/bootstrap/sessions/release")
def profile_bootstrap_sessions_release_api():
    return _profile_bootstrap_v2(profile_bootstrap.release_session)


@bp.post("/api/catalog/relationships/prepare")
def relationships_prepare_api():
    try:
        body = _json_body(max_bytes=16_000)
        source = resolve_profile_source(
            catalog_instance_id=body.get("catalog_instance_id"),
            server_id=body.get("server_id"),
        )
        # The claim is durable and a runner builds it step by step (SQ.2,
        # R6): a queued task did one 20-second step, and while AudioMuse
        # analysed it was refused and logged as an error at every sync.
        result = start_relationship_preparation(
            catalog_instance_id=source["catalog_instance_id"],
            server_id=source["server_id"],
        )
        return _private_json(
            {
                **result,
                "relationships": relationship_status(
                    get_db(), source["catalog_instance_id"]
                ),
            }
        )
    except (CatalogScanError, KeyError, ValueError) as exc:
        return _catalog_error("source_required", str(exc), 409)


@bp.get("/api/catalog/relationships/status")
def relationships_status_api():
    try:
        catalog_instance_id = str(request.args.get("catalog_instance_id") or "")
        if not catalog_instance_id:
            raise ValueError("catalog_instance_id is required")
        return _private_json(relationship_status(get_db(), catalog_instance_id))
    except (CatalogScanError, KeyError, ValueError) as exc:
        return _catalog_error("source_required", str(exc), 409)


@bp.get("/api/catalog/relationships/bootstrap")
def relationships_bootstrap_api():
    try:
        catalog_instance_id = str(request.args.get("catalog_instance_id") or "")
        if not catalog_instance_id:
            raise ValueError("catalog_instance_id is required")
        return _private_json(
            relationship_bootstrap_page(
                get_db(),
                catalog_instance_id,
                page_token=request.args.get("page_token"),
                limit=request.args.get("limit", 100),
            ),
            no_store=False,
        )
    except KeyError:
        return _catalog_error(
            "bootstrap_required", "Relationship bootstrap cursor expired.", 410
        )
    except (CatalogScanError, ValueError) as exc:
        return _catalog_error("invalid_relationship_bootstrap", str(exc), 400)


@bp.get("/api/catalog/relationships/changes")
def relationship_changes_api():
    cursor = request.args.get("cursor")
    if not cursor:
        return _catalog_error(
            "cursor_required", "Relationship cursor is required.", 400
        )
    try:
        return _private_json(
            read_relationship_changes(
                get_db(),
                cursor,
                catalog_instance_id=request.args.get("catalog_instance_id"),
                limit=request.args.get("limit", 250),
            ),
            no_store=False,
        )
    except KeyError:
        return _catalog_error(
            "bootstrap_required",
            "Relationship cursor expired or belongs to an old epoch.",
            410,
        )
    except (CatalogScanError, ValueError) as exc:
        return _catalog_error("invalid_cursor", str(exc), 400)


@bp.get("/api/catalog/loudness/bootstrap")
def loudness_bootstrap_api():
    try:
        return _private_json(
            loudness_stream.bootstrap_page(
                get_db(),
                str(request.args.get("catalog_instance_id") or ""),
                page_token=request.args.get("page_token"),
                limit=request.args.get("limit"),
            ),
            no_store=False,
        )
    except KeyError:
        return _catalog_error(
            "bootstrap_required", "Loudness bootstrap token expired.", 410
        )
    except (CatalogScanError, ValueError) as exc:
        return _catalog_error("invalid_loudness_bootstrap", str(exc), 400)


@bp.get("/api/catalog/loudness/changes")
def loudness_changes_api():
    cursor = request.args.get("cursor")
    if not cursor:
        return _catalog_error("cursor_required", "Loudness cursor is required.", 400)
    try:
        return _private_json(
            loudness_stream.read_changes(
                get_db(),
                cursor,
                catalog_instance_id=request.args.get("catalog_instance_id"),
                limit=request.args.get("limit"),
            ),
            no_store=False,
        )
    except KeyError:
        return _catalog_error(
            "bootstrap_required",
            "Loudness cursor expired or belongs to an old epoch.",
            410,
        )
    except (CatalogScanError, ValueError) as exc:
        return _catalog_error("invalid_cursor", str(exc), 400)


@bp.post("/api/analyze")
def analyze():
    if maintenance_paused():
        return _catalog_error(
            "maintenance_paused",
            "Lumae background analysis is paused by the administrator.",
            503,
        )
    body = request.get_json(silent=True) or {}
    try:
        source = resolve_profile_source(catalog_instance_id=body.get("catalog_instance_id"))
    except (KeyError, ValueError, CatalogScanError) as exc:
        return _catalog_error("source_required", str(exc), 409)
    ids = parse_ids(",".join(body.get("ids", [])))[:MAX_INTERACTIVE_PROFILE_IDS]
    catalog_instance_id = source["catalog_instance_id"]
    accepted, already_ready, already_pending = split_analyze_ids(
        ids, catalog_instance_id=catalog_instance_id
    )
    # A library catch-up may already have marked these rows pending. They are
    # recorded on demand too, so the runner serves them first: current
    # playback is never trapped behind an hours-long library backfill (R6).
    record_interactive_profiles(accepted + already_pending, catalog_instance_id)
    return jsonify(
        {
            "accepted": accepted,
            "already_ready": already_ready,
            "already_pending": already_pending,
            # Older plugins named refused requests here; the runner refuses none.
            "deferred": [],
        }
    ), 202


def edge_setting_enabled():
    return str(get_setting("edge_profiles_enabled", "true")).lower() in ("true", "1", "yes")


def edge_profiles_enabled():
    """This process can compute edges: the setting is on and its runtime qualifies."""
    return edge_setting_enabled() and edge_runtime_available()


def edge_worker_state(db=None):
    """``(analyzable, status)`` from the workers' runtime reports; never raises."""
    try:
        db = db or get_db()
    except Exception:
        db = None
    if db is None:
        return None, None
    try:
        return edge_worker_runtime(db)
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis could not read the edge worker runtime")
        return None, None


def edge_profiles_analyzable(db=None):
    """Health ``edge_profiles.analyzable``: edge jobs queued now will be computed.

    False when the setting is off. Otherwise True when this process or a
    worker that reported within the freshness window has a qualified runtime,
    False when fresh reports all lack one, None when no worker reported.
    """
    if not edge_setting_enabled():
        return False
    analyzable, _status = edge_worker_state(db)
    if analyzable or edge_runtime_available():
        return True
    return analyzable


def edge_scheduling_allowed():
    return not maintenance_paused() and edge_profiles_analyzable() is True


# A worker re-reports its edge runtime at most this often; health treats a
# report as fresh for edge_profile_store.EDGE_RUNTIME_FRESH_HOURS.
EDGE_RUNTIME_REPORT_SECONDS = 600
_edge_runtime_reported_at = None


def report_edge_runtime(force=False, park=True):
    """Record this process's edge runtime verdict: a worker's, or the web
    process's before its runner takes heavy work (R7, ``park=False``).

    Called at worker start, by every edge task and by the runners. A
    qualified worker creates missing pass rows and resumes parked passes, and
    when either happened wakes the runners, so a fresh install or upgrade
    starts the library pass at once. A worker without a qualified runtime
    parks due passes so the runners can go idle.
    """
    global _edge_runtime_reported_at
    now = time.monotonic()
    if (not force and _edge_runtime_reported_at is not None
            and now - _edge_runtime_reported_at < EDGE_RUNTIME_REPORT_SECONDS):
        return
    db = None
    try:
        db = get_db()
        # S8: each job is a fresh fork of the worker, so the module global
        # above never remembered a report and every job wrote one; the
        # worker's own row says when it last reported.
        if not force and edge_runtime_reported_within(db, socket.gethostname(), EDGE_RUNTIME_REPORT_SECONDS):
            _edge_runtime_reported_at = now
            return
        status = edge_runtime_status()
        record_edge_runtime(db, socket.gethostname(), status)
        if status.get("available") and edge_setting_enabled():
            if ensure_edge_backfill_sources(db) + arm_edge_backfill(db, include_complete=False):
                wake_runners(db, "edge_backfill_ready", commit=True)
        elif park:
            # The web process without a runtime leaves the passes to a
            # worker that has one, and parks nothing of theirs.
            park_edge_backfill(db)
        # A worker with PyAV reports: loudness passes parked for want of it resume (LN.4c).
        if status.get("pyav") and loudness_backfill.arm(db, include_complete=False):
            wake_runners(db, "loudness_backfill_ready", commit=True)
        _edge_runtime_reported_at = now
    except Exception:
        if db is not None:
            _rollback_if_possible(db)
        logger.warning("lumae_analysis could not report the edge runtime")


def report_edge_runtime_on_start():
    report_edge_runtime(force=True)
    try:
        # WP2: download directories of task processes that are gone.
        analysis_download.remove_leftovers(getattr(config, "TEMP_DIR", None))
    except Exception:
        logger.warning("lumae_analysis could not remove leftover analysis downloads")


# A queued background edge batch yields its slot after this long; its
# unstarted jobs are released and due again at once.
EDGE_BACKGROUND_BUDGET_SECONDS = 60
# SF.3: the stored-edge v3 upgrade's time per install or runner pass.
EDGE_V3_UPGRADE_BUDGET_SECONDS = 20
# The library pass reads due tracks this many at a time, and pages on until
# its slice's deadline (performance plan WP1a).
EDGE_BACKFILL_PAGE_SIZE = 25


def _pass_deadline(deadline):
    """A library pass works until its slice's ``deadline``; called outside a
    runner, for one slice."""
    return deadline if deadline is not None else time.monotonic() + RUNNER_SLICE_SECONDS


def request_edge_profiles(ids, catalog_instance_id, *, priority="background"):
    """Edges asked for: on demand, jobs recorded for the runners and a wake;
    in the background, the library pass made due now, which covers them (R6):
    a finished pass starts again, costing one scan, since its candidates skip
    tracks that have an edge."""
    empty = {"available": False, "accepted": [], "already_ready": [], "already_pending": [],
             "unsupported": [], "deferred": []}
    if not edge_scheduling_allowed():
        return empty
    db = get_db()
    if priority != "interactive":
        ensure_edge_backfill_sources(db)
        if arm_edge_backfill(db, catalog_instance_id):
            wake_runners(db, "edge_backfill_ready")
        db.commit()
        return {**empty, "available": True, "already_pending": list(ids)}
    jobs, ready, pending, unsupported = claim_edge_requests(db, catalog_instance_id, ids, priority)
    if jobs:
        mark_edge_jobs_waiting(db, catalog_instance_id, jobs, RUNNER_WAITING_MARKER)
        wake_runners(db, "interactive_edges", commit=True)
    return {"available": True,
            "accepted": [job["track_id"] for job in jobs if job["track_id"] not in set(pending)],
            "already_ready": ready, "already_pending": pending, "unsupported": unsupported,
            # Older plugins named refused requests here; the runner refuses none.
            "deferred": []}


def _leave_edge_to_pass(track_id, catalog_instance_id):
    """A waveform analysed without its edge (edges off or not schedulable, no
    media revision): the library pass, not a task per song, makes the edge.
    With edges on, the waveform's own child call makes it (WP2,
    ``_publish_bundle_edge``); on-demand work no longer queues an edge task
    per track.

    The host admits a plugin root task from inside its own analysis, so a task
    per song put hundreds on the queue, and the host's analysis page shows the
    newest root task and kept switching to them. The pass is made due to reach
    the track instead, and a runner reaches it on its next pass (R6).
    """
    if not catalog_instance_id or not edge_profiles_enabled() or not edge_scheduling_allowed():
        return
    db = None
    try:
        db = get_db()
        if rewind_edge_backfill(db, catalog_instance_id, track_id):
            wake_runners(db, "edge_backfill_ready", commit=True)
    except Exception:
        if db is not None:
            _rollback_if_possible(db)
        logger.warning("lumae_analysis optional edge upgrade could not be scheduled")


@bp.post("/api/profiles/edges/analyze")
def edge_analyze_api():
    try:
        body = _json_body(max_bytes=64000)
        source = resolve_profile_source(catalog_instance_id=body.get("catalog_instance_id"))
        ids = body.get("ids")
        if not isinstance(ids, list) or len(ids) > 100 or any(not isinstance(i, str) or not 0 < len(i) <= 512 for i in ids):
            raise ValueError("ids must contain at most 100 track IDs")
        return _private_json(request_edge_profiles(ids, source["catalog_instance_id"], priority="interactive")), 202
    except (KeyError, ValueError, CatalogScanError) as exc:
        return _catalog_error("invalid_edge_request", str(exc), 400)


@bp.post("/api/profiles/edges/backfill")
def edge_backfill_api():
    """Compatibility: the server walks the library itself (``server_backfill``)."""
    try:
        body = _json_body(max_bytes=64000)
        source = resolve_profile_source(catalog_instance_id=body.get("catalog_instance_id"))
        after = body.get("after", "")
        if not isinstance(after, str) or len(after) > 512:
            raise ValueError("invalid backfill cursor")
        limit = body.get("limit", 100)
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100:
            raise ValueError("limit must be an integer from 1 to 100")
        ids = edge_backfill_candidates(get_db(), source["catalog_instance_id"], after, limit)
        result = request_edge_profiles(ids, source["catalog_instance_id"])
        result["next_after"] = ids[-1] if ids else None
        return _private_json(result), 202
    except (KeyError, ValueError, CatalogScanError) as exc:
        return _catalog_error("invalid_edge_request", str(exc), 400)


def analyze_edges_task(jobs, catalog_instance_id, server_id, priority="background",
                       budget_seconds=EDGE_BACKGROUND_BUDGET_SECONDS):
    """Compute edges for claimed jobs, one file at a time.

    A background batch serves on-demand work before each track and
    releases its unstarted jobs once ``budget_seconds`` have passed (None: no
    budget), so it never holds the plugin's task slot for long.
    """
    report_edge_runtime()
    outcomes = []
    background = priority != "interactive"
    deadline = time.monotonic() + budget_seconds if background and budget_seconds else None
    jobs = list(jobs)[:100]
    for index, job in enumerate(jobs):
        if background:
            serve_interactive()
            if deadline is not None and time.monotonic() > deadline:
                for rest in jobs[index:]:
                    update_edge_job(get_db(), catalog_instance_id, rest, "failed", "edge-enqueue-failed")
                    outcomes.append({"track_id": rest["track_id"], "status": "released"})
                break
        outcome, state = _prepare_edge(job, catalog_instance_id, server_id)
        if state is not None:
            try:
                payload, error = run_file_analysis(loudness_v1.analyze_edge_file, state["path"],
                                                   **state["kwargs"]), None
            except Exception as exc:
                payload, error = None, exc
            outcome = _finish_edge(state, payload, error)
        if outcome is not None:
            outcomes.append(outcome)
    return outcomes


def _prepare_edge(job, catalog_instance_id, server_id, defer=False):
    """An edge job's start and download (WP1b's split of ``analyze_edges_task``).

    ``(outcome, None)`` when it settled here (None: another worker has the
    job), or ``(None, state)`` with the downloaded file for the analysis and
    ``_finish_edge``. Database and host calls only: the turn's own thread.
    """
    if not update_edge_job(get_db(), catalog_instance_id, job, "running"):
        return None, None
    state = {"job": job, "catalog_instance_id": catalog_instance_id, "info": None}
    try:
        if maintenance_paused() or not edge_profiles_enabled():
            raise ValueError("edge-worker-unavailable")
        info = state["info"] = load_track_file(job["track_id"], catalog_instance_id=catalog_instance_id,
                                               server_id=server_id, **({"defer": True} if defer else {}))
        if not info or opaque_revision(info.get("media_signature")) != job["media_revision"]:
            raise ValueError("edge-source-replaced")
    except Exception as exc:
        return _finish_edge(state, None, exc), None
    # LN.4a: whole-track loudness from the same decode, beside the edge payload.
    state["path"] = info["file_path"]
    state["kwargs"] = {"catalog_instance_id": catalog_instance_id, "track_id": job["track_id"],
                       "media_revision": job["media_revision"]}
    return None, state


def _finish_edge(state, payload, error):
    """Publish an edge (and its loudness) or record its failure, and remove the
    download; the turn's own thread."""
    job, catalog_instance_id, info = state["job"], state["catalog_instance_id"], state["info"]
    try:
        if error is not None:
            raise error
        measured = payload.pop(loudness_v1.LOUDNESS_KEY, None)
        applied = publish_edge_profile(get_db(), catalog_instance_id, job, payload, info["media_signature"])
        if not applied:
            update_edge_job(get_db(), catalog_instance_id, job, "failed", "edge-source-replaced")
        elif measured is not None:
            loudness_stream.store_measurement(get_db(), catalog_instance_id, job["track_id"],
                                              job["media_revision"], measured)
        return {"track_id": job["track_id"], "status": "ready" if applied else "superseded"}
    except Exception as exc:
        rollback = getattr(get_db(), "rollback", None)
        if callable(rollback):
            rollback()
        if is_unsupported_failure(exc):
            # Terminal for this media revision: never retried until it changes.
            update_edge_job(get_db(), catalog_instance_id, job, EDGE_UNSUPPORTED,
                            analysis_isolation.edge_failure_reason(exc))
            return {"track_id": job["track_id"], "status": EDGE_UNSUPPORTED}
        status = fail_edge_job(get_db(), catalog_instance_id, job,
                               analysis_isolation.edge_failure_reason(exc))
        return {"track_id": job["track_id"],
                "status": EDGE_UNSUPPORTED if status == EDGE_UNSUPPORTED else "failed"}
    finally:
        if info:
            remove_downloaded_file(info.get("cleanup_path"))


def _release_edge(state):
    """An edge whose analysis never finished (its pass raised, or Lumae's own
    download was refused): released, due again at once, like a background
    batch's unstarted jobs."""
    try:
        update_edge_job(get_db(), state["catalog_instance_id"], state["job"], "failed", "edge-enqueue-failed")
    finally:
        if state["info"]:
            remove_downloaded_file(state["info"].get("cleanup_path"))


def edge_backfill_task(server_id, catalog_instance_id, deadline=None, shared=False):
    """One library-pass slice: edges for published tracks until the slice's
    deadline, then yield.

    Runs inside a runner turn after the waveform backfill. Analyses one
    track at a time until the slice's ``deadline`` (WP1a; it took a fixed 30 s
    before), reading due tracks a page at a time, serving on-demand work
    between tracks, and keeps its cursor at the last track it reached.
    ``shared`` (multi-worker plan R4): every worker runner walks the pass at
    once, a batch at a time (``_edge_pass_shared``).
    """
    if maintenance_paused():
        return {"status": "paused", "processed": 0}
    if shared:
        return _edge_pass_shared(get_db(), server_id, catalog_instance_id, deadline)
    db = get_db()
    if not edge_profiles_enabled():
        park_edge_backfill(db)
        return {"status": "paused", "reason": "edge_runtime_unavailable", "processed": 0}
    row = edge_backfill_row(db, catalog_instance_id) or {}
    cursor = row.get("cursor") or ""
    started = not cursor
    try:
        ids = edge_backfill_candidates(db, catalog_instance_id, cursor, EDGE_BACKFILL_PAGE_SIZE)
        if not ids:
            update_edge_backfill(db, catalog_instance_id, "complete", cursor="",
                                 next_retry_hours=EDGE_BACKFILL_RESWEEP_HOURS, completed=True)
            return {"status": "complete", "processed": 0}
        update_edge_backfill(db, catalog_instance_id, "running", started=started)
        pass_deadline = _pass_deadline(deadline)
        pool = parallel_analysis.current()
        if pool is not None and pool.parallel:
            return _edge_pass_parallel(pool, db, server_id, catalog_instance_id, cursor, ids, pass_deadline)
        reached, counts = cursor, {}
        while ids:
            for track_id in ids:
                # Before the first track too: production's pass ran 81 s on
                # average against its 30 s (AUD-20).
                remaining = pass_deadline - time.monotonic()
                if remaining <= 0:
                    break
                jobs, _ready = claim_edge_jobs(get_db(), catalog_instance_id, [track_id])
                for outcome in analyze_edges_task(jobs, catalog_instance_id, server_id,
                                                  budget_seconds=remaining):
                    counts[outcome["status"]] = counts.get(outcome["status"], 0) + 1
                reached = track_id
            if reached != ids[-1] or time.monotonic() >= pass_deadline:
                break
            ids = edge_backfill_candidates(get_db(), catalog_instance_id, reached, EDGE_BACKFILL_PAGE_SIZE)
        processed = sum(counts.values())
        if not ids:
            # The walk reached the end inside this turn.
            update_edge_backfill(db, catalog_instance_id, "complete", cursor="", processed=processed,
                                 next_retry_hours=EDGE_BACKFILL_RESWEEP_HOURS, completed=True)
            return {"status": "complete", "processed": processed, **counts}
        update_edge_backfill(db, catalog_instance_id, "queued", cursor=reached, processed=processed)
        return {"status": "queued", "processed": processed, **counts}
    except Exception as exc:
        _rollback_if_possible(db)
        update_edge_backfill(db, catalog_instance_id, "failed", error=exc)
        raise


def _serve_between():
    """A parallel pass serves on-demand work whenever a thread frees (WP1b)."""
    serve_interactive()
    return True


def _paged(first_page, next_page):
    """The units of ``first_page`` then of each ``next_page(last unit)``, read
    lazily on the calling thread until a page comes back empty."""
    page = first_page
    while page:
        yield from page
        page = next_page(page[-1])


def _edge_pass_parallel(pool, db, server_id, catalog_instance_id, cursor, ids, deadline):
    """The edge pass's turn on the runner's K analysis threads (WP1b).

    Each due track is claimed, started and downloaded here, analysed on a
    thread and published here as it completes, serving on-demand work
    whenever a thread frees. A file in flight at the deadline runs to
    completion, as on the serial path. The cursor stays at the last track of
    the unbroken run of finished tracks, so a file cancelled because the pass
    raised (released, due again at once) is reached again next turn.
    """
    counts, limit = {}, analysis_time_limit_seconds()

    def prepare(track_id):
        jobs, _ready = claim_edge_jobs(get_db(), catalog_instance_id, [track_id])
        if not jobs:
            return None
        outcome, state = _prepare_edge(jobs[0], catalog_instance_id, server_id, defer=True)
        if state is None:
            if outcome is not None:
                counts[outcome["status"]] = counts.get(outcome["status"], 0) + 1
            return None
        info, path, kwargs = state["info"], state["path"], state["kwargs"]
        return (lambda: (fetch_track_file(info), run_file_analysis(
            loudness_v1.analyze_edge_file, path, limit_seconds=limit, **kwargs))[1]), state

    def finish(_track_id, state, payload, error):
        if isinstance(error, analysis_download.DownloadError):
            _refuse_own_download(catalog_instance_id, error)
            error = parallel_analysis.Cancelled()
        if isinstance(error, parallel_analysis.Cancelled):
            _release_edge(state)
            counts["released"] = counts.get("released", 0) + 1
            return
        outcome = _finish_edge(state, payload, error)
        counts[outcome["status"]] = counts.get(outcome["status"], 0) + 1

    report_edge_runtime()
    report = parallel_analysis.run(
        _paged(ids, lambda last: edge_backfill_candidates(get_db(), catalog_instance_id, last,
                                                          EDGE_BACKFILL_PAGE_SIZE)),
        prepare, finish, pool=pool, deadline=deadline,
        between=_serve_between)
    processed = sum(counts.values())
    if report.stopped is None and not report.cancelled:
        # The walk reached the end inside this turn.
        update_edge_backfill(db, catalog_instance_id, "complete", cursor="", processed=processed,
                             next_retry_hours=EDGE_BACKFILL_RESWEEP_HOURS, completed=True)
        return {"status": "complete", "processed": processed, **counts}
    reached = report.reached()
    update_edge_backfill(db, catalog_instance_id, "queued", cursor=cursor if reached is None else reached,
                         processed=processed)
    return {"status": "queued", "processed": processed, **counts}


# Multi-worker plan R4: a shared pass takes this many tracks per analysis
# thread at a time, so what a runner hands back at its deadline stays small.
SHARED_BATCH_PER_THREAD = 2
SHARED_BATCH_MAX = 25


def _shared_batch_size(pool):
    workers = pool.workers if pool is not None else 1
    return max(2, min(SHARED_BATCH_MAX, workers * SHARED_BATCH_PER_THREAD))


class _SharedFeed:
    """The units of a shared pass's slice (multi-worker plan R4), a batch at a
    time from ``shared_pass.take`` as the pass needs them; ``why`` says why
    it stopped (``shared_pass.OUT`` or ``ENDED``). The pass calls ``started``
    for each unit it prepares and adds the ones it cancels to ``cancelled``;
    ``close`` ends this slice's batches, handing back every other unit."""

    def __init__(self, pass_name, state_table, catalog_instance_id, size, *, next_units, track_id,
                 refilter, complete):
        self.pass_name, self.state_table = pass_name, state_table
        self.catalog_instance_id, self.size = catalog_instance_id, size
        self.next_units, self.track_id, self.refilter, self.complete = next_units, track_id, refilter, complete
        self.batches = []
        self.taken = set()
        self.cancelled = []
        self.why = None

    def __iter__(self):
        while True:
            db = get_db()
            batch, why = shared_pass.take(
                db, self.pass_name, self.state_table, self.catalog_instance_id, self.size,
                next_units=lambda after, size: self.next_units(db, after, size),
                track_id=self.track_id, refilter=lambda ids: self.refilter(db, ids),
                complete=lambda cur: self.complete(cur, self.catalog_instance_id))
            if batch is None:
                self.why = why
                return
            self.batches.append(batch)
            yield from batch.units

    def started(self, unit):
        """The pass prepares ``unit``: from now on it finishes it or cancels it. (``run`` may draw a
        unit it never starts: its serial path draws the next before it looks at the deadline.)"""
        self.taken.add(self.track_id(unit))

    def close(self):
        """Delete this slice's batches, handing back their unfinished tracks; returns how many."""
        cancelled = {self.track_id(unit) for unit in self.cancelled}
        unfinished = [track for batch in self.batches for track in batch.track_ids
                      if track not in self.taken or track in cancelled]
        db = get_db()
        handed_back = shared_pass.finish(db, self.pass_name, self.state_table, self.catalog_instance_id,
                                         self.batches, unfinished)
        self.batches = []
        if handed_back:
            wake_runners(db, f"{self.pass_name}_batch_handed_back", commit=True)
        return handed_back


def _close_feed(db, feed):
    try:
        feed.close()
    except Exception:
        _rollback_if_possible(db)
        # The batches stay this runner's: once its heartbeat stops another
        # runner takes them over; until then the pass waits for them.
        logger.warning("lumae_analysis could not hand back a shared %s batch", feed.pass_name,
                       exc_info=True)


# Multi-worker plan R4: a waveform analysis also measures its track's edge and
# loudness from the same download, and an edge analysis its loudness. One
# runner walks the passes one after the other. With every runner walking them
# at once, a source's edge and loudness passes wait while its waveform pass has
# tracks due or in flight, and its loudness pass while edge batches are out, so
# no file is fetched twice. A waveform track counts as in flight for a turn and
# its file's time limit after its admission: a runner that went away holds the
# later passes back no longer than that.
EARLIER_PASS_RUNNING = "earlier_pass_running"
PASS_WAIT_SECONDS = 30


def _earlier_pass_running(db, action, server_id, catalog_instance_id):
    """Whether the source's ``action`` pass (edge or loudness) waits for an earlier one."""
    if find_backfill_ids(1, catalog_instance_id=catalog_instance_id, server_id=server_id):
        return True
    with db.cursor() as cur:
        cur.execute(
            f"""SELECT 1 FROM {source_profiles_table()}
                 WHERE catalog_instance_id=%s AND status IN ('pending', 'pending_interactive')
                   AND analyzed_at > now() - make_interval(secs => %s)
                 LIMIT 1""",
            (catalog_instance_id, RUNNER_TURN_SECONDS + analysis_time_limit_seconds()),
        )
        running = cur.fetchone() is not None
    if not running and action == "loudness_backfill":
        running = shared_pass.batches_out(db, "edge", catalog_instance_id) > 0
    db.commit()
    return running


def _edge_pass_shared(db, server_id, catalog_instance_id, deadline):
    """The edge pass's slice when every worker runner walks it (multi-worker
    plan R4), on this turn's analysis threads, a batch at a time.

    A runner without a qualified runtime leaves the pass to those with one;
    the leader parks it only when no runner reported one (R5). A helper
    serves no on-demand work between files (``serve_interactive``).
    """
    if not edge_profiles_enabled():
        if not runner.HELPING.get() and edge_profiles_analyzable(db) is False:
            park_edge_backfill(db)
            return {"status": "paused", "reason": "edge_runtime_unavailable", "processed": 0}
        return {"status": "coalesced", "reason": "edge_runtime_unavailable", "processed": 0}
    if _earlier_pass_running(db, "edge_backfill", server_id, catalog_instance_id):
        return {"status": "coalesced", "reason": EARLIER_PASS_RUNNING, "processed": 0}
    pool = parallel_analysis.current()
    counts, limit = {}, analysis_time_limit_seconds()
    feed = _SharedFeed(
        "edge", table("edge_backfill_state"), catalog_instance_id, _shared_batch_size(pool),
        next_units=lambda conn, after, size: edge_backfill_candidates(conn, catalog_instance_id, after, size),
        track_id=lambda unit: unit,
        refilter=lambda conn, ids: edge_due_among(conn, catalog_instance_id, ids),
        complete=complete_edge_pass_sql)

    def prepare(track_id):
        feed.started(track_id)
        jobs, _ready = claim_edge_jobs(get_db(), catalog_instance_id, [track_id])
        if not jobs:
            return None
        outcome, state = _prepare_edge(jobs[0], catalog_instance_id, server_id, defer=True)
        if state is None:
            if outcome is not None:
                counts[outcome["status"]] = counts.get(outcome["status"], 0) + 1
            return None
        info, path, kwargs = state["info"], state["path"], state["kwargs"]
        return (lambda: (fetch_track_file(info), run_file_analysis(
            loudness_v1.analyze_edge_file, path, limit_seconds=limit, **kwargs))[1]), state

    def finish(track_id, state, payload, error):
        if isinstance(error, analysis_download.DownloadError):
            _refuse_own_download(catalog_instance_id, error)
            error = parallel_analysis.Cancelled()
        if isinstance(error, parallel_analysis.Cancelled):
            _release_edge(state)
            feed.cancelled.append(track_id)
            counts["released"] = counts.get("released", 0) + 1
            return
        outcome = _finish_edge(state, payload, error)
        counts[outcome["status"]] = counts.get(outcome["status"], 0) + 1

    report_edge_runtime(park=False)
    try:
        parallel_analysis.run(iter(feed), prepare, finish, pool=pool, deadline=deadline,
                              between=_serve_between)
    except Exception as exc:
        _rollback_if_possible(db)
        _close_feed(db, feed)
        update_edge_backfill(db, catalog_instance_id, "failed", error=exc)
        raise
    _close_feed(db, feed)
    processed = sum(counts.values())
    shared_pass.end_slice(db, table("edge_backfill_state"), catalog_instance_id, processed)
    if feed.why == shared_pass.ENDED:
        return {"status": "complete", "processed": processed, **counts}
    if feed.why == shared_pass.OUT and not processed:
        # Other runners hold the rest of the pass: nothing for this one now.
        return {"status": "coalesced", "processed": 0}
    return {"status": "queued", "processed": processed, **counts}


def next_loudness_backfill(db, server_id=None, shared=False):
    """``(server_id, catalog_instance_id)`` of the next loudness turn, or None (LN.4c)."""
    return loudness_backfill.next_due(db, server_id=server_id, shared=shared)


def loudness_backfill_task(server_id, catalog_instance_id, deadline=None, shared=False):
    """One loudness turn (LN.4c): follow the published catalogue when its generation moved, then
    measure due tracks on the standalone path until the slice's deadline and yield.

    Measures one track at a time until the slice's ``deadline`` (WP1a; it took a fixed 30 s and one
    page before), reading due tracks a page of the admin batch size at a time, serving on-demand
    work between tracks, publishes each page's measurements together and keeps its cursor at the
    last track it reached. A worker without PyAV parks the pass before downloading. ``shared``
    (multi-worker plan R4): every worker runner walks the pass at once, a batch at a time; a helper
    leaves following the catalogue to the leader.
    """
    if maintenance_paused():
        return {"status": "paused", "processed": 0}
    db = get_db()
    row = loudness_backfill.state(db, catalog_instance_id) or {}
    result = {"status": "current", "processed": 0, "ready": 0, "failed": 0, "reconciled": 0}
    try:
        generation = row.get("published_generation")
        if (generation is not None and generation != row.get("reconciled_generation")
                and not runner.HELPING.get()):
            result["reconciled"] = loudness_backfill.follow_catalogue(db, catalog_instance_id, generation)
        if shared:
            if not row.get("shared_due"):
                return result
            return _loudness_pass_shared(db, server_id, catalog_instance_id, deadline, result)
        if not row.get("pass_due"):
            return result
        if not loudness_backfill.runtime_available():
            # No decoder here: park before downloading anything (a PyAV worker's report resumes it).
            loudness_backfill.park(db, catalog_instance_id)
            return {**result, "status": "paused", "reason": "loudness_runtime_unavailable"}
        cursor = "" if row.get("status") == "complete" else (row.get("cursor") or "")
        page_size = configured_backfill_limit()
        edges_enabled = edge_profiles_enabled()
        due = loudness_backfill.candidates(db, catalog_instance_id, cursor, page_size,
                                           edges_enabled=edges_enabled)
        if not due:
            loudness_backfill.update(db, catalog_instance_id, "complete", cursor="",
                                     next_retry_hours=loudness_backfill.RESWEEP_HOURS, completed=True)
            return {**result, "status": "complete"}
        loudness_backfill.update(db, catalog_instance_id, "running", started=not cursor)
        pass_deadline = _pass_deadline(deadline)
        pool = parallel_analysis.current()
        if pool is not None and pool.parallel:
            return _loudness_pass_parallel(pool, db, server_id, catalog_instance_id, cursor, due, page_size,
                                           edges_enabled, pass_deadline, result)
        reached = cursor
        while due:
            measured = []
            for track_id, media_revision in due:
                serve_interactive()
                if time.monotonic() >= pass_deadline:
                    break
                outcome = _measure_loudness(db, catalog_instance_id, server_id, track_id, media_revision, measured)
                result[outcome] += 1
                reached = track_id
            failed = _publish_loudness(db, catalog_instance_id, measured)
            result["ready"] -= failed
            result["failed"] += failed
            if reached != due[-1][0] or time.monotonic() >= pass_deadline:
                break
            due = loudness_backfill.candidates(db, catalog_instance_id, reached, page_size,
                                               edges_enabled=edges_enabled)
        result["processed"] = result["ready"] + result["failed"]
        if not due:
            # The walk reached the end inside this turn.
            loudness_backfill.update(db, catalog_instance_id, "complete", cursor="", processed=result["processed"],
                                     next_retry_hours=loudness_backfill.RESWEEP_HOURS, completed=True)
            return {**result, "status": "complete"}
        loudness_backfill.update(db, catalog_instance_id, "queued", cursor=reached, processed=result["processed"])
        return {**result, "status": "queued"}
    except Exception as exc:
        _rollback_if_possible(db)
        loudness_backfill.update(db, catalog_instance_id, "failed", error=exc)
        raise


def _measure_loudness(db, catalog_instance_id, server_id, track_id, media_revision, measured):
    """``ready`` (its measurement appended to ``measured``) or ``failed`` for one track: one
    download, one decode."""
    outcome, state = _prepare_loudness(db, catalog_instance_id, server_id, track_id, media_revision)
    if outcome is not None:
        return outcome
    try:
        record, error = run_file_analysis(loudness_v1.measure_file, state["info"]["file_path"]), None
    except Exception as exc:
        record, error = None, exc
    return _finish_loudness(state, record, error, measured)


def _prepare_loudness(db, catalog_instance_id, server_id, track_id, media_revision, defer=False):
    """A loudness measurement's download (WP1b's split of ``_measure_loudness``):
    ``("failed", None)`` or ``(None, state)``; the turn's own thread."""
    state = {"db": db, "catalog_instance_id": catalog_instance_id, "track_id": track_id,
             "media_revision": media_revision, "info": None}
    try:
        info = state["info"] = load_track_file(track_id, catalog_instance_id=catalog_instance_id,
                                               server_id=server_id, **({"defer": True} if defer else {}))
        # Nothing written yet: end the read transaction rather than hold it through the decode.
        db.commit()
        if not info or opaque_revision(info.get("media_signature")) != media_revision:
            raise ValueError("loudness-source-replaced")
    except Exception as exc:
        return _finish_loudness(state, None, exc, None), None
    return None, state


def _finish_loudness(state, record, error, measured):
    """``ready`` (the measurement appended to ``measured``) or ``failed`` (backing off), and the
    download removed; the turn's own thread."""
    db, info = state["db"], state["info"]
    try:
        if error is not None:
            raise error
        measured.append({"track_id": state["track_id"], "media_revision": state["media_revision"],
                         "record": record})
        return "ready"
    except Exception as exc:
        _rollback_if_possible(db)
        loudness_backfill.record_failure(db, state["catalog_instance_id"], state["track_id"],
                                         state["media_revision"], analysis_isolation.edge_failure_reason(exc),
                                         unsupported=is_unsupported_failure(exc))
        return "failed"
    finally:
        if info:
            remove_downloaded_file(info.get("cleanup_path"))


def _loudness_pass_parallel(pool, db, server_id, catalog_instance_id, cursor, due, page_size,
                            edges_enabled, deadline, result):
    """The loudness turn on the turn's K analysis threads (WP1b).

    Downloads and publication stay here; a page of measurements (the admin
    batch size) is published together as it fills. A file in flight at the
    deadline runs to completion, as on the serial path; one cancelled because
    the pass raised is not counted and keeps the cursor before it.
    """
    measured, limit = [], analysis_time_limit_seconds()

    def prepare(item):
        track_id, media_revision = item
        outcome, state = _prepare_loudness(db, catalog_instance_id, server_id, track_id, media_revision,
                                           defer=True)
        if state is None:
            result[outcome] += 1
            return None
        info = state["info"]
        return (lambda: (fetch_track_file(info), run_file_analysis(
            loudness_v1.measure_file, info["file_path"], limit_seconds=limit))[1]), state

    def publish():
        failed = _publish_loudness(db, catalog_instance_id, measured)
        result["ready"] -= failed
        result["failed"] += failed
        measured.clear()

    def finish(_item, state, record, error):
        if isinstance(error, analysis_download.DownloadError):
            _refuse_own_download(catalog_instance_id, error)
            error = parallel_analysis.Cancelled()
        if isinstance(error, parallel_analysis.Cancelled):
            if state["info"]:
                remove_downloaded_file(state["info"].get("cleanup_path"))
            return
        result[_finish_loudness(state, record, error, measured)] += 1
        if len(measured) >= page_size:
            publish()

    report = parallel_analysis.run(
        _paged(due, lambda last: loudness_backfill.candidates(db, catalog_instance_id, last[0], page_size,
                                                              edges_enabled=edges_enabled)),
        prepare, finish, pool=pool, deadline=deadline, between=_serve_between)
    publish()
    result["processed"] = result["ready"] + result["failed"]
    if report.stopped is None and not report.cancelled:
        # The walk reached the end inside this turn.
        loudness_backfill.update(db, catalog_instance_id, "complete", cursor="", processed=result["processed"],
                                 next_retry_hours=loudness_backfill.RESWEEP_HOURS, completed=True)
        return {**result, "status": "complete"}
    reached = report.reached()
    loudness_backfill.update(db, catalog_instance_id, "queued", cursor=cursor if reached is None else reached[0],
                             processed=result["processed"])
    return {**result, "status": "queued"}


def _loudness_pass_shared(db, server_id, catalog_instance_id, deadline, result):
    """The loudness pass's slice when every worker runner walks it (multi-worker plan R4), on this
    turn's analysis threads, a batch at a time; measurements are published a page (the admin batch
    size) at a time as on the walk. A runner without PyAV leaves the pass to those with it; the
    leader parks it only when no runner reported PyAV (R5)."""
    if not loudness_backfill.runtime_available():
        if not runner.HELPING.get() and not pyav_reported(db):
            loudness_backfill.park(db, catalog_instance_id)
            return {**result, "status": "paused", "reason": "loudness_runtime_unavailable"}
        return {**result, "status": "coalesced", "reason": "loudness_runtime_unavailable"}
    if _earlier_pass_running(db, "loudness_backfill", server_id, catalog_instance_id):
        return {**result, "status": "coalesced", "reason": EARLIER_PASS_RUNNING}
    pool = parallel_analysis.current()
    page_size = configured_backfill_limit()
    # A track waits for the edge pass when any runner makes edges, not only this one.
    edges_enabled = edge_profiles_enabled() or (
        edge_setting_enabled() and edge_profiles_analyzable(db) is True)
    measured, limit = [], analysis_time_limit_seconds()
    feed = _SharedFeed(
        "loudness", table("loudness_backfill_state"), catalog_instance_id, _shared_batch_size(pool),
        next_units=lambda conn, after, size: loudness_backfill.candidates(
            conn, catalog_instance_id, after, size, edges_enabled=edges_enabled),
        track_id=lambda unit: unit[0],
        refilter=lambda conn, ids: loudness_backfill.due_among(
            conn, catalog_instance_id, ids, edges_enabled=edges_enabled),
        complete=loudness_backfill.complete_sql)

    def prepare(item):
        feed.started(item)
        track_id, media_revision = item
        outcome, state = _prepare_loudness(db, catalog_instance_id, server_id, track_id,
                                           media_revision, defer=True)
        if state is None:
            result[outcome] += 1
            return None
        info = state["info"]
        return (lambda: (fetch_track_file(info), run_file_analysis(
            loudness_v1.measure_file, info["file_path"], limit_seconds=limit))[1]), state

    def publish():
        failed = _publish_loudness(db, catalog_instance_id, measured)
        result["ready"] -= failed
        result["failed"] += failed
        measured.clear()

    def finish(item, state, record, error):
        if isinstance(error, analysis_download.DownloadError):
            _refuse_own_download(catalog_instance_id, error)
            error = parallel_analysis.Cancelled()
        if isinstance(error, parallel_analysis.Cancelled):
            if state["info"]:
                remove_downloaded_file(state["info"].get("cleanup_path"))
            feed.cancelled.append(item)
            return
        result[_finish_loudness(state, record, error, measured)] += 1
        if len(measured) >= page_size:
            publish()

    try:
        parallel_analysis.run(iter(feed), prepare, finish, pool=pool, deadline=deadline,
                              between=_serve_between)
        publish()
    except Exception as exc:
        _rollback_if_possible(db)
        _close_feed(db, feed)
        loudness_backfill.update(db, catalog_instance_id, "failed", error=exc)
        raise
    _close_feed(db, feed)
    result["processed"] = result["ready"] + result["failed"]
    shared_pass.end_slice(db, table("loudness_backfill_state"), catalog_instance_id, result["processed"])
    if feed.why == shared_pass.ENDED:
        return {**result, "status": "complete"}
    if feed.why == shared_pass.OUT and not result["processed"]:
        return {**result, "status": "coalesced"}
    return {**result, "status": "queued"}


def _publish_loudness(db, catalog_instance_id, measured):
    """Publish a turn's measurements in one transaction; returns how many failed. Should the batch
    fail, each is published alone, and one that still fails backs off like a failed measurement."""
    if not measured:
        return 0
    cur = db.cursor()
    try:
        loudness_stream.publish_tracks(cur, catalog_instance_id, measured)
        loudness_backfill.clear_failures(cur, catalog_instance_id, [item["track_id"] for item in measured])
        db.commit()
        return 0
    except Exception:  # noqa: BLE001 - fall back to one publication per track
        logger.exception("lumae_analysis loudness batch publication failed; publishing one at a time")
        _rollback_if_possible(db)
    finally:
        cur.close()
    failed = 0
    for item in measured:
        if loudness_stream.store_measurement(db, catalog_instance_id, item["track_id"], item["media_revision"],
                                             item["record"]):
            with db.cursor() as cleared:
                loudness_backfill.clear_failures(cleared, catalog_instance_id, [item["track_id"]])
            db.commit()
        else:
            failed += 1
            loudness_backfill.record_failure(db, catalog_instance_id, item["track_id"], item["media_revision"],
                                             "loudness-publication-failed")
    return failed


def serve_interactive(limit=None):
    """Serve on-demand work recorded for the runners; returns tracks served.

    First in every runner pass, and between the files of a library pass, so
    a request waits about one file. Waveform first, then edges. Never raises.
    A helper serves none (multi-worker plan R1): the on-demand claims are the
    role's, and the leader serves them between its own files.
    """
    global _serving_interactive
    if _serving_interactive or runner.HELPING.get() or maintenance_paused():
        return 0
    limit = limit or INTERACTIVE_PROFILE_CHUNK_SIZE
    _serving_interactive = True
    served = 0
    db = None
    try:
        db = get_db()
        by_source = {}
        for source, track_id, token in claim_waiting_profiles(db, limit):
            by_source.setdefault(source, {})[track_id] = token
        for source, tokens in by_source.items():
            server = resolve_profile_source(catalog_instance_id=source)["server_id"]
            analyze_tracks_task(list(tokens), catalog_instance_id=source, server_id=server,
                                priority="interactive", attempt_tokens=tokens)
            served += len(tokens)
        if edge_profiles_enabled():
            by_source = {}
            for job in claim_waiting_edge_jobs(db, WAITING_MARKERS, limit, runner_claim_marker()):
                by_source.setdefault(job.pop("catalog_instance_id"), []).append(job)
            for source, jobs in by_source.items():
                server = resolve_profile_source(catalog_instance_id=source)["server_id"]
                analyze_edges_task(jobs, source, server, "interactive")
                served += len(jobs)
    except Exception:
        if db is not None:
            _rollback_if_possible(db)
        logger.exception("lumae_analysis could not serve on-demand work")
    finally:
        _serving_interactive = False
    return served


_serving_interactive = False


def claim_waiting_profiles(db, limit):
    """Take on-demand waveform attempts waiting for a runner, oldest first:
    (source, track, token), marked with the runner's claim marker."""
    cur = db.cursor()
    cur.execute(
        f"""UPDATE {source_profiles_table()} p SET last_error=%s
              FROM (SELECT catalog_instance_id, track_id FROM {source_profiles_table()}
                     WHERE status='pending_interactive' AND last_error IN (%s, %s)
                       AND attempt_token IS NOT NULL
                     ORDER BY analyzed_at, track_id LIMIT %s FOR UPDATE SKIP LOCKED) d
             WHERE p.catalog_instance_id=d.catalog_instance_id AND p.track_id=d.track_id
         RETURNING p.catalog_instance_id, p.track_id, p.attempt_token""",
        (runner_claim_marker(), *WAITING_MARKERS, int(limit)),
    )
    rows = cur.fetchall()
    db.commit()
    cur.close()
    return [(row[0], row[1], row[2]) for row in rows]


def mark_profiles_waiting(db, catalog_instance_id, tokens):
    """Mark on-demand attempts as waiting for a runner (R6)."""
    cur = db.cursor()
    for track_id, token in tokens.items():
        cur.execute(
            f"""UPDATE {source_profiles_table()} SET last_error=%s
                 WHERE catalog_instance_id=%s AND track_id=%s AND attempt_token=%s
                   AND status='pending_interactive'""",
            (RUNNER_WAITING_MARKER, catalog_instance_id, track_id, token),
        )
    db.commit()
    cur.close()


def release_runner_claims(db, role, gone_for_seconds=None):
    """The on-demand work ``role``'s runner took, waveform attempts and edge
    jobs, started or not, waits again for whichever runner serves on-demand
    work now: that runner went away before finishing it (R6). With
    ``gone_for_seconds``, only while the role's heartbeat is older. One
    statement; returns how many."""
    cur = db.cursor()
    try:
        cur.execute(
            f"""
            WITH gone AS (
                SELECT 1 WHERE %(seconds)s::float IS NULL OR NOT EXISTS (
                    SELECT 1 FROM {runner.state_table()}
                     WHERE role=%(role)s
                       AND heartbeat_at > now() - make_interval(secs => %(seconds)s::float))
            ), profiles AS (
                UPDATE {source_profiles_table()} SET last_error=%(waiting)s
                 WHERE status='pending_interactive' AND attempt_token IS NOT NULL
                   AND last_error=%(claimed)s AND EXISTS (SELECT 1 FROM gone)
                RETURNING 1
            ), edges AS (
                UPDATE {table('edge_profile_jobs')}
                   SET status='pending', last_error=%(waiting)s, updated_at=now()
                 WHERE status IN ('pending', 'running') AND priority='interactive'
                   AND last_error=%(claimed)s AND EXISTS (SELECT 1 FROM gone)
                RETURNING 1
            )
            SELECT (SELECT count(*) FROM profiles) + (SELECT count(*) FROM edges)
            """,
            {"seconds": gone_for_seconds, "role": role, "waiting": RUNNER_WAITING_MARKER,
             "claimed": RUNNER_CLAIM_MARKERS[role]},
        )
        released = int(cur.fetchone()[0] or 0)
    finally:
        cur.close()
    if released:
        wake_runners(db, "runner_claims_released")
    db.commit()
    return released


def _safe_release_runner_claims(db, role, gone_for_seconds=None):
    try:
        released = release_runner_claims(db, role, gone_for_seconds)
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis could not release the on-demand work of a runner "
                       "that went away", exc_info=True)
        return 0
    if released:
        logger.info("lumae_analysis: %d on-demand items the %s runner took wait again",
                    released, role)
    return released


def interactive_demand_pending(db):
    """Whether on-demand waveform or edge work is waiting (credits and metadata yield)."""
    cur = db.cursor()
    cur.execute(
        f"""SELECT EXISTS(SELECT 1 FROM {source_profiles_table()} WHERE status='pending_interactive')
                OR EXISTS(SELECT 1 FROM {table('edge_profile_jobs')}
                           WHERE status='pending' AND priority='interactive')"""
    )
    row = cur.fetchone()
    cur.close()
    return bool(row and row[0])


def analyze_one_track(track_id, catalog_instance_id=None, server_id=None,
                      attempt_token=None, priority="background"):
    outcome, state = _prepare_track(track_id, catalog_instance_id, server_id, attempt_token, priority)
    if outcome is not None:
        return outcome
    try:
        result, error = _analyse_track_file(state), None
    except Exception as exc:
        result, error = None, exc
    return _finish_track(state, result, error)


def _bundle_edges(signature):
    """Whether a waveform analysis also makes the track's edge and loudness
    in the same child call (WP2): edges are on and schedulable, and the
    catalogue gives the media its revision."""
    try:
        return bool(opaque_revision(signature)) and edge_profiles_enabled() and edge_scheduling_allowed()
    except Exception:
        return False


def _analyse_track_file(state, limit_seconds=None):
    """The analysis child call for a waveform's state (any thread: settings
    are read only when ``limit_seconds`` is None, on the turn's thread).

    With ``state["bundle"]`` one call makes the waveform, the edge and its
    loudness (``analysis_bundle``), each analysis with the per-file limit.
    """
    path = state["info"]["file_path"]
    limit = {} if limit_seconds is None else {"limit_seconds": limit_seconds}
    if not state.get("bundle"):
        return run_file_analysis(analyze_file, path, **limit)
    per_file = analysis_time_limit_seconds() if limit_seconds is None else limit_seconds
    return run_file_analysis(
        analysis_bundle.analyze_track, path, limit_seconds=analysis_bundle.limit_for(True, per_file),
        edge=True, catalog_instance_id=state["catalog_instance_id"], track_id=state["track_id"],
        media_revision=opaque_revision(state["info"]["media_signature"]))


def _prepare_track(track_id, catalog_instance_id, server_id, attempt_token, priority, defer=False):
    """A waveform's claim and download (WP1b's split of ``analyze_one_track``).

    ``(outcome, None)`` when it settled here, or ``(None, state)`` with the
    downloaded file for the analysis and ``_finish_track``. Database and host
    calls only: it runs on the turn's own thread. ``defer``: an analysis
    thread fetches the file (``fetch_track_file``).
    """
    if maintenance_paused():
        release_pending(
            [track_id], catalog_instance_id=catalog_instance_id,
            reason="Lumae background maintenance is paused",
            tokens={track_id: attempt_token} if attempt_token else None,
            count_failure=False,
        )
        return {"track_id": track_id, "status": "skipped_maintenance_paused"}, None
    if catalog_instance_id and not attempt_token:
        return {"track_id": track_id, "status": "superseded"}, None

    def complete(result, status, error=None, media_sig=None, failure_code=None,
                 diagnostics=None):
        applied = upsert_profile(
            track_id, result, status, error, media_sig,
            catalog_instance_id=catalog_instance_id,
            attempt_token=attempt_token,
            **({"failure_code": failure_code} if failure_code else {}),
            **({"diagnostics": diagnostics} if diagnostics else {}),
        )
        return {"track_id": track_id, "status": status if applied else "superseded"}

    try:
        info = load_track_file(
            track_id, catalog_instance_id=catalog_instance_id, server_id=server_id,
            **({"defer": True} if defer else {}),
        )
    except MediaDownloadError as exc:
        return complete(object(), "failed", str(exc), failure_code="download_unavailable"), None
    if info is None:
        return complete(object(), "skipped_no_file", "missing file path", failure_code="media_unavailable"), None
    state = {"track_id": track_id, "catalog_instance_id": catalog_instance_id, "server_id": server_id,
             "attempt_token": attempt_token, "priority": priority, "info": info, "complete": complete,
             "bundle": bool(catalog_instance_id) and _bundle_edges(info.get("media_signature"))}
    if info.get("download") is not None:
        return None, state  # tags are read once the thread has fetched the file
    try:
        # JF.10: a Jellyfin track's tags, read from the downloaded original.
        file_tags.capture(get_db(), catalog_instance_id, track_id, info["file_path"])
    except Exception as exc:
        return _finish_track(state, None, exc), None
    return None, state


def _finish_track(state, result, error):
    """Publish a waveform analysis (or its failure) and remove the download;
    the turn's own thread."""
    track_id, info, complete = state["track_id"], state["info"], state["complete"]
    catalog_instance_id = state["catalog_instance_id"]
    try:
        if error is not None:
            raise error
        answer = None
        if state.get("bundle"):
            answer, result = result, analysis_bundle.part_value(result["waveform"])
        if info.get("download") is not None:
            # JF.10: the tags of the file the analysis thread fetched.
            file_tags.capture(get_db(), catalog_instance_id, track_id, info["file_path"])
        outcome = complete(result, "ready", media_sig=info["media_signature"])
        if outcome["status"] == "ready":
            if answer is not None:
                # WP2: the edge and its loudness came from the same call, on demand too:
                # no edge task per track and no second download.
                _publish_bundle_edge(track_id, catalog_instance_id, info["media_signature"], answer)
            else:
                _leave_edge_to_pass(track_id, catalog_instance_id)
        return outcome
    except Exception as exc:
        code = analysis_failure_code(track_id, exc)
        return complete(object(), "failed", str(exc), info["media_signature"], code,
                        analysis_isolation.failure_diagnostics(exc))
    finally:
        remove_downloaded_file(info.get("cleanup_path"))


def _publish_bundle_edge(track_id, catalog_instance_id, signature, answer):
    """Publish the edge (and loudness) a bundled analysis made, after its
    waveform was published (WP2). Never raises: the waveform stands, and the
    edge pass or the loudness backfill covers what this could not publish.

    The edge job is claimed now (it needs the published waveform). No job:
    the edge is current or another worker has it. A refused edge is marked
    unsupported and the standalone meter's loudness published; any other
    edge failure backs off as in the edge pass.
    """
    edge = answer.get("edge")
    if edge is None:
        _leave_edge_to_pass(track_id, catalog_instance_id)
        return
    db = None
    try:
        db = get_db()
        jobs, _ready = claim_edge_jobs(db, catalog_instance_id, [track_id])
        if not jobs:
            return
        job = jobs[0]
        if job["media_revision"] != opaque_revision(signature):
            update_edge_job(db, catalog_instance_id, job, "failed", "edge-enqueue-failed")
            return
        if not update_edge_job(db, catalog_instance_id, job, "running"):
            return
        try:
            payload, error = analysis_bundle.part_value(edge), None
        except analysis_isolation.IsolatedAnalysisError as exc:
            payload, error = None, exc
        _finish_edge({"job": job, "catalog_instance_id": catalog_instance_id,
                      "info": {"media_signature": signature}}, payload, error)
        if error is not None and answer.get("loudness") is not None:
            try:
                record = analysis_bundle.part_value(answer["loudness"])
            except analysis_isolation.IsolatedAnalysisError:
                return  # the backfill measures it again
            loudness_stream.store_measurement(get_db(), catalog_instance_id, track_id,
                                              job["media_revision"], record)
    except Exception:
        if db is not None:
            _rollback_if_possible(db)
        logger.exception("lumae_analysis could not publish the edge analysed with %s", track_id)


def _release_track(state, reason):
    """A waveform whose analysis never finished (its batch raised, or Lumae's
    own download was refused): released uncounted, due again at once."""
    try:
        release_pending([state["track_id"]], catalog_instance_id=state["catalog_instance_id"], reason=reason,
                        tokens={state["track_id"]: state["attempt_token"]} if state["attempt_token"] else None,
                        count_failure=False)
    finally:
        remove_downloaded_file(state["info"].get("cleanup_path"))


def hook_track_id(song):
    song = song or {}
    media_item = song.get("media_item") or {}
    track_id = song.get("item_id") or media_item.get("Id") or media_item.get("id")
    return str(track_id) if track_id else ""


def hook_source_path(song):
    song = song or {}
    media_item = song.get("media_item") or {}
    metadata = song.get("metadata") or {}
    return (
        media_item.get("FilePath")
        or media_item.get("Path")
        or media_item.get("path")
        or metadata.get("file_path")
        or ""
    )


def hook_media_signature(song, audio_path):
    track_id = hook_track_id(song)
    source_path = hook_source_path(song)
    audio_sig = media_signature(audio_path) or ""
    return f"analysis-hook|{track_id}|{source_path}|{audio_sig}"


def catalog_media_signature(track_id, server_id=None, catalog_instance_id=None):
    db = get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT t.media_fp
          FROM {table('catalog_sources')} s
          JOIN {table('catalog_state')} c USING (catalog_instance_id)
          JOIN {table('catalog_tracks')} t
            ON t.catalog_instance_id=s.catalog_instance_id
           AND t.published_generation=c.published_generation
         WHERE t.track_id=%s AND t.available=TRUE AND s.rebind_status='active'
           AND (%s IS NULL OR s.current_core_server_id=%s)
           AND (%s IS NULL OR s.catalog_instance_id=%s)
         ORDER BY s.is_default DESC LIMIT 1
        """,
        (track_id, server_id, server_id, catalog_instance_id, catalog_instance_id),
    )
    row = cur.fetchone()
    cur.close()
    return f"catalog-media:{row[0]}" if row and row[0] else None


def update_analysis_run(
    catalog_instance_id,
    run_id,
    status,
    *,
    finalizer_job_id=None,
    queued_profiles=None,
    profile_jobs=None,
    last_error=None,
    completed=False,
    db=None,
):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        UPDATE {analysis_runs_table()}
           SET status=%s,
               finalizer_job_id=COALESCE(%s, finalizer_job_id),
               queued_profiles=COALESCE(%s, queued_profiles),
               profile_jobs=COALESCE(%s, profile_jobs),
               last_error=%s,
               started_at=CASE WHEN %s='running' THEN COALESCE(started_at, now()) ELSE started_at END,
               completed_at=CASE WHEN %s THEN now() ELSE completed_at END,
               updated_at=now()
         WHERE catalog_instance_id=%s AND run_id=%s
        """,
        (
            status,
            finalizer_job_id,
            queued_profiles,
            profile_jobs,
            str(last_error)[:2000] if last_error else None,
            status,
            bool(completed),
            catalog_instance_id,
            run_id,
        ),
    )
    db.commit()
    cur.close()


def record_analysis_run(server_id, catalog_instance_id, run_id, db=None):
    """Count a hook and durably request reconciliation after its parent settles."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {analysis_runs_table()}
            (catalog_instance_id, run_id, server_id, status, songs_seen,
             first_seen_at, last_seen_at, updated_at)
        VALUES (%s, %s, %s, 'pending', 1, now(), now(), now())
        ON CONFLICT (catalog_instance_id, run_id) DO UPDATE SET
            server_id=EXCLUDED.server_id,
            songs_seen={analysis_runs_table()}.songs_seen + 1,
            last_seen_at=now(),
            status=CASE
                WHEN {analysis_runs_table()}.status IN ('running', 'complete')
                    THEN {analysis_runs_table()}.status
                ELSE 'pending'
            END,
            finalizer_job_id=CASE
                WHEN {analysis_runs_table()}.status IN ('running', 'complete')
                    THEN {analysis_runs_table()}.finalizer_job_id
                ELSE NULL
            END,
            last_error=CASE
                WHEN {analysis_runs_table()}.status IN ('running', 'complete')
                    THEN {analysis_runs_table()}.last_error
                ELSE NULL
            END,
            retry_count=CASE
                WHEN {analysis_runs_table()}.status IN ('running', 'complete')
                    THEN {analysis_runs_table()}.retry_count
                ELSE 0
            END,
            next_retry_at=CASE
                WHEN {analysis_runs_table()}.status IN ('running', 'complete')
                    THEN {analysis_runs_table()}.next_retry_at
                ELSE NULL
            END,
            updated_at=now()
        RETURNING status, songs_seen
        """,
        (catalog_instance_id, run_id, server_id),
    )
    row = cur.fetchone()
    if not row or int(row[1] or 0) <= 1:
        # A new run wakes the runners once; they follow it until it settles
        # (R7), so the songs after it send no wake each.
        wake_runners(db, "analysis_hook")
    db.commit()
    cur.close()
    return {
        "queued": False,
        "coalesced": bool(row and int(row[1] or 0) > 1),
        "status": str(row[0]) if row else "pending",
    }


def claim_analysis_run(catalog_instance_id, run_id, finalizer_job_id=None, db=None):
    del finalizer_job_id
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        UPDATE {analysis_runs_table()}
           SET status='running', started_at=COALESCE(started_at, now()),
               last_error=NULL, next_retry_at=NULL, updated_at=now()
         WHERE catalog_instance_id=%s AND run_id=%s
           AND (status IN ('pending', 'registering', 'queued',
                           'enqueue_failed', 'failed')
                OR (status='running' AND updated_at
                    < now() - interval '{ANALYSIS_RUN_STALE_MINUTES} minutes'))
        RETURNING songs_seen
        """,
        (catalog_instance_id, run_id),
    )
    row = cur.fetchone()
    db.commit()
    cur.close()
    return int(row[0] or 0) if row else None


def finalize_analysis_run_task(server_id, catalog_instance_id, run_id):
    """Publish one complete source update after an AudioMuse analysis run settles."""
    if maintenance_paused():
        return {
            "status": "paused",
            "reason": "maintenance_paused",
            "run_id": run_id,
        }
    songs_seen = claim_analysis_run(catalog_instance_id, run_id)
    if songs_seen is None:
        return {"status": "already_finalized", "run_id": run_id}
    try:
        _safe_progress("refreshing catalogue")
        source = resolve_profile_source(
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
        )
        if source["catalog_instance_id"] != catalog_instance_id:
            raise CatalogScanError("Catalogue identity changed before run finalization")
        started = _safe_catalog_refresh_clock()
        catalog_result = refresh_catalog(server_id=server_id)
        if catalog_result["catalog_instance_id"] != catalog_instance_id:
            raise CatalogScanError("Catalogue identity changed during run finalization")
        _satisfy_catalog_refresh_wants(catalog_instance_id, started)
        _safe_progress("projecting AudioMuse analysis")
        projection_result = project_analysis(
            server_id=server_id,
            adapter=get_core_adapter(),
        )
        if projection_result["catalog_instance_id"] != catalog_instance_id:
            raise CatalogScanError("Analysis identity changed during run finalization")
        _safe_progress("admitting volume and ramp work")
        profile_result = start_profile_backfill(
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
        )
        try:
            _safe_progress("admitting relationship work")
            relationship_result = start_relationship_preparation(
                catalog_instance_id=catalog_instance_id,
                server_id=server_id,
            )
        except Exception as exc:
            logger.exception(
                "lumae_analysis could not start relationship enrichment after analysis"
            )
            relationship_result = {
                "queued": False,
                "coalesced": False,
                "error": str(exc),
            }
        update_analysis_run(
            catalog_instance_id,
            run_id,
            "complete",
            queued_profiles=(profile_result["batch_size"] if profile_result["queued"] else 0),
            profile_jobs=(
                1
                if profile_result["queued"] and not profile_result.get("deferred")
                else 0
            ),
            completed=True,
        )
        return {
            "status": "complete",
            "run_id": run_id,
            "songs_seen": songs_seen,
            "catalog": catalog_result,
            "analysis": projection_result,
            "profiles": profile_result,
            "relationships": relationship_result,
        }
    except Exception as exc:
        update_analysis_run(
            catalog_instance_id,
            run_id,
            "failed",
            last_error=exc,
        )
        raise


def analyze_song_hook(song):
    """AudioMuse per-song hook. It records the analysis run, which wakes the
    runners (R7); they serve on-demand work, analysis or not."""
    return _analyze_song_hook(song)


def _analyze_song_hook(song):
    event = {}
    source_server_id = None
    catalog_instance_id = None
    try:
        event = get_core_adapter().normalize_analysis_hook(song)
        source_server_id = event["server_id"]
        catalog_instance_id = resolve_profile_source(server_id=source_server_id)[
            "catalog_instance_id"
        ]
    except Exception:
        logger.exception("lumae_analysis could not resolve the analysis source")
    if catalog_instance_id and maintenance_paused():
        return {"track_id": hook_track_id(song), "status": "skipped_maintenance_paused"}
    if catalog_instance_id:
        run_id = str((event or {}).get("run_id") or "").strip()
        if run_id:
            try:
                record_analysis_run(source_server_id, catalog_instance_id, run_id)
            except Exception:
                logger.exception(
                    "lumae_analysis could not record source finalization for run %s",
                    run_id,
                )
        else:
            logger.warning("lumae_analysis analysis hook did not include run_id")
    track_id = hook_track_id(song)
    if not track_id:
        logger.warning("lumae_analysis song hook skipped payload without item_id")
        return {"track_id": "", "status": "skipped_no_file"}
    if not catalog_instance_id:
        logger.warning("lumae_analysis song hook skipped %s without an exact source", track_id)
        return {"track_id": track_id, "status": "skipped_source_unresolved"}
    # JF.10: AudioMuse holds the original file now; keep a Jellyfin track's
    # tags (a no-op for any other source).
    hook_audio_path = (song or {}).get("audio_path")
    if hook_audio_path and os.path.exists(hook_audio_path):
        file_tags.capture(get_db(), catalog_instance_id, track_id, hook_audio_path)
    # An AudioMuse re-analysis pass fires this hook for every song. A current
    # published profile needs no new attempt (AUD-03); changed media, a new
    # analyzer or schema, and failed rows still requalify (LUM-007).
    if published_profile_current(
        get_db(), catalog_instance_id, track_id, ANALYZER_VERSION, SCHEMA_VERSION
    ):
        # Still heal a missing edge; a current edge makes this a no-op.
        _leave_edge_to_pass(track_id, catalog_instance_id)
        return {"track_id": track_id, "status": "current"}
    tokens = mark_pending([track_id], catalog_instance_id, priority="interactive")
    token = tokens.get(track_id)
    if not token:
        return {"track_id": track_id, "status": "skipped_source_unresolved"}
    audio_path = (song or {}).get("audio_path")
    media_sig = catalog_media_signature(
        track_id, source_server_id, catalog_instance_id=catalog_instance_id
    )

    def complete(result, status, error=None, failure_code=None, diagnostics=None):
        applied = upsert_profile(
            track_id, result, status, error, media_sig,
            catalog_instance_id=catalog_instance_id, attempt_token=token,
            **({"failure_code": failure_code} if failure_code else {}),
            **({"diagnostics": diagnostics} if diagnostics else {}),
        )
        # An AudioMuse run completes profiles song by song. Keep the settings
        # counts moving without counting the library for every song (P2-1).
        refresh_status_snapshot(
            catalog_instance_id=catalog_instance_id,
            min_age_seconds=status_model.PROFILE_COUNTS_MIN_AGE_SECONDS,
        )
        return {"track_id": track_id, "status": status if applied else "superseded"}

    if not audio_path or not os.path.exists(audio_path):
        return complete(object(), "skipped_no_file", "missing analysis audio path", "media_unavailable")
    # WP2: the edge and its loudness from the hook's own file, in the same child call.
    bundle = _bundle_edges(media_sig)
    try:
        if bundle:
            answer = run_file_analysis(
                analysis_bundle.analyze_track, audio_path,
                limit_seconds=analysis_bundle.limit_for(True, analysis_time_limit_seconds()),
                edge=True, catalog_instance_id=catalog_instance_id, track_id=track_id,
                media_revision=opaque_revision(media_sig))
            result = analysis_bundle.part_value(answer["waveform"])
        else:
            result = run_file_analysis(analyze_file, audio_path)
        outcome = complete(result, "ready")
        if outcome["status"] == "ready":
            if bundle:
                _publish_bundle_edge(track_id, catalog_instance_id, media_sig, answer)
            else:
                _leave_edge_to_pass(track_id, catalog_instance_id)
        return outcome
    except Exception as exc:
        code = analysis_failure_code(track_id, exc, "hook failed")
        return complete(object(), "failed", str(exc), code,
                        analysis_isolation.failure_diagnostics(exc))


def profile_task_disposition(track_id, catalog_instance_id=None, server_id=None, priority="background"):
    rows = fetch_profile_rows([track_id], catalog_instance_id=catalog_instance_id)
    row = rows[0] if rows else None
    if not row:
        return "analyze"
    if priority != "interactive" and row.get("status") == "pending_interactive":
        return "promoted"
    if row.get("status") != "ready" or int(row.get("analyzer_ver") or 0) < ANALYZER_VERSION:
        return "analyze"
    expected_signature = catalog_media_signature(
        track_id, server_id, catalog_instance_id=catalog_instance_id
    )
    stored_signature = row.get("media_signature")
    if expected_signature and stored_signature != expected_signature:
        return "analyze"
    return "already_ready"


def analyze_tracks_task(
    ids,
    catalog_instance_id=None,
    server_id=None,
    priority="background",
    attempt_tokens=None,
    deadline=None,
):
    """``deadline``: a runner slice's (``time.monotonic()``); no track starts
    after it, and the unstarted ones are released uncounted (plan S2).

    Inside a runner turn with K analysis threads (WP1b) a background batch analyses
    K files at once (``_analyze_tracks_parallel``)."""
    ids = parse_ids(",".join(ids or []))
    if maintenance_paused():
        release_pending(
            ids,
            catalog_instance_id=catalog_instance_id,
            reason="Lumae background maintenance is paused",
            tokens=attempt_tokens,
            count_failure=False,
        )
        return {
            "attempted": 0,
            "ready": 0,
            "already_ready": 0,
            "promoted": 0,
            "failed": 0,
            "skipped": len(ids),
            "deferred": len(ids),
            "paused": True,
        }
    if catalog_instance_id and not attempt_tokens:
        # Persisted jobs from before token admission cannot publish or release.
        return {
            "attempted": 0, "ready": 0, "already_ready": 0,
            "promoted": 0, "failed": 0, "skipped": len(ids),
            "deferred": len(ids), "superseded": len(ids),
        }

    pool = parallel_analysis.current() if priority == "background" else None
    if pool is not None and not pool.parallel:
        pool = None
    if priority == "background" and len(ids) > MAX_BACKFILL_BATCH_SIZE * (pool.workers if pool else 1):
        # Drain 0.8.0's already-persisted 250-track RQ jobs quickly after an
        # upgrade. Their rows become retryable and one bounded chain owns the
        # remaining durable work; interactive requests can promote any of them now.
        release_pending(
            ids,
            catalog_instance_id=catalog_instance_id,
            reason="Migrated to bounded 0.8.1 background enrichment",
            tokens=attempt_tokens,
            count_failure=False,
        )
        if catalog_instance_id or server_id:
            try:
                start_profile_backfill(
                    catalog_instance_id=catalog_instance_id,
                    server_id=server_id,
                )
            except Exception:
                logger.exception("lumae_analysis could not migrate a legacy backfill job")
        return {
            "attempted": 0,
            "ready": 0,
            "already_ready": 0,
            "promoted": 0,
            "failed": 0,
            "skipped": 0,
            "deferred": len(ids),
        }
    if pool is not None:
        results, attempted = _analyze_tracks_parallel(pool, ids, catalog_instance_id, server_id,
                                                      attempt_tokens, deadline)
        return _tracks_summary(results, attempted, catalog_instance_id, priority)
    results = []
    attempted = 0
    for index, track_id in enumerate(ids):
        _safe_progress("analyzing volume and ramps", current=index, total=len(ids))
        if deadline is not None and time.monotonic() >= deadline:
            remaining = ids[index:]
            release_pending(
                remaining,
                catalog_instance_id=catalog_instance_id,
                reason="The Lumae runner's slice was used",
                tokens=attempt_tokens,
                count_failure=False,
            )
            results.extend(
                {"track_id": item_id, "status": "deferred_tick_deadline"}
                for item_id in remaining
            )
            break
        if priority == "background":
            serve_interactive()
        if priority == "background" and catalog_instance_id:
            heartbeat_profile_backfill(catalog_instance_id)
        if maintenance_paused():
            remaining = ids[index:]
            release_pending(
                remaining,
                catalog_instance_id=catalog_instance_id,
                reason="Lumae background maintenance was paused during the batch",
                tokens=attempt_tokens,
                count_failure=False,
            )
            results.extend(
                {"track_id": item_id, "status": "skipped_maintenance_paused"}
                for item_id in remaining
            )
            break
        if catalog_instance_id and track_id not in attempt_tokens:
            results.append({"track_id": track_id, "status": "superseded"})
            continue
        disposition = profile_task_disposition(
            track_id,
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
            priority=priority,
        )
        if disposition != "analyze":
            results.append({"track_id": track_id, "status": disposition})
            continue
        attempted += 1
        results.append(
            analyze_one_track(
                track_id,
                catalog_instance_id=catalog_instance_id,
                server_id=server_id,
                attempt_token=attempt_tokens.get(track_id) if catalog_instance_id else None,
                priority=priority,
            )
        )
        _safe_progress("analyzing volume and ramps", current=index + 1, total=len(ids))
        if priority == "background" and catalog_instance_id:
            heartbeat_profile_backfill(catalog_instance_id)
    return _tracks_summary(results, attempted, catalog_instance_id, priority)


def _analyze_tracks_parallel(pool, ids, catalog_instance_id, server_id, attempt_tokens, deadline):
    """A background waveform batch on the turn's K analysis threads (WP1b):
    ``(results, attempted)``.

    Each track is claimed, checked and downloaded here, analysed on a thread,
    and published here as it completes. Deferred on-demand work is served
    whenever a thread frees, before the next track. No track starts once the
    slice's deadline is nearer than the batch's average time per file; a file
    in flight at the deadline runs to completion, as on the serial path, and
    the tracks never started are released uncounted.
    """
    results, attempted, paused = [], [0], [False]
    limit = analysis_time_limit_seconds()
    tokens = attempt_tokens or {}

    def between():
        serve_interactive()
        if catalog_instance_id:
            heartbeat_profile_backfill(catalog_instance_id)
        if maintenance_paused():
            paused[0] = True
            return False
        return True

    def prepare(track_id):
        _safe_progress("analyzing volume and ramps", current=len(results), total=len(ids))
        if catalog_instance_id and track_id not in tokens:
            results.append({"track_id": track_id, "status": "superseded"})
            return None
        disposition = profile_task_disposition(
            track_id, catalog_instance_id=catalog_instance_id, server_id=server_id, priority="background")
        if disposition != "analyze":
            results.append({"track_id": track_id, "status": disposition})
            return None
        attempted[0] += 1
        outcome, state = _prepare_track(track_id, catalog_instance_id, server_id,
                                        tokens.get(track_id) if catalog_instance_id else None, "background",
                                        defer=True)
        if outcome is not None:
            results.append(outcome)
            return None
        return (lambda: (fetch_track_file(state["info"]), _analyse_track_file(state, limit))[1]), state

    def finish(track_id, state, result, error):
        reason = "The Lumae runner's slice was used"
        if isinstance(error, analysis_download.DownloadError):
            # Due again at once; the host downloads it for the rest of the task.
            _refuse_own_download(catalog_instance_id, error)
            error, reason = parallel_analysis.Cancelled(), "Lumae's own download failed"
        if isinstance(error, parallel_analysis.Cancelled):
            attempted[0] -= 1
            _release_track(state, reason)
            results.append({"track_id": track_id, "status": "deferred_tick_deadline"})
        else:
            results.append(_finish_track(state, result, error))
        _safe_progress("analyzing volume and ramps", current=len(results), total=len(ids))
        if catalog_instance_id:
            heartbeat_profile_backfill(catalog_instance_id)

    report = parallel_analysis.run(ids, prepare, finish, pool=pool, deadline=deadline, between=between)
    remaining = ids[len(report.taken):]
    if remaining:
        status = "skipped_maintenance_paused" if paused[0] else "deferred_tick_deadline"
        release_pending(
            remaining,
            catalog_instance_id=catalog_instance_id,
            reason=("Lumae background maintenance was paused during the batch" if paused[0]
                    else "The Lumae runner's slice was used"),
            tokens=attempt_tokens,
            count_failure=False,
        )
        results.extend({"track_id": item_id, "status": status} for item_id in remaining)
    return results, attempted[0]


def _tracks_summary(results, attempted, catalog_instance_id, priority):
    summary = {
        "attempted": attempted,
        "ready": sum(1 for result in results if result["status"] == "ready"),
        "already_ready": sum(
            1 for result in results if result["status"] == "already_ready"
        ),
        "promoted": sum(1 for result in results if result["status"] == "promoted"),
        "failed": sum(1 for result in results if result["status"] == "failed"),
        "skipped": sum(1 for result in results if result["status"].startswith("skipped")),
        "deferred": sum(1 for result in results if result["status"] == "deferred_tick_deadline"),
    }
    if catalog_instance_id:
        finalize_preparation_if_settled(catalog_instance_id)
        if priority != "background":
            # Background batches run inside a runner turn, which refreshes
            # the settings counts when it ends; an interactive batch refreshes
            # them itself (P2-1).
            refresh_status_snapshot(catalog_instance_id=catalog_instance_id)
    return summary


def is_backfill_candidate(file_path, stored_sig, analyzer_ver, status):
    if is_pending_profile_status(status):
        return False
    current_sig = (
        file_path if str(file_path or "").startswith("catalog-media:") else media_signature(file_path)
    )
    if status == "deferred_no_media_revision":
        return bool(current_sig and current_sig != "catalog-media:")
    if status == "skipped_no_file":
        return bool(current_sig or media_server_download_available())
    if analyzer_ver is None:
        return True
    if int(analyzer_ver) < ANALYZER_VERSION:
        return True
    if status == "stale":
        return True
    if status == "ready" and current_sig and current_sig != "catalog-media:" and current_sig != stored_sig:
        return True
    return False


def fetch_analysis_rows(catalog_instance_id=None, server_id=None):
    db = get_db()
    cur = db.cursor()
    profile_table = source_profiles_table() if catalog_instance_id else profiles_table()
    profile_source_join = (
        "AND p.catalog_instance_id=source.catalog_instance_id" if catalog_instance_id else ""
    )
    source_filters = ""
    params = ()
    if catalog_instance_id or server_id:
        source_filters = """
               AND (%s IS NULL OR s.catalog_instance_id=%s)
               AND (%s IS NULL OR s.current_core_server_id=%s)
        """
        params = (catalog_instance_id, catalog_instance_id, server_id, server_id)
    sql = f"""
        WITH source AS (
            SELECT s.catalog_instance_id, c.published_generation
              FROM {table('catalog_sources')} s
              JOIN {table('catalog_state')} c USING (catalog_instance_id)
             WHERE s.rebind_status='active' AND c.status='complete'
               {source_filters}
             ORDER BY s.is_default DESC, s.server_name, s.catalog_instance_id
             LIMIT 1
        )
        SELECT t.track_id, 'catalog-media:' || COALESCE(t.media_fp, ''),
               p.media_signature, p.analyzer_ver, p.status
          FROM source
          JOIN {table('catalog_tracks')} t
            ON t.catalog_instance_id=source.catalog_instance_id
           AND t.published_generation=source.published_generation
          LEFT JOIN {profile_table} p ON p.track_id=t.track_id
               {profile_source_join}
         WHERE t.available=TRUE AND t.analysis_eligible=TRUE
         ORDER BY t.track_id
        """
    if params:
        cur.execute(sql, params)
    else:
        cur.execute(sql)
    rows = cur.fetchall()
    cur.close()
    return rows


def fetch_backfill_rows(
    limit,
    catalog_instance_id=None,
    server_id=None,
    include_failed=False,
):
    """Select only one retryable profile batch in PostgreSQL."""
    db = get_db()
    cur = db.cursor()
    profile_table = source_profiles_table() if catalog_instance_id else profiles_table()
    profile_source_join = (
        "AND p.catalog_instance_id=source.catalog_instance_id" if catalog_instance_id else ""
    )
    source_filters = ""
    params = scheduler_params(ANALYZER_VERSION, SCHEMA_VERSION)
    params.update(
        source=catalog_instance_id, server_id=server_id,
        include_failed=bool(include_failed), limit=max(1, int(limit)),
    )
    if catalog_instance_id or server_id:
        source_filters = """
               AND (%(source)s IS NULL OR s.catalog_instance_id=%(source)s)
               AND (%(server_id)s IS NULL OR s.current_core_server_id=%(server_id)s)
        """
    # The source table's predicates are profile_publication's, shared with
    # next_profile_retry_at and the /database-state work states (LUM-007).
    # Published catalogue occurrences are downloaded through
    # ProviderCatalogBridge, so a skipped row stays retryable on the legacy
    # table even when a v3 registry source has no matching legacy global
    # MEDIASERVER_* configuration.
    due = backfill_due_sql() if catalog_instance_id else backfill_due_sql(
        stale="p.status='stale'",
        failure="((%(include_failed)s AND p.status='failed') "
                "OR p.status='skipped_no_file')",
    )
    cur.execute(
        f"""
        WITH source AS (
            SELECT s.catalog_instance_id, c.published_generation
              FROM {table('catalog_sources')} s
              JOIN {table('catalog_state')} c USING (catalog_instance_id)
             WHERE s.rebind_status='active' AND c.status='complete'
               {source_filters}
             ORDER BY s.is_default DESC, s.server_name, s.catalog_instance_id
             LIMIT 1
        )
        SELECT t.track_id, 'catalog-media:' || COALESCE(t.media_fp, ''),
               p.media_signature, p.analyzer_ver, p.status
          FROM source
          JOIN {table('catalog_tracks')} t
            ON t.catalog_instance_id=source.catalog_instance_id
           AND t.published_generation=source.published_generation
          LEFT JOIN {profile_table} p ON p.track_id=t.track_id
               {profile_source_join}
         WHERE t.available=TRUE AND t.analysis_eligible=TRUE
           AND {due}
         ORDER BY t.track_id
         LIMIT %(limit)s
        """,
        params,
    )
    rows = cur.fetchall()
    cur.close()
    return rows


def find_backfill_ids(
    limit=25,
    catalog_instance_id=None,
    server_id=None,
    include_failed=False,
):
    batch_limit = normalize_backfill_limit(limit or configured_backfill_limit())
    ids = []
    rows = fetch_backfill_rows(
        batch_limit,
        catalog_instance_id=catalog_instance_id,
        server_id=server_id,
        include_failed=include_failed,
    )
    for item_id, file_path, stored_sig, analyzer_ver, status in rows:
        if (
            (catalog_instance_id and status in ("failed", "skipped_no_file"))
            or (include_failed and status == "failed")
            or is_backfill_candidate(
                file_path, stored_sig, analyzer_ver, status
            )
        ):
            ids.append(str(item_id))
            if len(ids) >= batch_limit:
                break
    return ids


def find_all_backfill_ids(catalog_instance_id=None, server_id=None, include_failed=False):
    ids = []
    rows = (
        fetch_analysis_rows(catalog_instance_id=catalog_instance_id, server_id=server_id)
        if catalog_instance_id or server_id
        else fetch_analysis_rows()
    )
    for item_id, file_path, stored_sig, analyzer_ver, status in rows:
        if (include_failed and status == "failed") or is_backfill_candidate(
            file_path, stored_sig, analyzer_ver, status
        ):
            ids.append(str(item_id))
    return ids


def _analysis_status_counts_query(catalog_instance_id=None, server_id=None):
    """The waveform status aggregate. Its sixth column is the counted generation.

    ``analysis_status_counts`` runs it live; ``refresh_status_snapshot`` stores
    its result for ``/settings/status`` (P2-1).
    """
    profile_table = source_profiles_table() if catalog_instance_id else profiles_table()
    profile_source_join = (
        "AND p.catalog_instance_id=source.catalog_instance_id" if catalog_instance_id else ""
    )
    source_filters = ""
    params = []
    if catalog_instance_id or server_id:
        source_filters = """
               AND (%s IS NULL OR s.catalog_instance_id=%s)
               AND (%s IS NULL OR s.current_core_server_id=%s)
        """
        params.extend((catalog_instance_id, catalog_instance_id, server_id, server_id))
    # A published catalogue occurrence is retried through ProviderCatalogBridge,
    # including v3 registry sources whose credentials are not represented by
    # the legacy global MEDIASERVER_* configuration fields.
    retry_skipped = True
    params.extend((ANALYZER_VERSION, retry_skipped))
    sql = f"""
        WITH source AS (
            SELECT s.catalog_instance_id, c.published_generation
              FROM {table('catalog_sources')} s
              JOIN {table('catalog_state')} c USING (catalog_instance_id)
             WHERE s.rebind_status='active' AND c.status='complete'
               {source_filters}
             ORDER BY s.is_default DESC, s.server_name, s.catalog_instance_id
             LIMIT 1
        )
        SELECT
            COUNT(*)::BIGINT,
            COUNT(*) FILTER (
                WHERE p.status='ready'
                  AND p.analyzer_ver >= %s
                  AND p.media_signature IS NOT DISTINCT FROM
                      ('catalog-media:' || COALESCE(t.media_fp, ''))
            )::BIGINT,
            COUNT(*) FILTER (
                WHERE p.status IN ('pending', 'pending_interactive')
            )::BIGINT,
            COUNT(*) FILTER (WHERE p.status='failed')::BIGINT,
            COUNT(*) FILTER (
                WHERE p.status='skipped_no_file' AND NOT %s
            )::BIGINT,
            (SELECT published_generation FROM source)
          FROM source
          JOIN {table('catalog_tracks')} t
            ON t.catalog_instance_id=source.catalog_instance_id
           AND t.published_generation=source.published_generation
          LEFT JOIN {profile_table} p ON p.track_id=t.track_id
               {profile_source_join}
         WHERE t.available=TRUE AND t.analysis_eligible=TRUE
        """
    return sql, tuple(params)


def analysis_status_counts(catalog_instance_id=None, server_id=None):
    db = get_db()
    cur = db.cursor()
    cur.execute(*_analysis_status_counts_query(catalog_instance_id, server_id))
    row = cur.fetchone() or (0, 0, 0, 0, 0)
    cur.close()
    total, ready, pending, failed, skipped = (int(value or 0) for value in row[:5])
    return {
        "total_with_files": total,
        "ready_current": ready,
        "pending": pending,
        "failed": failed,
        "skipped": skipped,
        "needs_analysis": max(0, total - ready - pending - failed - skipped),
    }


def _store_profile_snapshots(cur, catalog_instance_id=None, min_age_seconds=0,
                             missing_only=False):
    if catalog_instance_id:
        targets = [str(catalog_instance_id)]
    else:
        cur.execute(
            f"""
            SELECT s.catalog_instance_id
              FROM {table('catalog_sources')} s
              JOIN {table('catalog_state')} c USING (catalog_instance_id)
              LEFT JOIN {table('status_summary')} ss USING (catalog_instance_id)
             WHERE NOT %s OR ss.profile_generation IS DISTINCT FROM c.published_generation
             ORDER BY s.catalog_instance_id
            """,
            (bool(missing_only),),
        )
        targets = [str(row[0]) for row in cur.fetchall()]
    stored = 0
    for target in targets:
        if min_age_seconds:
            age = status_model.profile_counts_age_seconds(cur, target)
            if age is not None and age < min_age_seconds:
                continue
        sql, params = _analysis_status_counts_query(catalog_instance_id=target)
        status_model.store_profile_counts(cur, target, sql, params)
        stored += 1
    return stored


def refresh_status_snapshot(db=None, catalog_instance_id=None, min_age_seconds=0,
                            publications=False):
    """Refresh the waveform counts that ``/settings/status`` reads (P2-1).

    Background work calls this after it changed profile state; the GET route
    only reads the snapshot. With ``min_age_seconds`` a snapshot younger than
    that is kept. ``publications`` first summarizes any published generation
    that has no summary (a failed post-commit refresh, a rebound source, an
    older worker's publication). Never raises: a failed refresh keeps the
    previous snapshot, and the route counts live when the snapshot describes
    another generation.
    """
    try:
        db = db or get_db()
    except Exception:
        db = None
    if db is None:
        return 0
    try:
        cur = db.cursor()
        try:
            if publications:
                # Committed per source and before the waveform count, so no
                # analysis_state row lock is held while counting.
                status_model.backfill_publication_summaries(cur, commit=db.commit)
                db.commit()
            stored = _store_profile_snapshots(cur, catalog_instance_id, min_age_seconds)
        finally:
            cur.close()
        db.commit()
        return stored
    except Exception:
        _rollback_if_possible(db)
        logger.warning(
            "lumae_analysis could not refresh the settings status counts", exc_info=True
        )
        return 0


def refresh_status_summaries(db):
    """Install and upgrade: summarize what is already published (P2-1).

    Runs in the install transaction; the caller commits. Only what has no
    summary yet is counted, so a re-run writes nothing.
    """
    cur = db.cursor()
    try:
        status_model.backfill_publication_summaries(cur)
        _store_profile_snapshots(cur, missing_only=True)
    finally:
        cur.close()


def _committed_profile_counts(source):
    """The committed waveform counts of a source, or None to count live."""
    db = None
    try:
        db = get_db()
        return status_model.profile_counts(db, source) if db is not None else None
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis could not read the settings status counts", exc_info=True)
        return None


def profile_backfill_state(catalog_instance_id, db=None):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT server_id, status, processed_profiles, queued_profiles,
               last_error, started_at, completed_at, updated_at, next_retry_at
          FROM {profile_backfill_state_table()}
         WHERE catalog_instance_id=%s
        """,
        (catalog_instance_id,),
    )
    row = cur.fetchone()
    cur.close()
    if row is None:
        return None
    return {
        "catalog_instance_id": str(catalog_instance_id),
        "server_id": str(row[0]),
        "status": str(row[1]),
        "processed_profiles": int(row[2] or 0),
        "queued_profiles": int(row[3] or 0),
        "last_error": str(row[4]) if row[4] else None,
        "started_at": str(row[5]) if row[5] else None,
        "completed_at": str(row[6]) if row[6] else None,
        "updated_at": str(row[7]) if row[7] else None,
        # LUM-017 (P3-9): when this is set the worker is deliberately
        # cooling down after a transient failure, not idle or stuck.
        "next_retry_at": str(row[8]) if row[8] else None,
    }


def profile_backfill_is_active(state, now=None):
    if not state or state.get("status") not in ("queued", "running"):
        return False
    try:
        updated_at = datetime.fromisoformat(str(state["updated_at"]).replace("Z", "+00:00"))
        current = now or datetime.now(timezone.utc)
        if updated_at.tzinfo is None:
            updated_at = updated_at.replace(tzinfo=timezone.utc)
        return (current - updated_at).total_seconds() < BACKFILL_STALE_MINUTES * 60
    except (KeyError, TypeError, ValueError):
        return True


def _future_retry_at(value, now=None):
    """``value`` while that cooldown is still ahead of ``now``, else None."""
    if not value:
        return None
    try:
        at = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if at.tzinfo is None:
        at = at.replace(tzinfo=timezone.utc)
    return value if at > (now or datetime.now(timezone.utc)) else None


def claim_profile_backfill(source, db=None):
    """Atomically admit one durable background workflow per catalogue source."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {profile_backfill_state_table()}
            (catalog_instance_id, server_id, status, processed_profiles,
             queued_profiles, last_error, started_at, completed_at, updated_at)
        VALUES (%s, %s, 'queued', 0, 0, NULL, now(), NULL, now())
        ON CONFLICT (catalog_instance_id) DO UPDATE SET
            server_id=EXCLUDED.server_id, status='queued', processed_profiles=0,
            queued_profiles=0, last_error=NULL, started_at=now(),
            completed_at=NULL, retry_count=0, next_retry_at=NULL, updated_at=now()
        WHERE {profile_backfill_state_table()}.status NOT IN ('queued', 'running')
           OR {profile_backfill_state_table()}.updated_at
              < now() - interval '{BACKFILL_STALE_MINUTES} minutes'
        RETURNING catalog_instance_id
        """,
        (source["catalog_instance_id"], source["server_id"]),
    )
    claimed = cur.fetchone() is not None
    if claimed:
        wake_runners(db, "profile_backfill_admitted")
    db.commit()
    cur.close()
    return claimed


BACKFILL_ABORT_RETRY_SECONDS = 60


def claim_profile_backfill_batch(catalog_instance_id, db=None):
    """Claim one queued or interrupted batch for exclusive execution."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        UPDATE {profile_backfill_state_table()}
           SET status='running', last_error=NULL, next_retry_at=NULL, updated_at=now()
         WHERE catalog_instance_id=%s
           AND ((status='queued' AND (next_retry_at IS NULL OR next_retry_at <= now()))
                OR (status='failed' AND (next_retry_at IS NULL OR next_retry_at <= now()))
                OR (status='running' AND updated_at
                    < now() - interval '{BACKFILL_STALE_MINUTES} minutes'))
        RETURNING catalog_instance_id
        """,
        (catalog_instance_id,),
    )
    claimed = cur.fetchone() is not None
    db.commit()
    cur.close()
    return claimed


def heartbeat_profile_backfill(catalog_instance_id, db=None):
    """Keep a long bounded waveform batch from looking abandoned."""
    db = db or get_db()
    if db is None:
        return False
    try:
        cur = db.cursor()
        cur.execute(
            f"UPDATE {profile_backfill_state_table()} SET updated_at=now() "
            "WHERE catalog_instance_id=%s AND status='running'",
            (catalog_instance_id,),
        )
        cur.close()
        db.commit()
        return True
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not heartbeat profile backfill")
        return False


def update_profile_backfill_state(
    catalog_instance_id,
    server_id,
    status,
    *,
    processed_increment=0,
    queued_profiles=0,
    last_error=None,
    completed=False,
    next_retry_at=None,
    retry_after_seconds=None,
    db=None,
):
    """``retry_after_seconds`` sets ``next_retry_at`` from the database clock
    when ``next_retry_at`` is not given."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {profile_backfill_state_table()}
            (catalog_instance_id, server_id, status, processed_profiles,
             queued_profiles, last_error, started_at, completed_at,
             next_retry_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, now(),
                CASE WHEN %s THEN now() ELSE NULL END,
                COALESCE(%s, now() + %s::float8 * interval '1 second'), now())
        ON CONFLICT (catalog_instance_id) DO UPDATE SET
            server_id=EXCLUDED.server_id,
            status=CASE WHEN EXCLUDED.status='complete'
                              AND {profile_backfill_state_table()}.refresh_wake_pending
                        THEN 'queued' ELSE EXCLUDED.status END,
            refresh_wake_pending=FALSE,
            processed_profiles={profile_backfill_state_table()}.processed_profiles
                + EXCLUDED.processed_profiles,
            queued_profiles=EXCLUDED.queued_profiles,
            last_error=EXCLUDED.last_error,
            completed_at=EXCLUDED.completed_at,
            -- A wake (a catalogue refresh, or the recovery arm of this
            -- batch's own admissions) runs now, except after an explicit
            -- retry delay: an aborted batch waits it out (LUM-007).
            next_retry_at=CASE WHEN {profile_backfill_state_table()}.refresh_wake_pending
                                    AND %s::float8 IS NULL
                                  THEN NULL ELSE EXCLUDED.next_retry_at END,
            updated_at=now()
        """,
        (
            catalog_instance_id,
            server_id,
            status,
            int(processed_increment or 0),
            int(queued_profiles or 0),
            str(last_error)[:2000] if last_error else None,
            bool(completed),
            next_retry_at,
            retry_after_seconds,
            retry_after_seconds,
        ),
    )
    db.commit()
    cur.close()


def start_profile_backfill(catalog_instance_id=None, server_id=None):
    if maintenance_paused():
        return {
            "queued": False,
            "coalesced": True,
            "paused": True,
            "batch_size": configured_backfill_limit(),
        }
    source = resolve_profile_source(
        catalog_instance_id=catalog_instance_id,
        server_id=server_id,
    )
    if not claim_profile_backfill(source):
        return {"queued": False, "coalesced": True, "batch_size": configured_backfill_limit()}
    # The claim recorded it and woke the runners (R6).
    return {
        "queued": True,
        "coalesced": False,
        "deferred": True,
        "batch_size": configured_backfill_limit(),
    }


def next_profile_retry_at(catalog_instance_id, db=None):
    """Earliest finite due retry for one exact source; no work is queued early."""
    db = db or get_db()
    with db.cursor() as cur:
        cur.execute(
            f"""SELECT MIN(CASE
                       WHEN p.status IN ('pending', 'pending_interactive')
                           THEN p.analyzed_at + interval '1 hour'
                       ELSE p.retry_after END)
                  FROM {source_profiles_table()} p
                  JOIN {table('catalog_sources')} s
                    ON s.catalog_instance_id=p.catalog_instance_id
                  JOIN {table('catalog_state')} c
                    ON c.catalog_instance_id=p.catalog_instance_id
                  JOIN {table('catalog_tracks')} t
                    ON t.catalog_instance_id=p.catalog_instance_id
                   AND t.published_generation=c.published_generation
                   AND t.track_id=p.track_id
                 WHERE p.catalog_instance_id=%(source)s
                   AND s.rebind_status='active'
                   AND t.available=TRUE
                   AND t.analysis_eligible=TRUE
                   AND (
                       p.status IN ('pending', 'pending_interactive')
                       OR {RETRY_ARMED_SQL}
                   )""",
            {**scheduler_params(ANALYZER_VERSION, SCHEMA_VERSION),
             "source": catalog_instance_id},
        )
        row = cur.fetchone()
    return row[0] if row else None


def profile_backfill_task(server_id, catalog_instance_id, deadline=None, shared=False):
    """Process one small batch; the runner resumes a queued next batch.

    ``deadline``: the runner slice's; tracks not started by then are due
    again at once. ``shared`` (multi-worker plan R4): helpers admit batches
    of the same source meanwhile, so a track another runner's batch admitted
    is left to it.
    """
    if maintenance_paused():
        update_profile_backfill_state(
            catalog_instance_id,
            server_id,
            "queued",
            last_error=None,
        )
        return {"status": "paused", "processed": 0, "queued_next": False}
    if not claim_profile_backfill_batch(catalog_instance_id):
        return {
            "status": "coalesced",
            "processed": 0,
            "queued_next": False,
        }
    claimed_ids = []
    claim_tokens = {}
    try:
        _safe_progress("selecting volume and ramp batch")
        resolve_profile_source(
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
        )
        recover_stale_pending_profiles(catalog_instance_id)
        ids = find_backfill_ids(
            background_batch_limit(),
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
            include_failed=False,
        )
        if not ids:
            next_retry = next_profile_retry_at(catalog_instance_id)
            update_profile_backfill_state(
                catalog_instance_id, server_id,
                "queued" if next_retry else "complete",
                next_retry_at=next_retry, completed=not bool(next_retry),
            )
            return {"status": "waiting_retry" if next_retry else "complete",
                    "processed": 0, "queued_next": False}
        claimed_ids = ids
        claim_tokens = mark_pending(
            ids, catalog_instance_id=catalog_instance_id, priority="background",
            **({"keep_live": True} if shared else {}),
        )
        ids = [track_id for track_id in ids if track_id in claim_tokens]
        held = _hold_waveform(catalog_instance_id, claim_tokens) if shared else None
        try:
            result = analyze_tracks_task(
                ids,
                catalog_instance_id=catalog_instance_id,
                server_id=server_id,
                priority="background",
                attempt_tokens=claim_tokens,
                deadline=deadline,
            )
        finally:
            _forget_waveform(held)
        analysed = len(ids) - int((result or {}).get("deferred") or 0)
        next_ids = find_backfill_ids(
            1,
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
            include_failed=False,
        )
        if not next_ids:
            next_retry = next_profile_retry_at(catalog_instance_id)
            update_profile_backfill_state(
                catalog_instance_id, server_id,
                "queued" if next_retry else "complete",
                processed_increment=analysed, next_retry_at=next_retry,
                completed=not bool(next_retry),
            )
            return {"status": "waiting_retry" if next_retry else "complete",
                    "processed": analysed, "queued_next": False, **result}
        update_profile_backfill_state(
            catalog_instance_id,
            server_id,
            "queued",
            processed_increment=analysed,
            queued_profiles=len(next_ids),
        )
        return {
            "status": "queued",
            "processed": analysed,
            "queued_next": False,
            "deferred": True,
            **result,
        }
    except Exception as exc:
        if claimed_ids:
            try:
                release_pending(
                    claimed_ids,
                    catalog_instance_id=catalog_instance_id,
                    reason=f"Background enrichment batch failed: {exc}",
                    tokens=claim_tokens,
                    count_failure=False,
                )
            except Exception:
                logger.exception("lumae_analysis could not release a failed background batch")
        update_profile_backfill_state(
            catalog_instance_id,
            server_id,
            "failed",
            last_error=exc,
            completed=True,
            # Its rows are due at once (an uncounted release), so a persistent
            # error would abort a batch on every runner turn: retry the
            # batch after a fixed minute instead (LUM-007).
            retry_after_seconds=BACKFILL_ABORT_RETRY_SECONDS,
        )
        raise


# Multi-worker plan R4: a helper's waveform batch selects again this many
# times when other runners admitted every track it selected.
SHARED_BATCH_ATTEMPTS = 3
# Multi-worker plan R4: the record of a waveform batch's attempts, which any
# runner releases once its runner went away.
WAVEFORM_PASS = "waveform"


def _hold_waveform(catalog_instance_id, tokens):
    """Record this runner's admitted waveform attempts for its slice; the
    record's ID, or None (outside a runner turn, nothing admitted, or the
    record could not be written: then a stale attempt waits its hour)."""
    if not tokens or runner.RUNNER_ID.get() is None:
        return None
    db = get_db()
    try:
        return shared_pass.hold(db, WAVEFORM_PASS, catalog_instance_id, tokens)
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis could not record a waveform batch", exc_info=True)
        return None


def _forget_waveform(held):
    if held is None:
        return
    db = get_db()
    try:
        shared_pass.forget(db, held)
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis could not forget a waveform batch", exc_info=True)


def _release_gone_waveform(db):
    """Release the waveform attempts of runners that went away, due again at
    once, and queue their sources' waveform pass; returns how many. Never
    raises: what it could not release waits its hour as a stale attempt."""
    released = 0
    try:
        gone = shared_pass.take_over_gone(db, WAVEFORM_PASS)
        for catalog_instance_id, tokens in gone:
            released += release_attempts(db, catalog_instance_id, tokens, "runner_gone",
                                         count_failure=False)
            with db.cursor() as cur:
                cur.execute(
                    f"""UPDATE {profile_backfill_state_table()}
                           SET status='queued', next_retry_at=NULL, updated_at=now()
                         WHERE catalog_instance_id=%s AND status <> 'running'""",
                    (catalog_instance_id,),
                )
            db.commit()
        if released:
            logger.info("lumae_analysis released %d waveform attempts of a runner that went away",
                        released)
            wake_runners(db, "waveform_batch_taken_over", commit=True)
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis could not release a gone runner's waveform attempts",
                       exc_info=True)
    return released


def _requeue_waveform_claims(db):
    """A new worker leader with ``every``: the waveform passes the previous
    leader claimed (only a leader claims one) are queued again at once instead
    of after BACKFILL_STALE_MINUTES. Should that leader still finish a batch,
    ``keep_live`` admission keeps the two apart. Never raises."""
    try:
        with db.cursor() as cur:
            cur.execute(
                f"""UPDATE {profile_backfill_state_table()}
                       SET status='queued', next_retry_at=NULL, updated_at=now()
                     WHERE status='running'"""
            )
        db.commit()
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis could not queue the previous leader's waveform pass",
                       exc_info=True)


def helper_profile_batch_task(server_id, catalog_instance_id, deadline=None):
    """A helper's waveform batch (multi-worker plan R4): like the leader's
    ``profile_backfill_task`` but without its per-source claim and its state.

    The leader keeps the source's backfill state (queued, complete, its
    retries and stale recovery); a helper only selects due tracks, admits the
    ones no other runner's batch holds (``keep_live``), analyses them until
    ``deadline`` and counts them. ``coalesced`` when nothing is left for it.
    """
    if maintenance_paused():
        return {"status": "paused", "processed": 0}
    resolve_profile_source(catalog_instance_id=catalog_instance_id, server_id=server_id)
    for _attempt in range(SHARED_BATCH_ATTEMPTS):
        ids = find_backfill_ids(background_batch_limit(), catalog_instance_id=catalog_instance_id,
                                server_id=server_id, include_failed=False)
        if not ids:
            return {"status": "coalesced", "processed": 0}
        tokens = mark_pending(ids, catalog_instance_id=catalog_instance_id, priority="background",
                              keep_live=True)
        ids = [track_id for track_id in ids if track_id in tokens]
        if ids:
            break
    else:
        return {"status": "coalesced", "processed": 0}
    held = _hold_waveform(catalog_instance_id, tokens)
    try:
        result = analyze_tracks_task(ids, catalog_instance_id=catalog_instance_id, server_id=server_id,
                                     priority="background", attempt_tokens=tokens, deadline=deadline)
    except Exception as exc:
        try:
            release_pending(ids, catalog_instance_id=catalog_instance_id,
                            reason=f"Background enrichment batch failed: {exc}", tokens=tokens,
                            count_failure=False)
        except Exception:
            logger.exception("lumae_analysis could not release a failed helper batch")
        raise
    finally:
        _forget_waveform(held)
    analysed = len(ids) - int((result or {}).get("deferred") or 0)
    db = get_db()
    with db.cursor() as cur:
        cur.execute(
            f"UPDATE {profile_backfill_state_table()} SET processed_profiles=processed_profiles+%s "
            "WHERE catalog_instance_id=%s",
            (int(analysed), catalog_instance_id),
        )
    db.commit()
    return {**(result or {}), "status": "queued", "processed": analysed}


def backfill_missing_profiles(limit=None, catalog_instance_id=None, server_id=None):
    requested_limit = limit or configured_backfill_limit()
    source = (
        resolve_profile_source(
            catalog_instance_id=catalog_instance_id, server_id=server_id,
        )["catalog_instance_id"]
        if catalog_instance_id or server_id else None
    )
    ids = (
        find_backfill_ids(
            requested_limit,
            catalog_instance_id=source,
            server_id=server_id,
        )
        if source
        else find_backfill_ids(requested_limit)
    )
    if source:
        tokens = mark_pending(ids, catalog_instance_id=source, priority="background")
        admitted = [track_id for track_id in ids if track_id in tokens]
        return analyze_tracks_task(
            admitted,
            catalog_instance_id=source,
            server_id=server_id,
            attempt_tokens=tokens,
        )
    return analyze_tracks_task(ids)


def relationship_preparation_task(server_id, catalog_instance_id, time_budget_seconds=20):
    """One build step; a runner passes what is left of its slice."""
    if maintenance_paused():
        return {"status": "paused", "reason": "maintenance_paused"}
    source = resolve_profile_source(
        catalog_instance_id=catalog_instance_id, server_id=server_id,
    )
    if source["catalog_instance_id"] != catalog_instance_id:
        raise CatalogScanError("Catalogue identity changed before relationship preparation")
    # The builder owns a session advisory lock across its checkpoint commits.
    return prepare_relationships(catalog_instance_id, progress=_safe_progress,
                                 time_budget_seconds=max(1.0, float(time_budget_seconds)))


def start_relationship_preparation(
    catalog_instance_id=None, server_id=None, force=False
):
    """Request one coalesced relationship build without delaying readiness.
    ``force`` (the settings page's rebuild) skips W2's spacing."""
    if maintenance_paused():
        return {
            "queued": False,
            "coalesced": True,
            "paused": True,
            "reason": "maintenance_paused",
        }
    source = resolve_profile_source(
        catalog_instance_id=catalog_instance_id,
        server_id=server_id,
    )
    current = relationship_status(get_db(), source["catalog_instance_id"])
    catalog_generation = int(source["catalog"]["generation"])
    analysis_generation = int(source["analysis"]["generation"])
    already_current = (
        current.get("status") == "complete"
        and int(current.get("source_catalog_generation") or 0) == catalog_generation
        and int(current.get("source_analysis_generation") or 0) == analysis_generation
        and int(current.get("schema_version") or 0) == RELATIONSHIP_SCHEMA_VERSION
        and int(current.get("algorithm_version") or 0) == RELATIONSHIP_ALGORITHM_VERSION
        and int(current.get("scoring_revision") or 0) == RELATIONSHIP_SCORING_REVISION
    )
    if already_current:
        return {
            "queued": False,
            "coalesced": True,
            "reason": "already_current",
        }
    if not claim_relationship_preparation(get_db(), source["catalog_instance_id"], force=force):
        return {
            "queued": False,
            "coalesced": True,
            "reason": "already_running",
        }
    # The claim recorded it and woke the runners (R6).
    return {
        "queued": True,
        "coalesced": False,
        "deferred": True,
    }


def preparation_state(catalog_instance_id, db=None):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT server_id, status, phase, queued_profiles, profile_jobs,
               target_plugin_version, target_catalog_builder_version,
               worker_plugin_version, worker_catalog_builder_version,
               last_error, started_at, completed_at, updated_at
          FROM {preparation_state_table()}
         WHERE catalog_instance_id=%s
        """,
        (catalog_instance_id,),
    )
    row = cur.fetchone()
    cur.close()
    if row is None:
        return None
    return {
        "catalog_instance_id": str(catalog_instance_id),
        "server_id": str(row[0]),
        "status": str(row[1]),
        "phase": str(row[2]),
        "queued_profiles": int(row[3] or 0),
        "profile_jobs": int(row[4] or 0),
        "target_plugin_version": str(row[5]) if row[5] else None,
        "target_catalog_builder_version": int(row[6]) if row[6] is not None else None,
        "worker_plugin_version": str(row[7]) if row[7] else None,
        "worker_catalog_builder_version": int(row[8]) if row[8] is not None else None,
        "last_error": str(row[9]) if row[9] else None,
        "started_at": str(row[10]) if row[10] else None,
        "completed_at": str(row[11]) if row[11] else None,
        "updated_at": str(row[12]) if row[12] else None,
    }


def preparation_attestation_is_current(state):
    """Legacy completed rows are accepted; newly claimed work must attest."""
    if not state or not state.get("target_plugin_version"):
        return True
    target_builder = int(state.get("target_catalog_builder_version") or 0)
    worker_builder = int(state.get("worker_catalog_builder_version") or 0)
    return (
        state.get("worker_plugin_version") == state.get("target_plugin_version")
        and worker_builder >= target_builder
    )


def assert_preparation_worker_current(catalog_instance_id):
    state = preparation_state(catalog_instance_id)
    if not state or not state.get("target_plugin_version"):
        return
    expected_plugin = str(state["target_plugin_version"])
    expected_builder = int(state.get("target_catalog_builder_version") or 0)
    if PLUGIN_VERSION != expected_plugin or CATALOG_BUILDER_VERSION < expected_builder:
        raise RuntimeError(
            "AudioMuse queued catalogue preparation for Lumae Analysis "
            f"{expected_plugin} (builder {expected_builder}), but this worker is still "
            f"running {PLUGIN_VERSION} (builder {CATALOG_BUILDER_VERSION}). "
            "Restart the AudioMuse workers; Lumae retries automatically."
        )


def preparation_is_active(state, now=None):
    if not state or state.get("status") not in ("queued", "running"):
        return False
    try:
        updated_at = datetime.fromisoformat(str(state["updated_at"]).replace("Z", "+00:00"))
        current = now or datetime.now(timezone.utc)
        if updated_at.tzinfo is None:
            updated_at = updated_at.replace(tzinfo=timezone.utc)
        return (current - updated_at).total_seconds() < PREPARATION_STALE_HOURS * 3600
    except (KeyError, TypeError, ValueError):
        return True


def claim_preparation(source, db=None):
    """Atomically admit one preparation run for an exact catalogue source."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {preparation_state_table()}
            (catalog_instance_id, server_id, status, phase, queued_profiles,
             profile_jobs, target_plugin_version, target_catalog_builder_version,
             worker_plugin_version, worker_catalog_builder_version,
             last_error, started_at, completed_at, updated_at)
        VALUES (%s, %s, 'queued', 'queued', 0, 0, %s, %s, NULL, NULL,
                NULL, now(), NULL, now())
        ON CONFLICT (catalog_instance_id) DO UPDATE SET
            server_id=EXCLUDED.server_id,
            status='queued', phase='queued', queued_profiles=0, profile_jobs=0,
            target_plugin_version=EXCLUDED.target_plugin_version,
            target_catalog_builder_version=EXCLUDED.target_catalog_builder_version,
            worker_plugin_version=NULL, worker_catalog_builder_version=NULL,
            last_error=NULL, started_at=now(), completed_at=NULL,
            retry_count=0, next_retry_at=NULL, updated_at=now()
        WHERE {preparation_state_table()}.status NOT IN ('queued', 'running')
           OR {preparation_state_table()}.updated_at < now() - interval '{PREPARATION_STALE_HOURS} hours'
        RETURNING catalog_instance_id
        """,
        (
            source["catalog_instance_id"],
            source["server_id"],
            PLUGIN_VERSION,
            CATALOG_BUILDER_VERSION,
        ),
    )
    claimed = cur.fetchone() is not None
    if claimed:
        wake_runners(db, "catalog_preparation_admitted")
    db.commit()
    cur.close()
    return claimed


def claim_preparation_run(catalog_instance_id, db=None):
    """Claim one queued or interrupted catalogue preparation."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        UPDATE {preparation_state_table()}
           SET status='running', phase='starting', last_error=NULL,
               started_at=COALESCE(started_at, now()), next_retry_at=NULL, updated_at=now()
         WHERE catalog_instance_id=%s
           AND (status='queued'
                OR (status='failed' AND (next_retry_at IS NULL OR next_retry_at <= now()))
                OR (status='running' AND updated_at
                    < now() - interval '{PREPARATION_STALE_HOURS} hours'))
        RETURNING catalog_instance_id
        """,
        (catalog_instance_id,),
    )
    claimed = cur.fetchone() is not None
    db.commit()
    cur.close()
    return claimed


def recover_stale_pending_profiles(catalog_instance_id, db=None):
    """Release claims older than PREPARATION_STALE_HOURS as a used attempt,
    locking the rows in track-ID order (as admission and release do)."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        WITH recovered AS MATERIALIZED (
            SELECT track_id FROM {source_profiles_table()}
             WHERE catalog_instance_id=%(source)s
               AND status IN ('pending', 'pending_interactive')
               AND analyzed_at < now() - interval '{PREPARATION_STALE_HOURS} hours'
             ORDER BY track_id COLLATE "C"
               FOR UPDATE
        ), updated AS (
            UPDATE {source_profiles_table()} p
               SET status='stale', last_error='queue_unavailable',
                   attempt_token=NULL, retry_category='queue_unavailable',
                   retry_count=p.retry_count+1,
                   retry_after=CASE WHEN p.retry_count+1 < %(retry_limit)s
                       THEN now() + {retry_delay_sql('p.retry_count')} ELSE NULL END,
                   retry_media_signature=p.attempt_media_signature,
                   retry_analyzer_ver=p.attempt_analyzer_ver,
                   retry_profile_schema_ver=p.attempt_profile_schema_ver
              FROM recovered
             WHERE p.catalog_instance_id=%(source)s AND p.track_id=recovered.track_id
         RETURNING 1
        )
        SELECT count(*) FROM updated
        """,
        {**scheduler_params(ANALYZER_VERSION, SCHEMA_VERSION),
         "source": catalog_instance_id},
    )
    row = cur.fetchone()
    recovered = max(0, int(row[0] if row else 0))
    db.commit()
    cur.close()
    return recovered


def update_preparation_state(
    catalog_instance_id,
    server_id,
    status,
    phase,
    queued_profiles=0,
    profile_jobs=0,
    last_error=None,
    completed=False,
    db=None,
):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {preparation_state_table()}
            (catalog_instance_id, server_id, status, phase, queued_profiles,
             profile_jobs, target_plugin_version, target_catalog_builder_version,
             worker_plugin_version, worker_catalog_builder_version,
             last_error, started_at, completed_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now(),
                CASE WHEN %s THEN now() ELSE NULL END, now())
        ON CONFLICT (catalog_instance_id) DO UPDATE SET
            server_id=EXCLUDED.server_id,
            status=EXCLUDED.status,
            phase=EXCLUDED.phase,
            queued_profiles=EXCLUDED.queued_profiles,
            profile_jobs=EXCLUDED.profile_jobs,
            target_plugin_version=COALESCE(
                {preparation_state_table()}.target_plugin_version,
                EXCLUDED.target_plugin_version
            ),
            target_catalog_builder_version=COALESCE(
                {preparation_state_table()}.target_catalog_builder_version,
                EXCLUDED.target_catalog_builder_version
            ),
            worker_plugin_version=EXCLUDED.worker_plugin_version,
            worker_catalog_builder_version=EXCLUDED.worker_catalog_builder_version,
            last_error=EXCLUDED.last_error,
            completed_at=EXCLUDED.completed_at,
            updated_at=now()
        """,
        (
            catalog_instance_id,
            server_id,
            status,
            phase,
            int(queued_profiles or 0),
            int(profile_jobs or 0),
            PLUGIN_VERSION,
            CATALOG_BUILDER_VERSION,
            PLUGIN_VERSION,
            CATALOG_BUILDER_VERSION,
            str(last_error)[:2000] if last_error else None,
            bool(completed),
        ),
    )
    db.commit()
    cur.close()


def finalize_preparation_if_settled(catalog_instance_id):
    state = preparation_state(catalog_instance_id)
    if not state or state["status"] not in ("running", "profiles_queued"):
        return state
    counts = analysis_status_counts(
        catalog_instance_id=catalog_instance_id,
        server_id=state["server_id"],
    )
    if counts["pending"] > 0:
        return state
    ready = (
        counts["needs_analysis"] == 0
        and counts["failed"] == 0
        and counts["skipped"] == 0
    )
    update_preparation_state(
        catalog_instance_id,
        state["server_id"],
        "ready" if ready else "needs_attention",
        "complete" if ready else "profiles_need_attention",
        queued_profiles=state["queued_profiles"],
        profile_jobs=state["profile_jobs"],
        last_error=None if ready else "One or more profiles could not be prepared.",
        completed=True,
    )
    return preparation_state(catalog_instance_id)


def prepare_lumae_task(server_id=None, catalog_instance_id=None):
    """Publish the app-ready catalogue first, then start optional enrichment."""
    if maintenance_paused():
        return {"status": "paused", "reason": "maintenance_paused"}
    resolved_server_id = server_id
    resolved_catalog_instance_id = catalog_instance_id
    try:
        resolved_server_id = resolved_server_id or get_core_adapter().active_server_id()
        source = resolve_profile_source(
            catalog_instance_id=resolved_catalog_instance_id,
            server_id=resolved_server_id,
        )
        resolved_catalog_instance_id = source["catalog_instance_id"]
        resolved_server_id = source["server_id"]
        if not claim_preparation_run(resolved_catalog_instance_id):
            return {
                "status": "coalesced",
                "reason": "already_running_or_not_requested",
                "catalog_instance_id": resolved_catalog_instance_id,
            }
        assert_preparation_worker_current(resolved_catalog_instance_id)
        _safe_progress("refreshing catalogue")
        update_preparation_state(
            resolved_catalog_instance_id,
            resolved_server_id,
            "running",
            "catalog_refresh",
        )
        started = _safe_catalog_refresh_clock()
        catalog_result = refresh_catalog(server_id=resolved_server_id)
        if catalog_result["catalog_instance_id"] != resolved_catalog_instance_id:
            raise CatalogScanError("Catalogue identity changed during preparation")
        _satisfy_catalog_refresh_wants(resolved_catalog_instance_id, started)
        if (
            int(catalog_result.get("builder_version") or 0) < CATALOG_BUILDER_VERSION
            or catalog_result.get("refresh_required") is not False
        ):
            raise CatalogScanError(
                "Catalogue refresh finished without publishing the current builder version"
            )
        _safe_progress("projecting AudioMuse analysis")
        update_preparation_state(
            resolved_catalog_instance_id,
            resolved_server_id,
            "running",
            "analysis_projection",
        )
        projection_result = project_analysis(
            server_id=resolved_server_id,
            adapter=get_core_adapter(),
        )
        if projection_result["catalog_instance_id"] != resolved_catalog_instance_id:
            raise CatalogScanError("Analysis identity changed during preparation")
        update_preparation_state(
            resolved_catalog_instance_id,
            resolved_server_id,
            "ready",
            "catalog_ready",
            completed=True,
        )
        try:
            _safe_progress("admitting volume and ramp work")
            profile_result = start_profile_backfill(
                catalog_instance_id=resolved_catalog_instance_id,
                server_id=resolved_server_id,
            )
        except Exception as exc:
            # The catalogue is already safe and usable. Enrichment failures
            # remain visible in their own state and never roll readiness back.
            logger.exception("lumae_analysis could not start background profile enrichment")
            profile_result = {"queued": False, "coalesced": False, "error": str(exc)}
        try:
            _safe_progress("admitting relationship work")
            relationship_result = start_relationship_preparation(
                catalog_instance_id=resolved_catalog_instance_id,
                server_id=resolved_server_id,
            )
        except Exception as exc:
            logger.exception(
                "lumae_analysis could not start background relationship enrichment"
            )
            relationship_result = {
                "queued": False,
                "coalesced": False,
                "error": str(exc),
            }
        return {
            "catalog": catalog_result,
            "analysis": projection_result,
            "profiles": profile_result,
            "relationships": relationship_result,
            "preparation": preparation_state(resolved_catalog_instance_id),
        }
    except Exception as exc:
        if resolved_catalog_instance_id and resolved_server_id:
            update_preparation_state(
                resolved_catalog_instance_id,
                resolved_server_id,
                "failed",
                "failed",
                last_error=exc,
                completed=True,
            )
        raise


_READINESS_BLOCKER_LABELS = {
    "analysis_links_missing": "Some eligible tracks do not have AudioMuse analysis yet.",
    "analysis_links_need_repair": "Some source-analysis links are flagged for automatic repair.",
    "analysis_links_pending": "Some eligible tracks are still awaiting AudioMuse analysis.",
    "analysis_mapping_incomplete": "Some eligible provider tracks do not have an AudioMuse mapping yet.",
    "analysis_projection_incomplete": "The plugin analysis projection is not complete.",
    "catalog_generation_incomplete": "The provider catalogue generation is not complete.",
    "chromaprint_backfill_incomplete": "Full-library verification is still waiting for Chromaprint; affected collision groups remain usable but provisional.",
    "chromaprint_collection_disabled": "Chromaprint collection is disabled in AudioMuse.",
    "chromaprint_gate_disabled": "Chromaprint duplicate validation is disabled in AudioMuse.",
    "duration_tolerance_too_wide": "The AudioMuse duplicate duration tolerance is wider than one second.",
    "folder_gate_not_active": "The fp_4 folder-aware duplicate rule is not active.",
    "fp_4_not_active": "AudioMuse catalogue ID scheme fp_4 is not active.",
    "no_analysis_mappings": "No provider tracks have AudioMuse analysis mappings yet.",
    "per_link_evidence_unavailable": "This plugin cannot qualify AudioMuse analysis links individually.",
    "provisional_links_remaining": "Some usable source-analysis links still have provisional evidence.",
    "readiness_unavailable": "The plugin could not read AudioMuse repair diagnostics.",
    "sonic_evidence_incomplete": "Full per-track sonic evidence is not complete yet.",
    "source_rebind_required": "Lumae still needs to verify the AudioMuse source identity during app sync.",
}


from .settings_render import (
    _v3_readiness_sources,
    _render_basic_source_analysis_panel,
    render_v3_readiness_panel,
    render_relationship_status_panel,
    _published_track_count,
    render_source_preparation_sections,
    render_source_preparation_panel,
    render_provider_identity_panel,
    _readiness_availability,
    _readiness_age_text,
    _readiness_job,
    _readiness_stream_status,
    render_readiness_streams_panel,
    _reconcile_duration,
    _reconcile_event_summary,
    render_reconcile_status_panel,
    render_settings_status_panels,
    render_publication_repair_form,
    render_settings,
    _READINESS_AVAILABILITY_LABEL,
    _READINESS_AVAILABILITY_CLASS,
    _READINESS_JOB_LABEL,
)


@bp.get("/settings/status")
def settings_status():
    return _private_json({"panels": render_settings_status_panels(configured_backfill_limit())})


@bp.route("/settings", methods=["GET", "POST"])
def settings():
    message = None
    error = None
    if request.method == "POST":
        try:
            action = request.form.get("action")
            if action in ("pause_maintenance", "resume_maintenance"):
                paused = action == "pause_maintenance"
                set_setting("maintenance_paused", paused)
                if not paused:
                    wake_runners(get_db(), "maintenance_resumed", commit=True)
                message = (
                    "Background maintenance paused. Published Lumae data remains available."
                    if paused
                    else "Background maintenance resumed."
                )
            elif action == "save_heavy_work":
                value = save_heavy_work(request.form.get("heavy_work"))
                wake_runners(get_db(), "heavy_work_changed", commit=True)
                message = {
                    "auto": "Heavy work runs in an AudioMuse worker while one is online.",
                    "server": "Heavy work runs on this server, with or without a worker.",
                    "worker": "Heavy work runs only in an AudioMuse worker.",
                }[value]
            elif action == "save_worker_runners":
                value = save_worker_runners(request.form.get("worker_runners"))
                limit = save_max_files_in_flight(request.form.get("max_files_in_flight"))
                wake_runners(get_db(), "worker_runners_changed", commit=True)
                message = {
                    "one": "One AudioMuse worker does Lumae's heavy work; the others wait.",
                    "every": (f"Every AudioMuse worker analyzes library tracks, at most {limit} "
                              "files at once across workers. Workers start helping within a minute."),
                }[value]
            elif action == "save_collections":
                enabled = request.form.get("collection_manager_enabled") == "on"
                set_setting("collection_manager_enabled", enabled)
                sync_collections_menu(enabled)
                message = f"Living Collections {'enabled' if enabled else 'disabled'}."
            elif action in ("ack_v3_readiness", "clear_v3_readiness"):
                message = (
                    "Manual AudioMuse verification is no longer required. "
                    "Lumae now verifies sonic readiness automatically from current evidence."
                )
            elif action in ("prepare_lumae", "start_backfill", "catch_up", "queue_all"):
                batch_size = normalize_backfill_limit(
                    request.form.get("backfill_batch_size") or DEFAULT_BACKFILL_BATCH_SIZE
                )
                set_setting("backfill_batch_size", batch_size)
                save_background_workers(request.form)
                source = resolve_profile_source(
                    catalog_instance_id=request.form.get("catalog_instance_id"),
                    server_id=request.form.get("server_id"),
                )
                catalog_instance_id = source["catalog_instance_id"]
                server_id = source["server_id"]
                if action == "prepare_lumae":
                    if not claim_preparation(source):
                        message = f"Preparation is already running for {source['name']}."
                    else:
                        message = (
                            f"Preparing {source['name']}: library refresh and app sync index first, "
                            "then fair background volume and ramp work. Lumae can sync as soon as "
                            "the first two phases complete."
                        )
                else:
                    # Legacy catch_up/queue_all form submissions from an open
                    # 0.8.0 page intentionally map to the bounded 0.8.1 chain.
                    result = start_profile_backfill(
                        catalog_instance_id=catalog_instance_id,
                        server_id=server_id,
                    )
                    message = (
                        f"Background enrichment is already running for {source['name']}."
                        if result["coalesced"]
                        else f"Started background enrichment for {source['name']} in batches of "
                        f"{result['batch_size']}. Playback requests are prioritized separately."
                    )
            elif action == "retry_edge_profiles":
                # LUM-017 (P3-9): edge profiles had no settings-page retry path;
                # this makes the library pass due now, as the app-facing
                # backfill API does (``request_edge_profiles``, R6).
                source = resolve_profile_source(
                    catalog_instance_id=request.form.get("catalog_instance_id"),
                    server_id=request.form.get("server_id"),
                )
                ids = edge_backfill_candidates(get_db(), source["catalog_instance_id"], "", 100)
                result = request_edge_profiles(ids, source["catalog_instance_id"])
                if not result.get("available"):
                    message = "Edge profile upgrades are currently disabled or paused."
                else:
                    message = (
                        f"Lumae's edge pass for {source['name']} runs next; "
                        f"{format_count(len(ids))}{'+' if len(ids) >= 100 else ''} "
                        "track(s) still need an edge."
                        if ids else f"Every track of {source['name']} has an edge."
                    )
            elif action == "retry_relationships":
                # LUM-017 (P3-9): relationships had no settings-page retry
                # path; this wires the existing coalesced request the app API
                # already uses (``start_relationship_preparation``).
                source = resolve_profile_source(
                    catalog_instance_id=request.form.get("catalog_instance_id"),
                    server_id=request.form.get("server_id"),
                )
                result = start_relationship_preparation(
                    catalog_instance_id=source["catalog_instance_id"],
                    server_id=source["server_id"],
                    force=True,
                )
                if result.get("coalesced"):
                    message = (
                        f"Relationships for {source['name']}: "
                        f"{(result.get('reason') or 'already up to date').replace('_', ' ')}."
                    )
                else:
                    message = f"Queued a relationship rebuild for {source['name']}."
            elif action == "repair_profile_publications":
                result = repair_profile_publications()
                message = (
                    f"Withdrew {format_count(result['withdrawn'])} published profiles of "
                    "tracks no longer in the catalogue and republished "
                    f"{format_count(result['republished'])} ready profiles. Left: "
                    f"{format_count(result['profiles_orphaned'] or 0)} orphaned and "
                    f"{format_count(result['profiles_unpublished_ready'] or 0)} unpublished "
                    "ready profiles; run the repair again while either is above 0."
                )
            elif action == "save":
                batch_size = normalize_backfill_limit(
                    request.form.get("backfill_batch_size") or DEFAULT_BACKFILL_BATCH_SIZE
                )
                set_setting("backfill_batch_size", batch_size)
                save_background_workers(request.form)
                message = "Lumae analysis settings saved."
        except (KeyError, ValueError, CatalogScanError, RuntimeError) as exc:
            error = str(exc)

    return render_settings(message=message, error=error)


@bp.route("/database-state", methods=["GET"])
def database_state_page():
    compatibility = detect_core()
    db = get_db()
    try:
        sources = []
        if db is not None:
            # Every read of this page runs under the diagnostic statement
            # timeout, in a savepoint that is rolled back (P3-10).
            with bounded_reads(db):
                sources = resolve_catalog_source(db)
        readiness = None
        if db is not None and compatibility.adapter == "v3_registry":
            policy = dedup_policy()

            def v3_readiness(source):
                return v3_release_readiness(db, compatibility, source, policy)

            readiness = v3_readiness
        snapshot = collect_database_state(
            db,
            compatibility,
            sources,
            readiness=readiness,
        )
    except Exception as exc:
        logger.warning(
            "lumae_analysis could not collect database state (%s)", type(exc).__name__
        )
        snapshot = {
            "captured_at": utc_now_iso(),
            "status": "unavailable",
            "core": compatibility.as_dict(),
            "sources": [],
            "errors": [safe_snapshot_error(exc)],
        }
    return render_page(
        render_database_state(snapshot),
        title="Lumae Database State",
    )


# Runner plan R2: modules the actions import inside functions, imported before
# the first action. An upgrade replaces the plugin's files under a running
# process; the runner stops at its next turn (``_runner_code_current``), and a
# lazy import meanwhile would mix versions. Decoders run in exec children,
# which import from disk anyway.
RUNNER_PRELOAD_MODULES = (
    "catalog", "catalog_analysis", "catalog_enrichment", "collection_manager", "covers",
    "credits_store", "file_tags", "jellyfin_continuity", "jellyfin_provider", "journeys",
    "loudness_backfill", "loudness_stream", "music_metadata", "profile_publication",
    "provider_identity_rekey", "redaction", "relationship_build", "shelves", "status_model",
    "vibes",
)


def _runner_code_current():
    """R2: this process still runs the installed plugin. AudioMuse has no hot
    reload: an upgrade, a disable or an uninstall waits for a restart, and
    the runner must not go on with the old code meanwhile. True when the
    host does not say (older hosts, tests)."""
    try:
        from plugin.manager import plugin_manager
    except Exception:
        return True
    record = (getattr(plugin_manager, "records", None) or {}).get("lumae_analysis")
    if record is not None and not record.get("enabled", True):
        return False
    snapshot = (getattr(plugin_manager, "_boot_snapshot", None) or {}).get("lumae_analysis")
    if snapshot is None:
        return True
    db = get_db()
    try:
        import database

        row = database.get_plugin("lumae_analysis", conn=db)
        db.commit()
    except Exception:
        _rollback_if_possible(db)
        return True
    if not row:
        return False
    return (row.get("checksum"), bool(row.get("enabled"))) == tuple(snapshot)


def _preload_runner_modules():
    for name in RUNNER_PRELOAD_MODULES:
        try:
            importlib.import_module(f"{__name__}.{name}")
        except Exception:
            logger.warning("lumae_analysis could not preload %s for the runner", name)


def start_runner(role):
    """Start this process's ``role`` runner (R1, R2); never raises, never blocks."""
    try:
        from flask import current_app

        app = current_app._get_current_object()
    except Exception:
        logger.warning("lumae_analysis cannot start its %s runner outside an application", role)
        return None
    try:
        import database

        connect_raw = database.connect_raw
    except Exception:
        logger.warning("lumae_analysis cannot start its %s runner: this AudioMuse has no "
                       "database.connect_raw", role)
        _record_runner_unavailable(role, "host_without_connect_raw")
        return None
    _preload_runner_modules()
    return runner.start(
        role, app=app, turn=run_runner_turn,
        connect=lambda name: connect_raw(application_name=name),
        still_installed=_runner_code_current,
        can_help=_worker_may_help if role == runner.ROLE_WORKER else None,
    )


def _record_runner_unavailable(role, reason):
    db = None
    try:
        db = get_db()
        with db.cursor() as cur:
            runner.record_unavailable(cur, role, reason)
        db.commit()
    except Exception:
        if db is not None:
            _rollback_if_possible(db)


def flask_start():
    """``on_flask_start``: observe provider identities, start the server runner."""
    try:
        observe_provider_identities_on_start()
    finally:
        _revoke_stranded_tasks_on_start()
        try:
            # The server runner's downloads of a process that is gone.
            analysis_download.remove_leftovers(getattr(config, "TEMP_DIR", None))
        except Exception:
            logger.warning("lumae_analysis could not remove leftover analysis downloads")
        start_runner(runner.ROLE_SERVER)


def worker_start():
    """``on_worker_start``: report the edge runtime, start the worker runner."""
    try:
        report_edge_runtime_on_start()
    finally:
        start_runner(runner.ROLE_WORKER)


# Runner plan R1: the lanes. The server runner does the light lane, the worker
# runner the heavy lane; the server takes heavy actions only as heavy_work and
# the worker's heartbeat allow.
LIGHT_ACTIONS = frozenset((
    "edge_schema_v3", "analysis_run", "catalog_preparation", "catalog_refresh",
    "identity_recheck", "collection_retention", "analysis_projection", "credits",
    "music_metadata",
))
# R8: the retention schedule's replacement, once a day.
COLLECTION_RETENTION_SECONDS = 24 * 60 * 60
HEAVY_ACTIONS = frozenset((
    "interactive", "relationships", "profile_backfill", "edge_backfill", "loudness_backfill",
))
# R4: these wait while AudioMuse analyses (its song hook does the run's songs).
PER_TRACK_ACTIONS = frozenset(("profile_backfill", "edge_backfill", "loudness_backfill"))
HEAVY_WORK_SETTINGS = ("auto", "server", "worker")
# R4: the worker runner steps aside for every AudioMuse job (they need the
# worker's CPU and GPU); the server runner for those that rewrite track IDs.
WORKER_YIELD_TASK_TYPES = (
    "main_analysis", "main_clustering", "cleaning", "provider_migration", "server_sweep",
    "naming_preview",
)
# R3: each action gets this long from when it is chosen; a turn chooses
# actions for up to RUNNER_TURN_SECONDS, then the runner heartbeats and looks
# for a change of plugin before the next.
RUNNER_SLICE_SECONDS = 15
RUNNER_TURN_SECONDS = 300
# While an AudioMuse job holds a runner back it looks again this often.
RUNNER_HOST_WAIT_SECONDS = 60
# An analysis run in its settling grace is due again within this.
RUNNER_WAITING_SECONDS = 60
# R5: ``background_workers`` ``auto`` in the web process.
WEB_AUTO_WORKERS = 2


class SliceBudget:
    """The budget ``_next_reconcile_action`` reads, for one runner action:
    every action fits, and it has RUNNER_SLICE_SECONDS from now."""

    def __init__(self, seconds=None):
        self.deadline = time.monotonic() + (RUNNER_SLICE_SECONDS if seconds is None else seconds)

    def remaining(self):
        return max(0.0, self.deadline - time.monotonic())

    def fits(self, _action):
        return True

    def start(self):
        pass


def heavy_work_setting():
    """``heavy_work``: which runner does the heavy lane (R1). ``auto`` the
    worker's while one is online, else on-demand tracks on the server;
    ``server`` all of it on the server; ``worker`` none on the server."""
    value = str(get_setting("heavy_work", "auto") or "auto").strip().lower()
    return value if value in HEAVY_WORK_SETTINGS else "auto"


def save_heavy_work(value):
    """The settings form's ``heavy_work``; returns the stored value."""
    value = str(value or "").strip().lower()
    if value not in HEAVY_WORK_SETTINGS:
        raise ValueError("Heavy work must be auto, server or worker.")
    set_setting("heavy_work", value)
    return value


# Multi-worker plan (2026-10-30): ``worker_runners`` says whether the worker
# processes that do not lead help with the per-track passes (``every``) or
# stand by (``one``, 1.9's behaviour and the default).
WORKER_RUNNERS_SETTINGS = ("one", "every")
# R6: files analysed at once across every worker runner.
DEFAULT_MAX_FILES_IN_FLIGHT = 16
MAX_FILES_IN_FLIGHT_LIMIT = 64
# A helper whose turn found every analysis slot taken looks again after this.
SLOT_WAIT_SECONDS = 30


def worker_runners_setting():
    value = str(get_setting("worker_runners", "one") or "one").strip().lower()
    return value if value in WORKER_RUNNERS_SETTINGS else "one"


def save_worker_runners(value):
    """The settings form's ``worker_runners``; returns the stored value."""
    value = str(value or "").strip().lower()
    if value not in WORKER_RUNNERS_SETTINGS:
        raise ValueError("Worker runners must be one or every.")
    set_setting("worker_runners", value)
    return value


def normalize_max_files_in_flight(raw):
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return DEFAULT_MAX_FILES_IN_FLIGHT
    return min(max(value, 1), MAX_FILES_IN_FLIGHT_LIMIT)


def max_files_in_flight():
    return normalize_max_files_in_flight(get_setting("max_files_in_flight", DEFAULT_MAX_FILES_IN_FLIGHT))


def save_max_files_in_flight(raw):
    """The settings form's ``max_files_in_flight``; returns the stored value."""
    value = normalize_max_files_in_flight(raw)
    set_setting("max_files_in_flight", value)
    return value


def shared_passes():
    """Whether every worker runner walks the per-track passes (``worker_runners: every``)."""
    return worker_runners_setting() == "every"


def _worker_may_help():
    """``Runner.can_help`` for the worker role: helpers only with ``every``, and
    only while the worker lane does the heavy work."""
    return shared_passes() and heavy_work_setting() != "server"


# W3: the status page's count of files Lumae has stopped trying, counted at
# most this often (the panel is polled).
PARKED_FILES_SECONDS = 300
_parked_files = None


def parked_files(db):
    """W3's parked files over the active sources: loudness ``too_long``
    (never downloaded) and ``parked`` (failed for good on the current file),
    and edges ``unsupported`` on the current file. ``None`` when unreadable."""
    global _parked_files
    now = time.monotonic()
    if _parked_files is not None and now - _parked_files[0] < PARKED_FILES_SECONDS:
        return _parked_files[1]
    try:
        with db.cursor() as cur:
            cur.execute(f"SELECT catalog_instance_id FROM {table('catalog_sources')} "
                        "WHERE rebind_status='active'")
            sources = [row[0] for row in cur.fetchall()]
            cur.execute(f"SELECT count(*) FROM {table('edge_profile_jobs')} "
                        "WHERE status='unsupported' AND catalog_instance_id = ANY(%s)", (sources,))
            edges = int(cur.fetchone()[0] or 0)
        db.commit()
        totals = {"too_long": 0, "parked": 0, "edge_unsupported": edges}
        for source in sources:
            for key, count in loudness_backfill.parked_counts(db, source).items():
                totals[key] += count
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis could not count the files it stopped trying", exc_info=True)
        return None
    _parked_files = (now, totals)
    return totals


def runner_lane(db, role):
    """``(actions, reason)``: what ``role`` may run now (R1)."""
    setting = heavy_work_setting()
    if role == runner.ROLE_WORKER:
        if setting == "server":
            return frozenset(), "heavy_work_on_server"
        return HEAVY_ACTIONS, "heavy_lane"
    if setting == "server":
        return LIGHT_ACTIONS | HEAVY_ACTIONS, "heavy_work_on_server"
    if setting == "worker":
        return LIGHT_ACTIONS, "light_lane"
    try:
        with db.cursor() as cur:
            online = runner.worker_online(cur)
        db.commit()
    except Exception:
        _rollback_if_possible(db)
        online = False
    if online:
        return LIGHT_ACTIONS, "light_lane"
    return LIGHT_ACTIONS | {"interactive"}, "no_worker_online"


def _runner_blocker(db, role):
    types = (WORKER_YIELD_TASK_TYPES if role == runner.ROLE_WORKER
             else reconcile.ID_REWRITING_TASK_TYPES)
    return reconcile.live_host_task(db, types)


def _runner_next_due_seconds(db):
    """Seconds until the soonest retry in the work tables, or None (R2's sleep)."""
    try:
        with db.cursor() as cur:
            summary = reconcile._work_summary(cur)
        db.commit()
    except Exception:
        _rollback_if_possible(db)
        return None
    due = summary.get("retry_in_seconds")
    if summary.get("waiting"):
        due = RUNNER_WAITING_SECONDS if due is None else min(due, RUNNER_WAITING_SECONDS)
    return due


def run_runner_turn(active):
    """One turn of ``active`` (runner.Runner): today's actions in today's order
    (``_next_reconcile_action``) for every source, within the runner's lane,
    each in a slice of its own, until none is due or RUNNER_TURN_SECONDS
    pass, stepping aside for AudioMuse before each (R3, R4)."""
    if getattr(active, "helping", False):
        return run_helper_turn(active)
    db = get_db()
    role = active.role
    if active.new_leader:
        # The role's previous leader went away mid-work, or this one starts
        # again after a failure: the on-demand work it took waits again.
        _safe_release_runner_claims(db, role)
    if maintenance_paused():
        return runner.Turn(False, "paused", "maintenance_paused", None, None)
    blocker = _runner_blocker(db, role)
    if blocker:
        return runner.Turn(False, "waiting_host", f"audiomuse:{blocker}",
                           RUNNER_HOST_WAIT_SECONDS, None)
    allowed, lane = runner_lane(db, role)
    if role == runner.ROLE_SERVER:
        _runner_bookkeeping(db)
    if not allowed:
        return runner.idle_turn(None, lane)
    # Multi-worker plan: with ``every`` the worker leader walks the per-track
    # passes with the helpers, a batch at a time, and parks a pass only when
    # no runner can make it (R5).
    shared = role == runner.ROLE_WORKER and _safe_shared_passes()
    if shared and active.new_leader:
        _requeue_waveform_claims(db)
    if role == runner.ROLE_WORKER:
        report_edge_runtime(park=not shared)
    elif allowed & HEAVY_ACTIONS:
        # R7: the web process qualifies its own runtime before heavy work.
        report_edge_runtime(park=False)
    done = {action for action in LIGHT_ACTIONS | HEAVY_ACTIONS if action not in allowed}
    if "credits" in done:
        done.update(("credits:before_background", "music_metadata:before_background"))
    if PER_TRACK_ACTIONS & allowed and reconcile.live_host_task(db, ("main_analysis",)):
        done.update(PER_TRACK_ACTIONS)
    workers, sizing = background_sizing()
    slots = None
    if shared:
        _release_gone_waveform(db)
        # R6: the leader's analysis threads count towards the files in flight
        # too, but only while a per-track pass runs (_LeaderSlots).
        slots = _LeaderSlots(db, active, workers)
        sizing = f"{sizing}; at most {max_files_in_flight()} files in flight across workers"
    active.files_at_once = None if shared else workers
    report = TurnReport()
    started = time.monotonic()
    worked = None
    waited = False
    # Credits sweep once a turn (S8); the K analysis threads (WP1b) start on
    # first use and stop, with their analysis workers, when the turn ends.
    credits_service.begin_tick()
    try:
        with parallel_analysis.tick_scope(workers, sizing):
            while time.monotonic() - started < RUNNER_TURN_SECONDS and not active.stopped.is_set():
                action, result = _next_runner_action(db, report, active, done, shared, slots)
                if action is None:
                    break
                status = str((result or {}).get("status") or "") if isinstance(result, dict) else ""
                waited = waited or _held_back(result)
                if _moved_on(status, result):
                    worked = action
                if status in _SETTLED_STATUSES or (status == "complete" and action in _COMPLETE_SETTLES):
                    done.add(action)
                blocker = _runner_blocker(db, role)
                if blocker:
                    return runner.Turn(True, "waiting_host", f"audiomuse:{blocker}",
                                       RUNNER_HOST_WAIT_SECONDS, worked)
                if active.stopped.wait(runner.PAUSE_SECONDS):
                    break
    finally:
        credits_service.end_tick()
        if shared:
            _safe_release_slots(db)
        if report.actions:
            _refresh_status_after_turn(db, report)
    if worked:
        return runner.Turn(True, "working", lane, None, worked)
    if waited:
        return runner.idle_turn(PASS_WAIT_SECONDS, EARLIER_PASS_RUNNING)
    return runner.idle_turn(_runner_next_due_seconds(db))


def _held_back(result):
    """Whether an action's pass waited for an earlier pass another runner walks."""
    return isinstance(result, dict) and result.get("reason") == EARLIER_PASS_RUNNING


def _safe_shared_passes():
    try:
        return shared_passes()
    except Exception:
        logger.warning("lumae_analysis could not read worker_runners; one worker runner works",
                       exc_info=True)
        return False


def _safe_acquire_slots(db, workers):
    """R6: up to ``workers`` analysis slots for this runner's turn; 0 when none
    is free or the slots cannot be read."""
    try:
        return shared_pass.acquire_slots(db, workers, max_files_in_flight())
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis could not take analysis slots", exc_info=True)
        return 0


def _safe_release_slots(db):
    try:
        shared_pass.release_slots(db)
    except Exception:
        _rollback_if_possible(db)
        # Freed once this runner's heartbeat stops.
        logger.warning("lumae_analysis could not give back its analysis slots", exc_info=True)


class _LeaderSlots:
    """R6 for a shared leader turn: up to ``workers`` analysis slots for each
    per-track pass, given back when the pass returns. A turn also runs the
    leader's relationship and catalogue work, which analyses no file; holding
    the slots through it left the helpers half the files in flight (owner's
    server, 2026-10-31: a relationship build held 8 of 16 for minutes)."""

    def __init__(self, db, active, workers):
        self.db, self.active, self.workers = db, active, workers

    def take(self, done):
        granted = _safe_acquire_slots(self.db, self.workers)
        if not granted:
            # The helpers have every slot: this turn leaves the passes to them.
            done.update(PER_TRACK_ACTIONS)
            return False
        pool = parallel_analysis.current()
        if pool is not None:
            pool.workers = granted
        self.active.files_at_once = granted
        return True

    def give_back(self):
        _safe_release_slots(self.db)
        self.active.files_at_once = None


@contextmanager
def _pass_slots(slots, done):
    """Whether a per-track pass may run now; a shared leader holds its slots
    (``_LeaderSlots``) for the pass alone."""
    if slots is None:
        yield True
        return
    if not slots.take(done):
        yield False
        return
    try:
        yield True
    finally:
        slots.give_back()


# Multi-worker plan R1: what a helper turn may do, in this order.
HELPER_ACTIONS = ("profile_backfill", "edge_backfill", "loudness_backfill")
# A helper's turn is short: between turns it tries the role's lock, so a
# leader that went away is replaced within about a minute, as by a runner
# standing by (multi-worker plan R1).
HELPER_TURN_SECONDS = runner.STANDBY_SECONDS


def run_helper_turn(active):
    """One turn of a helper (multi-worker plan R1): only the per-track passes,
    shared with the leader and the other helpers, on the analysis threads
    its slots allow (R6). It steps aside for AudioMuse as the leader does and
    serves no on-demand work (``serve_interactive``)."""
    db = get_db()
    if maintenance_paused():
        return runner.Turn(False, "paused", "maintenance_paused", None, None)
    if not _safe_shared_passes():
        return runner.idle_turn(None, "one_worker_runner")
    blocker = _runner_blocker(db, runner.ROLE_WORKER)
    if blocker:
        return runner.Turn(False, "waiting_host", f"audiomuse:{blocker}",
                           RUNNER_HOST_WAIT_SECONDS, None)
    allowed, lane = runner_lane(db, runner.ROLE_WORKER)
    if not allowed & PER_TRACK_ACTIONS:
        return runner.idle_turn(None, lane)
    if reconcile.live_host_task(db, ("main_analysis",)):
        # R4: AudioMuse's song hook does the run's songs.
        return runner.Turn(False, "waiting_host", "audiomuse:main_analysis",
                           RUNNER_HOST_WAIT_SECONDS, None)
    report_edge_runtime(park=False)
    _release_gone_waveform(db)
    workers, sizing = background_sizing()
    granted = _safe_acquire_slots(db, workers)
    if not granted:
        return runner.Turn(False, "waiting", "files_in_flight_cap", SLOT_WAIT_SECONDS, None)
    active.files_at_once = granted
    report = TurnReport()
    started = time.monotonic()
    worked = None
    waited = False
    done = set()
    try:
        with parallel_analysis.tick_scope(
                granted, f"{sizing}; {granted} of {max_files_in_flight()} files in flight across workers"):
            while time.monotonic() - started < HELPER_TURN_SECONDS and not active.stopped.is_set():
                action, result = _next_helper_action(db, report, active, done)
                if action is None:
                    break
                status = str((result or {}).get("status") or "") if isinstance(result, dict) else ""
                waited = waited or _held_back(result)
                if _moved_on(status, result):
                    worked = action
                if status in _SETTLED_STATUSES or status == "complete":
                    done.add(action)
                if _runner_blocker(db, runner.ROLE_WORKER) or reconcile.live_host_task(db, ("main_analysis",)):
                    break
                if active.stopped.wait(runner.PAUSE_SECONDS):
                    break
    finally:
        _safe_release_slots(db)
        if report.actions:
            _refresh_status_after_turn(db, report)
    if worked:
        return runner.Turn(True, "working", "helper", None, worked)
    if waited:
        return runner.idle_turn(PASS_WAIT_SECONDS, EARLIER_PASS_RUNNING)
    return runner.idle_turn(None, "helper_nothing_due")


def _next_helper_action(db, report, active, done):
    """One helper action in a slice of its own: the first per-track pass with
    work for it. ``(action, result)``, or ``(None, None)`` when none has."""
    for action in HELPER_ACTIONS:
        if action in done:
            continue
        budget = SliceBudget()
        active.begin_action(action)
        ran = False
        try:
            source = _next_shared_source(db, action)
            if source is None:
                done.add(action)
                continue
            start = time.monotonic()
            function = {"profile_backfill": helper_profile_batch_task,
                        "edge_backfill": edge_backfill_task,
                        "loudness_backfill": loudness_backfill_task}[action]
            args = (source[0], source[1], budget.deadline) + (() if action == "profile_backfill" else (True,))
            result = _call_action(function, source[0], *args)
            status = str((result or {}).get("status") or "")
            ran = status not in ("coalesced", "current")
            if ran:
                _record_turn(db, report, action, source[0], source[1], result, start)
            return action, result
        except Exception:
            _rollback_if_possible(db)
            logger.warning("lumae_analysis helper action %s failed; it is retried", action,
                           exc_info=True)
            done.add(action)
            return action, {"status": "failed"}
        finally:
            active.end_action(ran=ran)
    return None, None


def _next_shared_source(db, action):
    """``(server_id, catalog_instance_id)`` of a source whose ``action`` pass a
    helper can share now, or None."""
    if action == "profile_backfill":
        with db.cursor() as cur:
            cur.execute(
                f"""SELECT st.server_id, st.catalog_instance_id
                      FROM {profile_backfill_state_table()} st
                      JOIN {table('catalog_sources')} s USING (catalog_instance_id)
                     WHERE s.rebind_status='active' AND st.status IN ('queued', 'running', 'failed')
                     ORDER BY st.updated_at, st.catalog_instance_id LIMIT 1"""
            )
            row = cur.fetchone()
        db.commit()
        return (str(row[0]), str(row[1])) if row else None
    if action == "edge_backfill":
        if not edge_profiles_enabled():
            return None
        edge = next_edge_backfill(db, shared=True)
        return (edge[0], edge[1]) if edge else None
    if not loudness_backfill.runtime_available():
        return None
    return next_loudness_backfill(db, shared=True)


# The server runner's bookkeeping (what 1.8.0's watchdog tick did) at most this often.
RUNNER_BOOKKEEPING_SECONDS = 60
_runner_bookkeeping_at = None


def _runner_bookkeeping(db):
    """Events whose process went away become ``interrupted``, the on-demand
    work a worker runner that went away had taken waits again, catalogues
    that need a publication (first run, a builder upgrade) are claimed for
    preparation, and a publication left without a summary gets one, with the
    waveform counts at most every STATUS_SNAPSHOT_IDLE_SECONDS, as each 1.8.0
    tick did (P2-1, S8). Never raises."""
    global _runner_bookkeeping_at
    now = time.monotonic()
    if _runner_bookkeeping_at is not None and now - _runner_bookkeeping_at < RUNNER_BOOKKEEPING_SECONDS:
        return
    _runner_bookkeeping_at = now
    try:
        recover_interrupted_events(db)
        enqueue_required_catalog_preparations(db=db)
        _safe_release_runner_claims(db, runner.ROLE_WORKER, runner.WORKER_ONLINE_SECONDS)
        # Multi-worker plan R2: rows of runners gone for a day.
        with db.cursor() as cur:
            runner.prune_workers(cur)
        db.commit()
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis runner bookkeeping failed")
    refresh_status_snapshot(db, min_age_seconds=STATUS_SNAPSHOT_IDLE_SECONDS, publications=True)


def _refresh_status_after_turn(db, report):
    """The waveform counts /settings/status reads follow the turn's work; a
    publication left without a summary gets one (P2-1). A turn that changed no
    profile state counts them at most every STATUS_SNAPSHOT_IDLE_SECONDS (S8)."""
    try:
        if _changed_profile_state(report):
            refresh_status_snapshot(db, publications=True)
        else:
            refresh_status_snapshot(db, min_age_seconds=STATUS_SNAPSHOT_IDLE_SECONDS,
                                    publications=True)
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not refresh the status snapshot")


def _next_runner_action(db, report, active, done, shared=False, slots=None):
    """One action of the turn in a slice of its own; ``active`` shows each
    action while the turn looks for its work and does it (``fits``), and
    counts the one that ran (``start``). ``shared``: the per-track passes are
    walked with the helpers (multi-worker plan R4), on ``slots`` (R6)."""

    class Budget(SliceBudget):
        last = None
        ran = False

        def fits(self, action):
            self.last = action
            active.begin_action(action)
            return True

        def start(self):
            self.ran = True

    budget = Budget()
    try:
        return _next_reconcile_action(db, report, budget, None, done, shared=shared, slots=slots)
    except AnalysisProjectionDeferred as exc:
        # Held back by design (an unresolved provider identity, say): the
        # journal keeps the retry, and the log needs no traceback (R9).
        _rollback_if_possible(db)
        logger.warning("lumae_analysis runner action %s waits: %s", budget.last, exc)
        done.add(budget.last)
        return budget.last, {"status": "failed"}
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis runner action %s failed; it is retried",
                       budget.last, exc_info=True)
        done.add(budget.last)
        return budget.last, {"status": "failed"}
    finally:
        active.end_action(ran=budget.ran)


def register(ctx):
    ctx.add_blueprint(bp)
    ctx.set_settings_page("lumae_analysis.settings")
    if collections_enabled():
        ctx.add_menu_item(COLLECTIONS_MENU_LABEL, COLLECTIONS_MENU_ENDPOINT)
    ctx.on_install(migrate)
    ctx.on_flask_start(flask_start)
    if hasattr(ctx, "on_worker_start"):
        ctx.on_worker_start(worker_start)
    ctx.on_song_analyzed(analyze_song_hook)
    # Runner plan R8: no task is registered. AudioMuse lists every registered
    # name under Scheduled Tasks with an Enable box, and an enabled row would
    # put a Lumae task back on its queue. A job an older version queued runs
    # by its dotted path, which stays.


