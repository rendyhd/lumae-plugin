"""EdgeProfileV2: bounded source-timeline measurements for transition planning.

The decoder, resampler and all recursive filters remain continuous for the whole
source. Only the first and last 30 seconds of measurements and canonical PCM are
retained. Exact digital zero is reported separately from adaptive quiet regions;
only the former can ever authorize padding trim.
"""

import base64
import hashlib
import json
import math
import os
import struct
import tempfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from scipy.signal import butter, lfilter, resample_poly

SCHEMA_VERSION = 2
ANALYZER_VERSION = "lumae-edge-v2.0.0"
METHOD = "lumae-edge-kweighted-bands-48k-k4-v2"
QUANTIZATION = "s16le-centidb-u16le-q15-v2"
CANONICAL_RATE = 48_000
EDGE_SECONDS = 30
ZERO_CDB = -32768
MAX_SOURCE_RATE = 384_000
MAX_SECONDS = 6553.6
BLOCK_FRAMES = 65_536
TRUE_PEAK_OVERSAMPLE = 4
CROSSOVER_HZ = (150, 2500)
# PyAV is not pinned: any release at or above this floor is accepted once its
# decode+resample runtime reproduces the qualification reference (below).
PYAV_MINIMUM = (16, 0)
QUALIFICATION_FILE = "edge_qualification_v2.json"
# Largest per-value difference a qualified runtime may show against the
# reference (see EDGE_PROFILES.md for the measured PyAV 16.1.0 / 17.1.0
# differences). Frame counts, boundaries, digital-zero positions, flags and
# every other field must match exactly.
QUALIFICATION_CDB_TOLERANCE = 2
QUALIFICATION_Q15_TOLERANCE = 4
_B1 = (1.53512485958697, -2.69169618940638, 1.19839281085285)
_A1 = (1.0, -1.69065929318241, 0.73248077421585)
_B2 = (1.0, -2.0, 1.0)
_A2 = (1.0, -1.99004745483398, 0.99007225036621)
_LOW_B, _LOW_A = butter(4, CROSSOVER_HZ[0], btype="low", fs=CANONICAL_RATE)
_MID_B, _MID_A = butter(4, CROSSOVER_HZ[1], btype="low", fs=CANONICAL_RATE)


class EdgeProfileError(ValueError):
    pass


class EdgeAnalysisTimeout(EdgeProfileError):
    """The soft deadline (LUM-007 category ``analysis_timeout``)."""


def canonical_json(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def opaque_revision(media_signature):
    if not media_signature:
        return None
    return "sha256:" + hashlib.sha256(str(media_signature).encode("utf-8")).hexdigest()


def profile_digest(payload):
    return hashlib.sha256(canonical_json({k: v for k, v in payload.items() if k != "profile_digest"}).encode("utf-8")).hexdigest()


def quantize_db(value, *, peak=False):
    if not math.isfinite(value) or value < 0:
        raise EdgeProfileError("non-finite or negative measurement")
    if value == 0:
        return ZERO_CDB
    db = (20 if peak else 10) * math.log10(value) * 100
    quantized = math.ceil(db) if peak else math.floor(db + 0.5)
    if not -32767 <= quantized <= 32767:
        raise EdgeProfileError("measurement outside centidB range")
    if peak and 10 ** (quantized / 2000) < value:
        quantized += 1
    if not -32767 <= quantized <= 32767:
        raise EdgeProfileError("measurement outside centidB range")
    return quantized


def _q15(value):
    if not math.isfinite(value):
        raise EdgeProfileError("non-finite normalized measurement")
    return max(0, min(32768, int(round(value * 32768))))


def _check_deadline(deadline):
    if deadline is not None and time.monotonic() >= deadline:
        raise EdgeAnalysisTimeout("edge analysis deadline exceeded")


_QUALIFYING = threading.local()
_STATUS_LOCK = threading.Lock()
_STATUS = None


def _version_tuple(text):
    parts = []
    for piece in str(text).split("."):
        digits = ""
        for char in piece:
            if not char.isdigit():
                break
            digits += char
        if not digits:
            break
        parts.append(int(digits))
    return tuple(parts)


def _import_av():
    """PyAV at or above the floor, without runtime qualification."""
    import av
    if _version_tuple(av.__version__)[:2] < PYAV_MINIMUM:
        raise EdgeProfileError("edge analysis requires PyAV >= %d.%d" % PYAV_MINIMUM)
    if not av.library_versions.get("libswresample"):
        raise EdgeProfileError("edge analysis requires libswresample")
    return av


def _swr_text(av):
    return ".".join(str(value) for value in av.library_versions["libswresample"])


def _av():
    if getattr(_QUALIFYING, "active", False):
        return _import_av()
    status = edge_runtime_status()
    if not status["available"]:
        raise EdgeProfileError("edge runtime unavailable: " + str(status["reason"]))
    return _import_av()


# Qualification: the runtime must reproduce, through the production code
# paths, reference payloads recorded with PyAV 16.1.0 / libswresample 6.1.100
# (edge_qualification_v2.json). Case "golden-pcm" is the published
# cross-language golden input; the WAV cases go through analyze_edge_file, so
# the real demuxer, decoder, layout detection and a 44.1 kHz up / 96 kHz down
# resample are exercised.
def qualification_wav(case):
    """Deterministic WAVE_FORMAT_EXTENSIBLE s16 bytes for a qualification case."""
    rate, channels, frames, lead = case["sample_rate"], case["channels"], case["frames"], case["leading_zero_frames"]
    t = np.arange(frames, dtype=np.float64) / rate
    envelope = np.minimum(1.0, t / 0.25)
    tones = [(0.3, 1000.0), (0.2, 12000.0)] if channels == 2 else [(0.25, 440.0)]
    pcm = np.stack([amp * envelope * np.sin(2 * np.pi * hz * t) + 0.05 * np.sin(2 * np.pi * 60.0 * t) for amp, hz in tones])
    pcm[:, :lead] = 0
    samples = np.round(pcm.T * 32767).astype("<i2")
    mask = 3 if channels == 2 else 4
    fmt = struct.pack("<HHIIHHHHI16s", 0xfffe, channels, rate, rate * channels * 2, channels * 2, 16, 22, 16, mask,
                      bytes.fromhex("0100000000001000800000aa00389b71"))
    data = b"fmt " + struct.pack("<I", len(fmt)) + fmt + b"data" + struct.pack("<I", samples.nbytes) + samples.tobytes()
    return b"RIFF" + struct.pack("<I", len(data) + 4) + b"WAVE" + data


def golden_pcm():
    """The published cross-language golden input (48 kHz stereo float PCM)."""
    t = np.arange(10003, dtype=np.float64) / 48000
    pcm = np.asarray([.1 * np.sin(2 * np.pi * 1000 * t), .08 * np.sin(2 * np.pi * 400 * t)], dtype=np.float32)
    pcm[:, :403] = 0
    return pcm


_IDENTITY = dict(catalog_instance_id="catalog-a", track_id="track-a", media_revision="sha256:" + "a" * 64)


def run_qualification_case(case):
    """Measure one qualification case with the production analyzer."""
    if case["input"] == "golden-pcm":
        return analyze_edge_blocks([golden_pcm()], 48000, content_sha256="b" * 64, timeline_verified=True, **_IDENTITY)
    handle, path = tempfile.mkstemp(suffix=".wav", prefix="lumae-edge-qual-")
    try:
        with os.fdopen(handle, "wb") as out:
            out.write(qualification_wav(case))
        return analyze_edge_file(path, **_IDENTITY)
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


_RUNTIME_FIELDS = {("measurement", "resampler"), ("source", "decoder"), ("profile_digest",)}


def compare_to_reference(actual, expected, path=()):
    """Differences beyond the qualification tolerances, as short strings.

    ``*_cdb`` values (scalars or base64 s16 series) may differ by
    QUALIFICATION_CDB_TOLERANCE and ``*_q15`` values by
    QUALIFICATION_Q15_TOLERANCE; digital-zero (ZERO_CDB) positions and every
    other field must be exact. Runtime provenance strings and the digest are
    not compared."""
    if path in _RUNTIME_FIELDS:
        return []
    where = "/".join(path)
    name = path[-1] if path else ""
    if isinstance(expected, dict):
        if not isinstance(actual, dict) or set(actual) != set(expected):
            return [where + ": keys differ"]
        out = []
        for key in sorted(expected):
            out += compare_to_reference(actual[key], expected[key], path + (key,))
        return out
    cdb = name.endswith("_cdb")
    if not cdb and not name.endswith("_q15"):
        return [] if type(actual) is type(expected) and actual == expected else [where + ": differs"]
    tolerance = QUALIFICATION_CDB_TOLERANCE if cdb else QUALIFICATION_Q15_TOLERANCE
    if isinstance(expected, str) and isinstance(actual, str):
        dtype = "<i2" if cdb else "<u2"
        got = np.frombuffer(base64.b64decode(actual), dtype=dtype).astype(int)
        want = np.frombuffer(base64.b64decode(expected), dtype=dtype).astype(int)
    elif type(expected) is int and type(actual) is int:
        got, want = np.asarray([actual]), np.asarray([expected])
    else:
        return [where + ": differs"]
    if got.shape != want.shape:
        return [where + ": length differs"]
    if cdb and not np.array_equal(got == ZERO_CDB, want == ZERO_CDB):
        return [where + ": digital-zero positions differ"]
    worst = int(np.max(np.abs(got - want))) if got.size else 0
    return [where + ": off by %d" % worst] if worst > tolerance else []


def _qualify():
    started = time.monotonic()
    status = {"available": False, "pyav": None, "libswresample": None, "reason": None, "detail": None,
              "qualified_at": None, "qualification_ms": None}
    try:
        import av
    except Exception:
        status["reason"] = "pyav_missing"
        return status
    status["pyav"] = str(getattr(av, "__version__", "")) or None
    swr = getattr(av, "library_versions", {}).get("libswresample")
    status["libswresample"] = ".".join(str(v) for v in swr) if swr else None
    try:
        _import_av()
    except EdgeProfileError as error:
        status["reason"] = "libswresample_missing" if "libswresample" in str(error) else "pyav_too_old"
        status["detail"] = str(error)
        return status
    _QUALIFYING.active = True
    try:
        reference = json.loads((Path(__file__).resolve().parent / QUALIFICATION_FILE).read_text(encoding="utf-8"))
        failures = []
        for case in reference["cases"]:
            failures += [case["name"] + ": " + item for item in compare_to_reference(run_qualification_case(case), case["expected"])]
    except Exception as error:  # a runtime that cannot run the reference is unqualified
        status["reason"] = "qualification_error"
        status["detail"] = (type(error).__name__ + ": " + str(error))[:200]
        return status
    finally:
        _QUALIFYING.active = False
        status["qualification_ms"] = int((time.monotonic() - started) * 1000)
    if failures:
        status["reason"] = "runtime_unqualified"
        status["detail"] = "; ".join(failures[:5])[:300]
        return status
    status["available"] = True
    status["qualified_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return status


def edge_runtime_status():
    """JSON-serializable verdict on this process's edge runtime:
    ``available``, ``pyav``, ``libswresample``, ``reason`` (None,
    ``pyav_missing``, ``pyav_too_old``, ``libswresample_missing``,
    ``runtime_unqualified`` or ``qualification_error``), ``detail``,
    ``qualified_at`` (UTC ISO-8601 when available) and ``qualification_ms``.
    Qualification runs once per process on first use and is cached; importing
    this module does not run it."""
    global _STATUS
    if _STATUS is None:
        with _STATUS_LOCK:
            if _STATUS is None:
                _STATUS = _qualify()
    return dict(_STATUS)


def edge_runtime_available():
    return edge_runtime_status()["available"]


def _reset_runtime_status():
    """Tests only: forget the cached qualification verdict."""
    global _STATUS
    with _STATUS_LOCK:
        _STATUS = None


class _EdgeSamples:
    """Head plus circular tail; allocation never grows with recording duration."""

    def __init__(self, capacity, dtype):
        self.capacity = capacity
        self.head = np.empty(capacity, dtype=dtype)
        self.tail = np.empty(capacity, dtype=dtype)
        self.total = 0

    def push(self, values):
        values = np.asarray(values)
        count = len(values)
        first = min(count, max(0, self.capacity - self.total))
        if first:
            self.head[self.total:self.total + first] = values[:first]
        offset = 0
        while offset < count:
            pos = (self.total + offset) % self.capacity
            take = min(count - offset, self.capacity - pos)
            self.tail[pos:pos + take] = values[offset:offset + take]
            offset += take
        self.total += count

    def window(self, start, end):
        if start < 0 or end > self.total or end <= start:
            raise EdgeProfileError("invalid edge sample coverage")
        if end <= min(self.total, self.capacity):
            return self.head[start:end]
        if start < self.total - self.capacity:
            raise EdgeProfileError("edge sample coverage unavailable")
        pos = start % self.capacity
        length = end - start
        if pos + length <= self.capacity:
            return self.tail[pos:pos + length]
        return np.concatenate((self.tail[pos:], self.tail[:length - (self.capacity - pos)]))


def _pack_i16(values):
    return base64.b64encode(np.asarray(values, dtype="<i2").tobytes()).decode("ascii")


def _pack_u16(values):
    return base64.b64encode(np.asarray(values, dtype="<u2").tobytes()).decode("ascii")


def _boundaries(sample_rate, origin, end):
    result = [origin]
    index = 1
    while result[-1] < end:
        result.append(min(end, origin + index * sample_rate // 10))
        index += 1
    return result


def _canonical_range(begin, finish, source_rate, canonical_total, source_total):
    start = begin * CANONICAL_RATE // source_rate
    end = min(canonical_total, finish * CANONICAL_RATE // source_rate)
    if finish == source_total:
        end = canonical_total
    if end <= start:
        end = min(canonical_total, start + 1)
    return start, end


def _spectral_features(pcm):
    """Bounded evidence, not a probability: spectral change and onset density."""
    mono = np.mean(pcm.astype(np.float64), axis=0)
    if not len(mono) or np.max(np.abs(mono)) == 0:
        return 0, 0
    split = len(mono) // 2
    if split >= 64:
        previous = np.abs(np.fft.rfft(mono[:split] * np.hanning(split)))
        current = np.abs(np.fft.rfft(mono[-split:] * np.hanning(split)))
        count = min(len(previous), len(current))
        flux = float(np.sum(np.maximum(0.0, current[:count] - previous[:count]))) / max(
            1e-12, float(np.sum(current[:count]))
        )
    else:
        flux = 0.0
    hop = max(1, CANONICAL_RATE // 100)
    rms = []
    for offset in range(0, len(mono), hop):
        part = mono[offset:offset + hop]
        if len(part):
            rms.append(math.sqrt(float(np.mean(part * part))))
    if len(rms) < 2:
        density = 0.0
    else:
        floor = max(1e-9, float(np.percentile(rms, 20)))
        onsets = sum(1 for before, after in zip(rms, rms[1:]) if after > max(before * 1.8, floor * 2.5))
        density = onsets / (len(rms) - 1)
    return _q15(min(1.0, flux * 2.0)), _q15(density)


def _true_peak(pcm, sample_peak):
    if pcm.size == 0 or sample_peak == 0:
        return sample_peak
    measured = sample_peak
    for channel in pcm:
        oversampled = resample_poly(channel.astype(np.float64), TRUE_PEAK_OVERSAMPLE, 1, padtype="line")
        if len(oversampled):
            measured = max(measured, float(np.max(np.abs(oversampled))))
    return measured


def _edge(peaks, powers, true_pcm, band_powers, sample_rate, origin, end):
    boundaries = _boundaries(sample_rate, origin, end)
    levels, peak_bounds, true_peaks = [], [], []
    low_levels, mid_levels, high_levels = [], [], []
    flux_values, onset_values = [], []
    for begin, finish in zip(boundaries, boundaries[1:]):
        sample_peak = float(np.max(peaks.window(begin, finish)))
        canonical_begin, canonical_end = _canonical_range(begin, finish, sample_rate, powers.total, peaks.total)
        power = float(np.mean(powers.window(canonical_begin, canonical_end)))
        low = float(np.mean(band_powers[0].window(canonical_begin, canonical_end)))
        mid = float(np.mean(band_powers[1].window(canonical_begin, canonical_end)))
        high = float(np.mean(band_powers[2].window(canonical_begin, canonical_end)))
        # Recursive filter residue below -300 dBFS is numerical zero, not a
        # meaningful source measurement and not representable in centidB i16.
        power = 0.0 if power < 1e-30 else power
        low = 0.0 if low < 1e-30 else low
        mid = 0.0 if mid < 1e-30 else mid
        high = 0.0 if high < 1e-30 else high
        pcm = np.stack([channel.window(canonical_begin, canonical_end) for channel in true_pcm])
        flux, onset = _spectral_features(pcm)
        levels.append(quantize_db(power))
        peak_bounds.append(quantize_db(sample_peak, peak=True))
        true_peaks.append(quantize_db(_true_peak(pcm, sample_peak), peak=True))
        low_levels.append(quantize_db(low))
        mid_levels.append(quantize_db(mid))
        high_levels.append(quantize_db(high))
        flux_values.append(flux)
        onset_values.append(onset)
    count = len(levels)
    mask = bytearray((count + 7) // 8)
    for index in range(count):
        mask[index // 8] |= 1 << (index % 8)
    wire = {
        "origin_frame": origin,
        "covered_frames": end - origin,
        "bin_count": count,
        "boundaries": boundaries,
        "valid": base64.b64encode(mask).decode("ascii"),
        "level_cdb": _pack_i16(levels),
        "peak_cdb": _pack_i16(peak_bounds),
        "true_peak_cdb": _pack_i16(true_peaks),
        "low_power_cdb": _pack_i16(low_levels),
        "mid_power_cdb": _pack_i16(mid_levels),
        "high_power_cdb": _pack_i16(high_levels),
        "spectral_flux_q15": _pack_u16(flux_values),
        "onset_density_q15": _pack_u16(onset_values),
    }
    # Raw source peaks protect quiet full-band or DC-like material from the
    # K-weighted high-pass being mistaken for terminal silence. A 6 dB crest
    # allowance keeps isolated low-level impulses from defining the body.
    evidence_levels = [max(level, peak - 600) for level, peak in zip(levels, peak_bounds)]
    return wire, evidence_levels


def _landmarks(head, head_levels, tail, tail_levels, total, leading_zeros, trailing_zeros, timeline_verified):
    represented = [value for value in head_levels + tail_levels if value != ZERO_CDB]
    if not represented:
        position = min(total, leading_zeros)
        return -12000, {
            "audible_start_frame": position,
            "body_start_frame": position,
            "body_end_frame": position,
            "audible_end_frame": position,
            "leading_padding_frames": position,
            "trailing_padding_frames": 0,
            "confidence_q15": 32768 if timeline_verified else 16384,
            "terminal_silence_confidence_q15": 0,
            "hidden_content_guard": False,
        }
    noise_floor = max(-12000, min(0, int(round(float(np.percentile(represented, 10))))))
    maximum = max(represented)
    audible_threshold = max(-12000, min(noise_floor + 1000, maximum - 1200))
    body_threshold = max(audible_threshold, maximum - 600)
    head_audible = [value != ZERO_CDB and value >= audible_threshold for value in head_levels]
    tail_audible = [value != ZERO_CDB and value >= audible_threshold for value in tail_levels]
    head_body = [value != ZERO_CDB and value >= body_threshold for value in head_levels]
    tail_body = [value != ZERO_CDB and value >= body_threshold for value in tail_levels]
    first_audible = next((i for i, yes in enumerate(head_audible) if yes), 0)
    last_audible = max((i for i, yes in enumerate(tail_audible) if yes), default=len(tail_levels) - 1)
    first_body = next((i for i, yes in enumerate(head_body) if yes), first_audible)
    last_body = max((i for i, yes in enumerate(tail_body) if yes), default=last_audible)
    audible_start = max(leading_zeros, head["boundaries"][first_audible])
    audible_end = min(total - trailing_zeros, tail["boundaries"][last_audible + 1])
    body_start = max(audible_start, head["boundaries"][first_body])
    body_end = min(audible_end, tail["boundaries"][last_body + 1])
    if body_start > body_end:
        body_start, body_end = audible_start, audible_end
    hidden_guard = False
    seen_audible = False
    quiet_run = 0
    for audible in tail_audible:
        if audible:
            if seen_audible and quiet_run >= 20:
                hidden_guard = True
            seen_audible = True
            quiet_run = 0
        elif seen_audible:
            quiet_run += 1
    separation = max(0, maximum - noise_floor)
    confidence = min(1.0, (0.84 if timeline_verified else 0.58) + min(0.12, separation / 10000))
    terminal_confidence = 1.0 if trailing_zeros > 0 and timeline_verified and not hidden_guard else 0.5 if trailing_zeros > 0 and not hidden_guard else 0.0
    return noise_floor, {
        "audible_start_frame": int(audible_start),
        "body_start_frame": int(body_start),
        "body_end_frame": int(body_end),
        "audible_end_frame": int(audible_end),
        "leading_padding_frames": int(leading_zeros),
        "trailing_padding_frames": int(trailing_zeros),
        "confidence_q15": _q15(confidence),
        "terminal_silence_confidence_q15": _q15(terminal_confidence),
        "hidden_content_guard": hidden_guard,
    }


def analyze_edge_blocks(blocks, sample_rate, *, catalog_instance_id, track_id,
                        media_revision, content_sha256, channel_layout="stereo",
                        decoder="pcm-input-v1", timeline_verified=False, deadline=None):
    """Measure channel-first float PCM. Identity must be verified by the caller."""
    av = _av()
    if isinstance(sample_rate, bool) or not isinstance(sample_rate, int) or not 10 <= sample_rate <= MAX_SOURCE_RATE:
        raise EdgeProfileError("unsupported source sample rate")
    if channel_layout not in ("mono", "stereo"):
        raise EdgeProfileError("unqualified channel layout")
    for token in (catalog_instance_id, track_id, media_revision):
        if not isinstance(token, str) or not 0 < len(token) <= 512:
            raise EdgeProfileError("invalid source identity")
    if not media_revision.startswith("sha256:") or len(media_revision) != 71 or any(c not in "0123456789abcdef" for c in media_revision[7:]):
        raise EdgeProfileError("invalid media revision")
    if not isinstance(content_sha256, str) or len(content_sha256) != 64 or any(c not in "0123456789abcdef" for c in content_sha256):
        raise EdgeProfileError("invalid content hash")
    channels = 1 if channel_layout == "mono" else 2
    resampler = av.AudioResampler(format="fltp", layout=channel_layout, rate=CANONICAL_RATE)
    peaks = _EdgeSamples(EDGE_SECONDS * sample_rate, np.float32)
    canonical_capacity = (EDGE_SECONDS + 1) * CANONICAL_RATE
    powers = _EdgeSamples(canonical_capacity, np.float64)
    true_pcm = [_EdgeSamples(canonical_capacity, np.float32) for _ in range(channels)]
    band_powers = [_EdgeSamples(canonical_capacity, np.float64) for _ in range(3)]
    z1 = np.zeros((channels, 2), dtype=np.float64)
    z2 = np.zeros((channels, 2), dtype=np.float64)
    low_z = np.zeros((channels, len(_LOW_A) - 1), dtype=np.float64)
    mid_z = np.zeros((channels, len(_MID_A) - 1), dtype=np.float64)
    leading_zero_frames = 0
    trailing_zero_frames = 0
    found_signal = False

    def consume_canonical(frame):
        nonlocal z1, z2, low_z, mid_z
        for converted in resampler.resample(frame):
            pcm = converted.to_ndarray().astype(np.float64)
            weighted, z1 = lfilter(_B1, _A1, pcm, axis=1, zi=z1)
            weighted, z2 = lfilter(_B2, _A2, weighted, axis=1, zi=z2)
            low, low_z = lfilter(_LOW_B, _LOW_A, pcm, axis=1, zi=low_z)
            upper = pcm - low
            mid, mid_z = lfilter(_MID_B, _MID_A, upper, axis=1, zi=mid_z)
            high = upper - mid
            powers.push(np.mean(weighted * weighted, axis=0))
            band_powers[0].push(np.mean(low * low, axis=0))
            band_powers[1].push(np.mean(mid * mid, axis=0))
            band_powers[2].push(np.mean(high * high, axis=0))
            for channel in range(channels):
                true_pcm[channel].push(pcm[channel].astype(np.float32))

    for raw in blocks:
        _check_deadline(deadline)
        block = np.asarray(raw, dtype=np.float32)
        if block.ndim != 2 or block.shape[0] != channels:
            raise EdgeProfileError("source channel layout changed")
        for offset in range(0, block.shape[1], BLOCK_FRAMES):
            _check_deadline(deadline)
            pcm = np.ascontiguousarray(block[:, offset:offset + BLOCK_FRAMES])
            if not np.all(np.isfinite(pcm)):
                raise EdgeProfileError("non-finite source PCM")
            if peaks.total + pcm.shape[1] > int(MAX_SECONDS * sample_rate):
                raise EdgeProfileError("edge duration limit exceeded")
            peak = np.max(np.abs(pcm), axis=0)
            nonzero = np.flatnonzero(peak)
            if not found_signal:
                leading_zero_frames += int(nonzero[0]) if len(nonzero) else len(peak)
                found_signal = len(nonzero) > 0
            trailing_zero_frames = len(peak) - int(nonzero[-1]) - 1 if len(nonzero) else trailing_zero_frames + len(peak)
            frame = av.AudioFrame.from_ndarray(pcm, format="fltp", layout=channel_layout)
            frame.sample_rate = sample_rate
            frame.pts = peaks.total
            peaks.push(peak)
            consume_canonical(frame)
    consume_canonical(None)
    _check_deadline(deadline)
    if peaks.total == 0 or abs(powers.total - peaks.total * CANONICAL_RATE / sample_rate) > 1:
        raise EdgeProfileError("invalid decoded/resampled timeline")
    head, head_levels = _edge(peaks, powers, true_pcm, band_powers, sample_rate, 0, min(peaks.total, EDGE_SECONDS * sample_rate))
    tail, tail_levels = _edge(peaks, powers, true_pcm, band_powers, sample_rate, max(0, peaks.total - EDGE_SECONDS * sample_rate), peaks.total)
    noise_floor, landmarks = _landmarks(head, head_levels, tail, tail_levels, peaks.total, leading_zero_frames, trailing_zero_frames, timeline_verified)
    swr = _swr_text(av)
    payload = {
        "schema_version": SCHEMA_VERSION,
        "analyzer_version": ANALYZER_VERSION,
        "catalog_instance_id": catalog_instance_id,
        "track_id": track_id,
        "media_revision": media_revision,
        "representation_id": "sha256:" + content_sha256,
        "content_sha256": content_sha256,
        "source": {"sample_rate": sample_rate, "channel_layout": channel_layout, "decoded_frames": peaks.total, "decoder": decoder, "padding": "decoder-output-v1", "timeline_verified": timeline_verified},
        "measurement": {"method": METHOD, "sample_rate": CANONICAL_RATE, "channel_rule": "mean-power", "quantization": QUANTIZATION, "resampler": "pyav-" + av.__version__ + "-swr-" + swr, "true_peak_oversample": TRUE_PEAK_OVERSAMPLE, "crossover_hz": list(CROSSOVER_HZ)},
        "leading_silence": {"frames": leading_zero_frames, "method": "digital-zero", "verified": True},
        "noise_floor_cdb": noise_floor,
        "landmarks": landmarks,
        "head": head,
        "tail": tail,
    }
    payload["profile_digest"] = profile_digest(payload)
    return payload


def analyze_edge_file(path, *, catalog_instance_id, track_id, media_revision, deadline_seconds=900,
                      observer=None):
    # ``observer``: see ``loudness.analyze_file``; the hard limit is LUM-018's.
    av = _av()
    deadline = time.monotonic() + max(1, deadline_seconds)
    with open(path, "rb") as source:
        before = os.fstat(source.fileno())

        def hash_source():
            source.seek(0)
            digest = hashlib.sha256()
            while chunk := source.read(1024 * 1024):
                _check_deadline(deadline)
                digest.update(chunk)
            return digest.hexdigest()

        content_hash = hash_source()
        source.seek(0)
        with av.open(source) as container:
            if not container.streams.audio:
                raise EdgeProfileError("no audio stream")
            stream = container.streams.audio[0]
            if observer is not None:
                observer.opened(container, stream)
            rate = stream.codec_context.sample_rate
            layout = stream.codec_context.layout.name
            codec = stream.codec_context.name
            # F1: planar to_ndarray() crashes PyAV 16 on 8 channels (see
            # loudness.PLANAR_MAX_CHANNELS). analyze_edge_blocks rejects every
            # layout but mono and stereo before this generator runs.
            converter = av.AudioResampler(format="fltp", layout=layout, rate=rate)

            def blocks():
                for frame in container.decode(stream):
                    _check_deadline(deadline)
                    if observer is not None:
                        observer.decoded(frame)
                    for converted in converter.resample(frame):
                        yield converted.to_ndarray()
                for converted in converter.resample(None):
                    yield converted.to_ndarray()

            result = analyze_edge_blocks(blocks(), rate, catalog_instance_id=catalog_instance_id, track_id=track_id, media_revision=media_revision or "sha256:" + content_hash, content_sha256=content_hash, channel_layout=layout, decoder="pyav-" + av.__version__ + ":" + codec, timeline_verified=codec in ("flac", "pcm_s16le", "pcm_s24le", "pcm_s32le", "pcm_f32le"), deadline=deadline)
        after = os.fstat(source.fileno())
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns) or hash_source() != content_hash:
            raise EdgeProfileError("source changed during analysis")
        return result
