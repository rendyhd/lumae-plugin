"""Server-owned Lumae playback and library enrichment streams.

The mobile app owns private listening state, but deterministic library-wide
work belongs beside AudioMuse's provider catalogue and analysis projection.
This module publishes:

* completed loudness/MixRamp profiles as a cursor stream; and
* album/artist relationship snapshots calculated with Lumae's native scoring
  model after each published analysis generation.

Neither stream is a catalogue-readiness gate.  Mobile clients bootstrap what
is currently ready, advance opaque cursors atomically with local writes, and
pick up later work during an ordinary sync.
"""

from datetime import datetime, timezone
import base64
import hashlib
import json
import math
import re
import uuid

import numpy as np

from plugin.api import get_db, table

from . import migrations
from .reconcile import arm_reconcile
from .edge_profiles import opaque_revision
from .edge_profile_store import edge_join

from .catalog import (
    JOURNAL_WRITER_GENERATION,
    CatalogScanError,
    canonical_json,
    change_journal_retention_limit,
    compact_change_journal,
    opaque_cursor,
    parse_opaque_cursor,
    read_change_page,
    resolve_catalog_source,
)


RELATIONSHIP_SCHEMA_VERSION = 1
RELATIONSHIP_ALGORITHM_VERSION = 1
RELATIONSHIP_LIMIT = 12
RELATIONSHIP_CANDIDATE_TRACKS_PER_VECTOR = 96
RELATIONSHIP_MAX_CANDIDATE_ENTITIES = 384
RELATIONSHIP_ENTITY_SAMPLE_LIMIT = 160
ENRICHMENT_STALE_HOURS = 2
# Minimum profile journal retention per source. The effective limit is
# profile_change_retention_limit(library size), persisted per source in
# profile_stream_state.retention_limit by compact_enrichment_storage.
PROFILE_CHANGE_RETENTION_EVENTS = 50_000
# Most journal rows one profile publication may compact past the current floor
# (bounds the delete under the publication locks; maintenance is unbounded).
PROFILE_COMPACTION_MAX_ADVANCE = 5_000
# A v2 bootstrap session admitted in state 'capturing' whose capture has not
# finished after this long was abandoned (its request died): it holds neither
# a slot nor the journal floor, and the next create purges it.
PROFILE_BOOTSTRAP_CAPTURE_MINUTES = 10
MOOD_FEATURE_NAMES = ("danceable", "aggressive", "happy", "party", "relaxed", "sad")

_ALBUM_WEIGHTS = {
    "core": 0.38,
    "poles": 0.22,
    "spread": 0.14,
    "energy": 0.10,
    "mood": 0.08,
    "path": 0.08,
}
_ARTIST_WEIGHTS = {
    "poles": 0.32,
    "core": 0.22,
    "spread": 0.14,
    "outliers": 0.12,
    "energyMood": 0.12,
    "trajectory": 0.08,
}
_REASON_THRESHOLD = 0.18
_CORE_REASON_THRESHOLD = 0.12
_EDITION_SUFFIX = re.compile(
    r"\s*\(([^)]*(deluxe|japanese|remastered|expanded)[^)]*)\)\s*$",
    re.IGNORECASE,
)


class RelationshipIndexUnavailable(RuntimeError):
    pass


def t(name):
    return table(name)


def _json(value, fallback=None):
    if value is None:
        return fallback
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return fallback


def _iso(value):
    """ISO-8601 text. A zoned value (TIMESTAMPTZ) is converted to UTC with a
    ``Z`` suffix whatever the database session's TimeZone is. A naive value
    (TIMESTAMP, e.g. a profile's ``analyzed_at``) keeps its zone-less form."""
    if getattr(value, "tzinfo", None) is not None:
        value = value.astimezone(timezone.utc)
    if hasattr(value, "isoformat"):
        return value.isoformat().replace("+00:00", "Z")
    return str(value)


def _now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _fingerprint(value):
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _stream_state(cur, table_name, catalog_instance_id):
    cur.execute(
        f"SELECT epoch, head_seq, floor_seq FROM {t(table_name)} "
        "WHERE catalog_instance_id=%s",
        (catalog_instance_id,),
    )
    row = cur.fetchone()
    if row:
        return str(row[0]), int(row[1]), int(row[2])
    epoch = str(uuid.uuid4())
    cur.execute(
        f"INSERT INTO {t(table_name)} "
        "(catalog_instance_id, epoch, head_seq, floor_seq, updated_at) "
        "VALUES (%s, %s, 0, 0, now())",
        (catalog_instance_id, epoch),
    )
    return epoch, 0, 0


def _profile_stream_state(cur, catalog_instance_id, *, for_update=False):
    """Get the source profile frontier, locking it for publisher mutation."""
    if not for_update:
        cur.execute(
            f"SELECT epoch, head_seq, floor_seq FROM {t('profile_stream_state')} "
            "WHERE catalog_instance_id=%s",
            (catalog_instance_id,),
        )
        row = cur.fetchone()
        if row is not None:
            return str(row[0]), int(row[1]), int(row[2])
    cur.execute(
        f"INSERT INTO {t('profile_stream_state')} "
        "(catalog_instance_id, epoch, head_seq, floor_seq, updated_at) "
        "VALUES (%s, %s, 0, 0, now()) "
        "ON CONFLICT (catalog_instance_id) DO NOTHING",
        (catalog_instance_id, str(uuid.uuid4())),
    )
    cur.execute(
        f"SELECT epoch, head_seq, floor_seq FROM {t('profile_stream_state')} "
        "WHERE catalog_instance_id=%s" + (" FOR UPDATE" if for_update else ""),
        (catalog_instance_id,),
    )
    row = cur.fetchone()
    if row is None:
        raise RuntimeError("Profile stream state disappeared during initialization")
    return str(row[0]), int(row[1]), int(row[2])


def profile_change_retention_limit(library_count):
    """Profile events kept per source: two full libraries, at least 50k."""
    return max(
        PROFILE_CHANGE_RETENTION_EVENTS,
        change_journal_retention_limit(library_count),
    )


def refresh_profile_retention(cur, catalog_instance_id, library_count):
    """Persist the source's profile retention limit for a new library size.

    Called when the catalogue publishes a generation (which already holds the
    catalog_state row lock, the same order publishers use) and, with the
    published-profile count as well, by compact_enrichment_storage.
    """
    retention_limit = profile_change_retention_limit(library_count)
    cur.execute(
        f"""
        INSERT INTO {t('profile_stream_state')} AS p
            (catalog_instance_id, epoch, head_seq, floor_seq, retention_limit, updated_at)
        VALUES (%s, %s, 0, 0, %s, now())
        ON CONFLICT (catalog_instance_id) DO UPDATE
           SET retention_limit=EXCLUDED.retention_limit
         WHERE p.retention_limit IS DISTINCT FROM EXCLUDED.retention_limit
        """,
        (catalog_instance_id, str(uuid.uuid4()), retention_limit),
    )
    return retention_limit


def live_bootstrap_session_sql(alias="s"):
    """SQL condition: v2 bootstrap session ``alias`` is still servable.

    A live session is unexpired, is not an abandoned capture (still
    'capturing' after PROFILE_BOOTSTRAP_CAPTURE_MINUTES), and its source is
    active with the same core server, catalogue epoch and profile epoch. Only
    live sessions hold a slot or the journal floor; every other session would
    answer 410 on its next request, and the next create purges it.
    """
    return f"""(
        {alias}.expires_at > now()
        AND ({alias}.state <> 'capturing'
             OR {alias}.created_at > now()
                 - interval '{int(PROFILE_BOOTSTRAP_CAPTURE_MINUTES)} minutes')
        AND EXISTS (
            SELECT 1
              FROM {t('catalog_sources')} src
              JOIN {t('catalog_state')} cs
                ON cs.catalog_instance_id=src.catalog_instance_id
              JOIN {t('profile_stream_state')} ps
                ON ps.catalog_instance_id=src.catalog_instance_id
             WHERE src.catalog_instance_id={alias}.catalog_instance_id
               AND src.rebind_status='active'
               AND src.current_core_server_id={alias}.core_server_id
               AND cs.catalog_epoch={alias}.catalog_epoch
               AND ps.epoch={alias}.profile_epoch))"""


def _profile_floor_hold(cur, catalog_instance_id, epoch):
    """Oldest snapshot seq an open v2 bootstrap session still has to replay.

    A session reads ``seq > snapshot_seq`` once, when its catch-up captures the
    head; until then compaction must not advance the floor past it. The row is
    committed at admission, before the capture, with the admission head as
    ``snapshot_seq`` (a lower bound of the capture's head), so the hold covers
    the capture too. Sessions that are no longer live (identity-stale,
    expired, abandoned captures) would 410 anyway and hold nothing.
    """
    cur.execute(
        f"""
        SELECT MIN(s.snapshot_seq)
          FROM {t('profile_bootstrap_sessions')} s
         WHERE s.source_scope=%s AND s.catalog_instance_id=%s
           AND s.profile_epoch=%s AND s.head_seq IS NULL
           AND {live_bootstrap_session_sql('s')}
        """,
        (catalog_instance_id, catalog_instance_id, str(epoch)),
    )
    row = cur.fetchone()
    return None if row is None or row[0] is None else int(row[0])


def compact_enrichment_storage(db, catalog_instance_id=None, cursor=None,
                               profile_versions=None):
    """Bound profile and relationship journals during upgrades and maintenance.

    Also sweeps edge payloads that no published profile reaches: a catalogue
    publication deletes the edges of the profiles it withdraws only after it
    commits (P2-3), so a failed purge leaves them behind until the next
    publication or this sweep.

    Then it repairs the publication (P3-7), bounded, in the caller's
    transaction: it withdraws published profiles whose track the current
    catalogue generation lacks (at install, the 1.2.5 seed's orphans), with
    their edges, and, given ``profile_versions`` (analyzer, schema),
    republishes 'ready' profiles that have no published row. Both lock
    catalog_state before the profile stream state, as every publisher does.
    """
    from .profile_publication import (
        purge_withdrawn_edges,
        republish_ready_profiles,
        withdraw_orphaned_profiles,
    )

    cur = cursor or db.cursor()
    cur.execute(
        f"""
        SELECT p.catalog_instance_id,
               r.epoch, r.head_seq, r.album_count, r.artist_count
          FROM {t('profile_stream_state')} AS p
          LEFT JOIN {t('relationship_state')} AS r USING (catalog_instance_id)
         WHERE %s IS NULL OR p.catalog_instance_id=%s
         ORDER BY p.catalog_instance_id
        """,
        (catalog_instance_id, catalog_instance_id),
    )
    rows = cur.fetchall()
    # Before any stream-state row is locked below, so no publisher waits on it.
    for row in rows:
        purge_withdrawn_edges(cur, str(row[0]))
    for row in rows:
        withdraw_orphaned_profiles(db, str(row[0]), commit=False)
        if profile_versions is not None:
            republish_ready_profiles(db, str(row[0]), *profile_versions, commit=False)
    for row in rows:
        source_id = str(row[0])
        epoch, head_seq, _floor_seq = _profile_stream_state(
            cur, source_id, for_update=True
        )
        # The library is the larger of the published profiles and the
        # catalogue's tracks, so a first backfill is already covered.
        cur.execute(
            f"""
            SELECT GREATEST(
                (SELECT COUNT(*) FROM {t('published_source_profiles')}
                  WHERE catalog_instance_id=%s),
                COALESCE((SELECT (entity_counts->>'track')::bigint
                            FROM {t('catalog_state')}
                           WHERE catalog_instance_id=%s), 0))
            """,
            (source_id, source_id),
        )
        retention_limit = profile_change_retention_limit(cur.fetchone()[0])
        cur.execute(
            f"UPDATE {t('profile_stream_state')} SET retention_limit=%s "
            "WHERE catalog_instance_id=%s",
            (retention_limit, source_id),
        )
        compact_change_journal(
            cur,
            catalog_instance_id=source_id,
            state_table="profile_stream_state",
            changes_table="profile_changes",
            epoch_column="epoch",
            floor_column="floor_seq",
            epoch=epoch,
            head_seq=head_seq,
            retention_limit=retention_limit,
            purge_other_epochs=True,
            hold_floor_seq=_profile_floor_hold(cur, source_id, epoch),
        )
        if row[1] is not None:
            compact_change_journal(
                cur,
                catalog_instance_id=source_id,
                state_table="relationship_state",
                changes_table="relationship_changes",
                epoch_column="epoch",
                floor_column="floor_seq",
                epoch=row[1],
                head_seq=row[2],
                retention_limit=change_journal_retention_limit(
                    int(row[3] or 0) + int(row[4] or 0)
                ),
                purge_other_epochs=True,
            )
    if cursor is None:
        cur.close()


def migrate_enrichment(db):
    """Create source-scoped, independently cursorable enrichment storage."""
    cur = db.cursor()
    statements = [
        f"""
        CREATE TABLE IF NOT EXISTS {t("profile_stream_state")} (
            catalog_instance_id TEXT PRIMARY KEY
                REFERENCES {t("catalog_sources")}(catalog_instance_id) ON DELETE CASCADE,
            epoch TEXT NOT NULL,
            head_seq BIGINT NOT NULL DEFAULT 0,
            floor_seq BIGINT NOT NULL DEFAULT 0,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """,
        lambda cur: migrations.ensure_columns(
            cur, t("profile_stream_state"),
            f"retention_limit BIGINT NOT NULL DEFAULT {PROFILE_CHANGE_RETENTION_EVENTS}",
        ),
        f"""
        CREATE TABLE IF NOT EXISTS {t("profile_changes")} (
            catalog_instance_id TEXT NOT NULL,
            epoch TEXT NOT NULL,
            seq BIGINT NOT NULL,
            track_id TEXT NOT NULL,
            operation TEXT NOT NULL,
            payload JSONB,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            PRIMARY KEY (catalog_instance_id, epoch, seq)
        )
        """,
        # AUD-05 fence: a 1.2.5 worker writes source_profiles 'ready' without a
        # published row, then journals it in the same transaction. Its journal
        # insert omits this column, fails, and rolls the source row back too.
        lambda cur: migrations.ensure_columns(
            cur, t("profile_changes"),
            f"writer_generation SMALLINT NOT NULL DEFAULT {JOURNAL_WRITER_GENERATION}",
        ),
        lambda cur: migrations.ensure_no_default(cur, t("profile_changes"), "writer_generation"),
        # K6 (P3-2): an upsert journals its waveform payload plus a reference
        # to its edge (journal_edge_ref) instead of a copy of the edge. Rows
        # journalled before (1.2.5, 1.3.0 before K6) keep their embedded edge
        # and a NULL reference; they are never rewritten. Additive, no default.
        lambda cur: migrations.ensure_columns(cur, t("profile_changes"), "edge_ref JSONB"),
        f"""
        CREATE TABLE IF NOT EXISTS {t("profile_bootstrap_sessions")} (
            session_id UUID PRIMARY KEY,
            token_hash TEXT NOT NULL UNIQUE,
            signing_secret TEXT NOT NULL,
            source_scope TEXT NOT NULL,
            transfer_contract_version INTEGER NOT NULL DEFAULT 3,
            catalog_instance_id TEXT NOT NULL,
            core_server_id TEXT NOT NULL,
            catalog_epoch TEXT NOT NULL,
            profile_epoch TEXT NOT NULL,
            schema_version INTEGER NOT NULL,
            page_size INTEGER NOT NULL,
            snapshot_seq BIGINT NOT NULL,
            head_seq BIGINT,
            snapshot_count INTEGER NOT NULL,
            expires_at TIMESTAMPTZ NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """,
        lambda cur: migrations.ensure_columns(
            cur, t('profile_bootstrap_sessions'),
            "source_scope TEXT",
            "transfer_contract_version INTEGER NOT NULL DEFAULT 0",
        ),
        f"""
        DELETE FROM {t('profile_bootstrap_sessions')}
        WHERE transfer_contract_version <> 3 OR source_scope IS NULL
        """,
        # Account-era sessions had a NOT NULL principal; relax it if present.
        lambda cur: migrations.ensure_nullable(cur, t('profile_bootstrap_sessions'), "principal"),
        lambda cur: migrations.ensure_not_null(cur, t('profile_bootstrap_sessions'), "source_scope"),
        lambda cur: migrations.ensure_default(
            cur, t('profile_bootstrap_sessions'), "transfer_contract_version", "3",
        ),
        lambda cur: migrations.ensure_index(cur, f"""
        CREATE INDEX IF NOT EXISTS {t('profile_bootstrap_sessions_source_idx')}
        ON {t('profile_bootstrap_sessions')} (source_scope, expires_at)
        """),
        f"""
        CREATE TABLE IF NOT EXISTS {t('profile_bootstrap_snapshot')} (
            session_id UUID NOT NULL REFERENCES {t('profile_bootstrap_sessions')}(session_id)
                ON DELETE CASCADE,
            ordinal INTEGER NOT NULL,
            payload JSONB NOT NULL,
            PRIMARY KEY (session_id, ordinal)
        )
        """,
        f"""
        CREATE TABLE IF NOT EXISTS {t('profile_bootstrap_catchup')} (
            session_id UUID NOT NULL REFERENCES {t('profile_bootstrap_sessions')}(session_id)
                ON DELETE CASCADE,
            ordinal INTEGER NOT NULL,
            seq BIGINT NOT NULL,
            payload JSONB NOT NULL,
            PRIMARY KEY (session_id, ordinal),
            UNIQUE (session_id, seq)
        )
        """,
        # K2 (P1-5): captures store the waveform payload plus an edge
        # reference {media_revision, profile_digest}, resolved at page read.
        # Rows captured before 1.3.0 keep their embedded edge and a NULL ref.
        lambda cur: migrations.ensure_columns(cur, t('profile_bootstrap_snapshot'), "edge_ref JSONB"),
        lambda cur: migrations.ensure_columns(cur, t('profile_bootstrap_catchup'), "edge_ref JSONB"),
        # P1-6 (K3/K5, AUD-11): a session is admitted as 'capturing' and
        # becomes 'ready' when its capture commits; rows from before 1.3.0 are
        # ready. expiry_mode 'sliding' extends expires_at on every page;
        # client_request_id and pages_served let a retried create replace its
        # unclaimed session. Additive, metadata-only defaults.
        lambda cur: migrations.ensure_columns(
            cur, t('profile_bootstrap_sessions'),
            "state TEXT NOT NULL DEFAULT 'ready'",
            "expiry_mode TEXT NOT NULL DEFAULT 'absolute'",
            "client_request_id UUID",
            "pages_served INTEGER NOT NULL DEFAULT 0",
        ),
        # K6 (P3-2): a session created with edge_refs: true serves ref-eligible
        # catch-up upserts as edge_profile_ref. Metadata-only default.
        lambda cur: migrations.ensure_columns(
            cur, t('profile_bootstrap_sessions'), "edge_refs BOOLEAN NOT NULL DEFAULT FALSE",
        ),
        lambda cur: migrations.ensure_index(cur, f"""
        CREATE INDEX IF NOT EXISTS {t('profile_bootstrap_sessions_request_idx')}
        ON {t('profile_bootstrap_sessions')} (source_scope, client_request_id)
        WHERE client_request_id IS NOT NULL
        """),
        # Admitted creates per (source, caller) for the create rate limit;
        # rows older than the window are purged by the next create.
        f"""
        CREATE TABLE IF NOT EXISTS {t('profile_bootstrap_creates')} (
            catalog_instance_id TEXT NOT NULL,
            caller_key TEXT NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """,
        lambda cur: migrations.ensure_index(cur, f"""
        CREATE INDEX IF NOT EXISTS {t('profile_bootstrap_creates_caller_idx')}
        ON {t('profile_bootstrap_creates')} (catalog_instance_id, caller_key, created_at)
        """),
        lambda cur: migrations.ensure_index(cur, f"""
        CREATE INDEX IF NOT EXISTS {t("profile_changes_track_idx")}
        ON {t("profile_changes")} (catalog_instance_id, track_id)
        """),
        f"""
        CREATE TABLE IF NOT EXISTS {t("relationship_state")} (
            catalog_instance_id TEXT PRIMARY KEY
                REFERENCES {t("catalog_sources")}(catalog_instance_id) ON DELETE CASCADE,
            relationship_schema_version INTEGER NOT NULL
                DEFAULT {RELATIONSHIP_SCHEMA_VERSION},
            algorithm_version INTEGER NOT NULL DEFAULT {RELATIONSHIP_ALGORITHM_VERSION},
            source_catalog_generation BIGINT NOT NULL DEFAULT 0,
            source_analysis_generation BIGINT NOT NULL DEFAULT 0,
            result_generation BIGINT NOT NULL DEFAULT 0,
            epoch TEXT NOT NULL,
            head_seq BIGINT NOT NULL DEFAULT 0,
            floor_seq BIGINT NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'not_initialized',
            album_count BIGINT NOT NULL DEFAULT 0,
            artist_count BIGINT NOT NULL DEFAULT 0,
            started_at TIMESTAMPTZ,
            completed_at TIMESTAMPTZ,
            last_error TEXT,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """,
        f"""
        CREATE TABLE IF NOT EXISTS {t("relationship_results")} (
            catalog_instance_id TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            result_generation BIGINT NOT NULL,
            result_fp TEXT NOT NULL,
            payload JSONB NOT NULL,
            computed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            PRIMARY KEY (catalog_instance_id, entity_type, entity_id)
        )
        """,
        f"""
        CREATE TABLE IF NOT EXISTS {t("relationship_changes")} (
            catalog_instance_id TEXT NOT NULL,
            epoch TEXT NOT NULL,
            seq BIGINT NOT NULL,
            generation BIGINT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            operation TEXT NOT NULL,
            payload JSONB,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            PRIMARY KEY (catalog_instance_id, epoch, seq)
        )
        """,
    ]
    migrations.apply(cur, statements)

    from .relationship_build import migrate_relationship_builds
    migrate_relationship_builds(cur)

    cur.execute(f"SELECT catalog_instance_id FROM {t('catalog_sources')} ORDER BY catalog_instance_id")
    source_ids = [str(row[0]) for row in cur.fetchall()]
    for catalog_instance_id in source_ids:
        _profile_stream_state(cur, catalog_instance_id, for_update=True)
        cur.execute(
            f"""
            INSERT INTO {t("relationship_state")}
                (catalog_instance_id, relationship_schema_version,
                 algorithm_version, epoch)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (catalog_instance_id) DO UPDATE SET
                relationship_schema_version=CASE
                    WHEN {t("relationship_state")}.result_generation = 0
                    THEN EXCLUDED.relationship_schema_version
                    ELSE {t("relationship_state")}.relationship_schema_version
                END,
                algorithm_version=CASE
                    WHEN {t("relationship_state")}.result_generation = 0
                    THEN EXCLUDED.algorithm_version
                    ELSE {t("relationship_state")}.algorithm_version
                END,
                status=CASE
                    WHEN {t("relationship_state")}.relationship_schema_version
                           <> EXCLUDED.relationship_schema_version
                      OR {t("relationship_state")}.algorithm_version
                           <> EXCLUDED.algorithm_version
                    THEN 'stale'
                    ELSE {t("relationship_state")}.status
                END,
                updated_at=CASE
                    WHEN {t("relationship_state")}.relationship_schema_version
                           <> EXCLUDED.relationship_schema_version
                      OR {t("relationship_state")}.algorithm_version
                           <> EXCLUDED.algorithm_version
                    THEN now()
                    ELSE {t("relationship_state")}.updated_at
                END
            """,
            (
                catalog_instance_id,
                RELATIONSHIP_SCHEMA_VERSION,
                RELATIONSHIP_ALGORITHM_VERSION,
                str(uuid.uuid4()),
            ),
        )
    cur.close()


def _bytes(value):
    if value is None:
        return b""
    if isinstance(value, memoryview):
        return value.tobytes()
    return bytes(value)


def float4(value):
    """Return ``value`` at the ``REAL`` (float4) precision the profile tables store.

    The result is a decimal that round-trips the float4 value; equal to
    PostgreSQL's text form for the LUFS range. Publication compares
    and inserts this value, and every payload path emits it, so change events,
    bootstraps, snapshots and direct reads agree (AUD-03).
    """
    return float(str(np.float32(float(value))))


def serialize_profile(
    track_id,
    sample_rate,
    duration_ms,
    ref_lufs,
    start_ramp,
    end_ramp,
    analyzer_ver,
    analyzed_at,
    media_signature,
    edge_profile=None,
):
    revision = opaque_revision(media_signature)
    ref_lufs = float4(ref_lufs)
    payload = {
        "track_id": str(track_id),
        "source": "waveform",
        "sample_rate": int(sample_rate),
        "duration_ms": int(duration_ms),
        "ref_lufs": ref_lufs if math.isfinite(ref_lufs) else None,
        "start_ramp": base64.b64encode(_bytes(start_ramp)).decode("ascii"),
        "end_ramp": base64.b64encode(_bytes(end_ramp)).decode("ascii"),
        "analyzer_ver": int(analyzer_ver),
        "analyzed_at": _iso(analyzed_at),
        "media_signature": revision,
        "media_revision": revision,
    }
    if (isinstance(edge_profile, dict) and edge_profile.get("track_id") == str(track_id)
            and revision and edge_profile.get("media_revision") == revision):
        payload["edge_profile"] = edge_profile
    return payload


def _profile_json(payload):
    # ``serialize_profile`` output is already the wire form every read path
    # returns, so events store it as is. The catalogue sanitizer
    # (``catalog.canonical_json``) would rewrite empty ramps to null and could
    # alter an embedded edge, making events differ from reads.
    return json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
        allow_nan=False,
    )


def journal_edge_ref(profile_digest, *, kept):
    """An upsert's reference to its edge in the journal (K6, P3-2).

    ``profile_digest`` names the ``edge_profiles`` row; its media_revision is
    the upsert payload's own (an edge belongs to its row's revision only).
    ``kept`` marks a waveform-only republish that kept the current edge. Only
    such an event is served as ``edge_profile_ref`` to a client that opted
    in; an edge publication (not kept) always reaches every client in full.
    """
    reference = {"profile_digest": str(profile_digest)}
    if kept:
        reference["kept"] = True
    return reference


def record_profile_change(cur, catalog_instance_id, track_id, status, payload=None, *,
                          edge_ref=None):
    """Append a profile upsert/delete in the same transaction as its profile.

    An upsert with an edge journals its waveform payload (``serialize_profile``
    without the edge) and ``edge_ref`` (``journal_edge_ref``); readers join
    the edge back from ``edge_profiles`` (K6). A payload that embeds
    ``edge_profile`` and has no ``edge_ref`` is journalled as given: the
    format of 1.2.5 and of 1.3.0 before K6, which every reader still serves.
    """
    epoch, head_seq, floor_seq = _profile_stream_state(
        cur, catalog_instance_id, for_update=True
    )
    seq = head_seq + 1
    operation = "upsert" if status == "ready" and payload is not None else "delete"
    if edge_ref is not None and (
            operation != "upsert" or "edge_profile" in payload
            or not payload.get("media_revision")
            or not isinstance(edge_ref, dict) or not edge_ref.get("profile_digest")):
        raise ValueError("An edge reference needs an upsert with a media revision "
                         "and without an embedded edge")
    cur.execute(
        f"""
        INSERT INTO {t("profile_changes")}
            (catalog_instance_id, epoch, seq, track_id, operation, payload,
             edge_ref, writer_generation)
        VALUES (%s, %s, %s, %s, %s, %s::jsonb, %s::jsonb, %s)
        """,
        (
            catalog_instance_id,
            epoch,
            seq,
            str(track_id),
            operation,
            _profile_json(payload) if payload is not None and operation == "upsert" else None,
            _profile_json(edge_ref) if edge_ref is not None else None,
            JOURNAL_WRITER_GENERATION,
        ),
    )
    cur.execute(
        f"UPDATE {t('profile_stream_state')} "
        "SET head_seq=%s, updated_at=now() "
        "WHERE catalog_instance_id=%s AND epoch=%s AND head_seq=%s "
        "RETURNING head_seq, retention_limit",
        (seq, catalog_instance_id, epoch, head_seq),
    )
    advanced = cur.fetchone()
    if advanced is None:
        raise RuntimeError("Profile stream head changed during publication")
    compact_change_journal(
        cur,
        catalog_instance_id=catalog_instance_id,
        state_table="profile_stream_state",
        changes_table="profile_changes",
        epoch_column="epoch",
        floor_column="floor_seq",
        epoch=epoch,
        head_seq=seq,
        # Persisted by compact_enrichment_storage: no count(*) per publication.
        retention_limit=max(PROFILE_CHANGE_RETENTION_EVENTS, int(advanced[1] or 0)),
        hold_floor_seq=_profile_floor_hold(cur, catalog_instance_id, epoch),
        current_floor=floor_seq,
        max_advance=PROFILE_COMPACTION_MAX_ADVANCE,
    )
    return seq


def record_profile_deletions(cur, catalog_instance_id, track_ids):
    """Append one delete event per track, in order, with one compaction (P2-3).

    Leaves the journal and stream state exactly as ``record_profile_change(...,
    "deleted")`` called once per track would: the same seqs, rows and head, and
    the same floor. Per event, compaction may advance the floor by at most
    ``PROFILE_COMPACTION_MAX_ADVANCE`` towards a target that grows by at most
    one seq per event, under a hold that cannot change inside the transaction.
    So n appends reach ``min(target at the last head, floor +
    n * PROFILE_COMPACTION_MAX_ADVANCE)``, which one compaction with that
    bound computes, and delete the same rows. Returns the new head, or None
    when ``track_ids`` is empty (then nothing is read or written).
    """
    track_ids = [str(track_id) for track_id in track_ids]
    if not track_ids:
        return None
    epoch, head_seq, floor_seq = _profile_stream_state(
        cur, catalog_instance_id, for_update=True
    )
    seq = head_seq + len(track_ids)
    cur.execute(
        f"""
        INSERT INTO {t("profile_changes")}
            (catalog_instance_id, epoch, seq, track_id, operation, payload,
             writer_generation)
        SELECT %s, %s, %s + event.ordinality, event.track_id, 'delete', NULL, %s
          FROM unnest(%s::text[]) WITH ORDINALITY AS event(track_id, ordinality)
        """,
        (catalog_instance_id, epoch, head_seq, JOURNAL_WRITER_GENERATION, track_ids),
    )
    cur.execute(
        f"UPDATE {t('profile_stream_state')} "
        "SET head_seq=%s, updated_at=now() "
        "WHERE catalog_instance_id=%s AND epoch=%s AND head_seq=%s "
        "RETURNING head_seq, retention_limit",
        (seq, catalog_instance_id, epoch, head_seq),
    )
    advanced = cur.fetchone()
    if advanced is None:
        raise RuntimeError("Profile stream head changed during publication")
    compact_change_journal(
        cur,
        catalog_instance_id=catalog_instance_id,
        state_table="profile_stream_state",
        changes_table="profile_changes",
        epoch_column="epoch",
        floor_column="floor_seq",
        epoch=epoch,
        head_seq=seq,
        retention_limit=max(PROFILE_CHANGE_RETENTION_EVENTS, int(advanced[1] or 0)),
        hold_floor_seq=_profile_floor_hold(cur, catalog_instance_id, epoch),
        current_floor=floor_seq,
        max_advance=PROFILE_COMPACTION_MAX_ADVANCE * len(track_ids),
    )
    return seq


def _profile_rows(cur, catalog_instance_id, after_track_id, limit):
    cur.execute(
        f"""
        SELECT p.track_id, p.sample_rate, p.duration_ms, p.ref_lufs, p.start_ramp, p.end_ramp,
               p.analyzer_ver, p.analyzed_at, p.media_signature, edge.payload
          FROM {t("published_source_profiles")} p {edge_join()}
         WHERE p.catalog_instance_id=%s AND p.track_id > %s
         ORDER BY p.track_id LIMIT %s
        """,
        (catalog_instance_id, after_track_id or "", limit),
    )
    return [
        serialize_profile(*row)
        for row in cur.fetchall()
    ]


def _encode_page_token(value):
    raw = canonical_json(value).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _decode_page_token(value):
    try:
        padded = str(value or "") + "=" * (-len(str(value or "")) % 4)
        decoded = base64.urlsafe_b64decode(padded.encode("ascii"))
        result = json.loads(decoded.decode("utf-8"))
    except (ValueError, TypeError, UnicodeError) as exc:
        raise ValueError("Invalid enrichment page token") from exc
    if not isinstance(result, dict):
        raise ValueError("Invalid enrichment page token")
    return result


def profile_bootstrap_page(db, catalog_instance_id, page_token=None, limit=250):
    sources = resolve_catalog_source(db, catalog_instance_id=catalog_instance_id)
    if len(sources) != 1:
        raise ValueError("An explicit catalogue source is required")
    catalog_instance_id = sources[0]["catalog_instance_id"]
    limit = max(1, min(int(limit), 500))
    cur = db.cursor()
    epoch, head_seq, _floor_seq = _profile_stream_state(
        cur, catalog_instance_id
    )
    token = _decode_page_token(page_token) if page_token else None
    if token:
        if token.get("catalog_instance_id") != catalog_instance_id or token.get("epoch") != epoch:
            cur.close()
            raise KeyError("bootstrap_required")
        pinned_head = int(token.get("head_seq", 0))
        after = str(token.get("after") or "")
    else:
        pinned_head = head_seq
        after = ""
    rows = _profile_rows(cur, catalog_instance_id, after, limit + 1)
    cur.close()
    has_more = len(rows) > limit
    rows = rows[:limit]
    next_token = None
    if has_more and rows:
        next_token = _encode_page_token(
            {
                "catalog_instance_id": catalog_instance_id,
                "epoch": epoch,
                "head_seq": pinned_head,
                "after": rows[-1]["track_id"],
            }
        )
    return {
        "schema_version": 1,
        "catalog_instance_id": catalog_instance_id,
        "profiles": rows,
        "cursor": opaque_cursor(catalog_instance_id, epoch, pinned_head),
        "next_page_token": next_token,
        "has_more": has_more,
    }


# K6 (P3-2): a journalled edge reference is ref-eligible when it is kept
# (journal_edge_ref); ``{alias}`` is the journal (or catch-up) row.
EDGE_REF_KEPT = """{alias}.edge_ref @> '{{"kept": true}}'::jsonb"""


def edge_profile_ref_sql(alias, payload):
    """SQL: the wire ``edge_profile_ref`` of a kept journal row whose waveform
    payload is at the SQL path ``payload``."""
    return (f"jsonb_build_object('media_revision', {payload}->'media_revision', "
            f"'profile_digest', {alias}.edge_ref->'profile_digest')")


def _changes_page_sql(edge_refs):
    """(select, join) that serve a /changes page's journal rows (alias ``c``).

    A row journalled with an edge reference is joined back to its edge: the
    edge of that digest (for the row's track and media_revision), else the
    edge current for that media_revision (the referenced one was replaced
    later), else none (it was removed). Either way the event that replaced or
    removed it follows in the journal. The join runs only for the page's own
    rows, and without the opt-in a row reads exactly as the pre-K6 journal
    row with the edge embedded. With ``edge_refs`` a kept row carries
    ``edge_profile_ref`` instead, as journalled, and looks nothing up. Rows
    journalled before K6 (NULL edge_ref) are served as stored.

    The found edge's own payload is returned as its own column, unmerged:
    ``read_profile_changes`` attaches it to the row's ``payload`` in Python.
    Concatenating it in SQL (``payload || jsonb_build_object('edge_profile',
    ...)``) forced Postgres to rebuild a fresh ~19 KB JSONB value per row
    (P3-2 follow-up: 108 ms p50 for a 250-event page against 83 ms), which a
    plain Python dict merge does not.
    """
    kept = EDGE_REF_KEPT.format(alias="c")
    payload = "c.payload"
    lookup = "c.edge_ref IS NOT NULL"
    if edge_refs:
        payload = (f"CASE WHEN {kept} THEN c.payload || jsonb_build_object("
                   f"'edge_profile_ref', {edge_profile_ref_sql('c', 'c.payload')}) "
                   f"ELSE c.payload END")
        lookup += f" AND NOT {kept}"
    select = f"c.seq, c.track_id, c.operation, {payload}, c.created_at, edge.payload"
    join = f"""LEFT JOIN LATERAL (
        SELECT e.payload FROM {t('edge_profiles')} e
         WHERE {lookup}
           AND e.catalog_instance_id=%s AND e.track_id=c.track_id
           AND e.media_revision=c.payload->>'media_revision'
         ORDER BY e.profile_digest=c.edge_ref->>'profile_digest' DESC,
                  e.updated_at DESC, e.profile_digest
         LIMIT 1
    ) edge ON TRUE"""
    return select, join


def read_profile_changes(db, cursor_value, catalog_instance_id=None, limit=250, *,
                         edge_refs=False):
    """One /profiles/changes page. ``edge_refs`` is the K6 opt-in (P3-2)."""
    cursor = parse_opaque_cursor(cursor_value)
    expected_id = catalog_instance_id or cursor["catalog_instance_id"]
    sources = resolve_catalog_source(db, catalog_instance_id=expected_id)
    if len(sources) != 1 or sources[0]["catalog_instance_id"] != cursor["catalog_instance_id"]:
        raise ValueError("Cursor belongs to another profile source")
    page_select, page_join = _changes_page_sql(bool(edge_refs))
    cur = db.cursor()
    try:
        # State and events from one snapshot, checked for density (P1-7);
        # each event's edge is resolved in that snapshot too (K6).
        epoch, head_seq, rows, _state = read_change_page(
            cur,
            catalog_instance_id=expected_id,
            cursor=cursor,
            limit=limit,
            state_table="profile_stream_state",
            epoch_column="epoch",
            head_column="head_seq",
            floor_column="floor_seq",
            changes_table="profile_changes",
            columns=("seq", "track_id", "operation", "payload", "created_at", "edge_ref"),
            ahead_message="Cursor is ahead of the profile head",
            page_select=page_select,
            page_join=page_join,
            page_params=(expected_id,),
        )
    finally:
        cur.close()
    changes = []
    for row in rows:
        payload = _json(row[3])
        edge_profile = _json(row[5])
        # ``edge.payload`` (row[5]) is only ever non-NULL when the join found
        # an edge for a non-"kept" edge_ref row (P3-2's invariant: such a
        # payload never already embeds one), so this is the same merge the
        # SQL ``||`` used to do, just in Python instead of in Postgres.
        if edge_profile is not None and isinstance(payload, dict):
            payload = dict(payload, edge_profile=edge_profile)
        changes.append({
            "seq": int(row[0]),
            "track_id": str(row[1]),
            "operation": row[2],
            "payload": payload,
            "created_at": _iso(row[4]),
        })
    next_seq = changes[-1]["seq"] if changes else cursor["seq"]
    return {
        "schema_version": 1,
        "catalog_instance_id": expected_id,
        "changes": changes,
        "cursor": opaque_cursor(expected_id, epoch, next_seq),
        "head_cursor": opaque_cursor(expected_id, epoch, head_seq),
        "has_more": next_seq < head_seq,
    }


def _vector(blob, dimensions):
    raw = _bytes(blob)
    dimensions = int(dimensions or 0)
    if dimensions <= 0 or len(raw) != dimensions * 4:
        return None
    return np.frombuffer(raw, dtype="<f4")


def _parse_features(value):
    result = {}
    if isinstance(value, dict):
        values = value.items()
    else:
        values = []
        for part in str(value or "").split(","):
            name, separator, raw = part.partition(":")
            if separator:
                values.append((name, raw))
    for name, raw in values:
        try:
            number = float(raw)
        except (TypeError, ValueError):
            continue
        if math.isfinite(number):
            result[str(name).strip()] = number
    return result


def _mood_vector(scalar):
    mood = _parse_features((scalar or {}).get("mood_vector"))
    other = _parse_features((scalar or {}).get("other_features"))
    return [float(other.get(name, mood.get(name, 0.0))) for name in MOOD_FEATURE_NAMES]


def _energy(value):
    try:
        raw = float(value)
    except (TypeError, ValueError):
        return None
    return max(0.0, min(1.0, (raw - 0.01) / 0.14))


def _average(values):
    return sum(values) / len(values) if values else 0.0


def _quantile(sorted_values, q):
    if not sorted_values:
        return 0.0
    pos = (len(sorted_values) - 1) * q
    base = int(math.floor(pos))
    rest = pos - base
    if base + 1 >= len(sorted_values):
        return sorted_values[base]
    return sorted_values[base] + rest * (sorted_values[base + 1] - sorted_values[base])


def _range_stats(values):
    values = sorted(value for value in values if value is not None)
    if not values:
        return {"min": 0.0, "max": 0.0, "mean": 0.0, "q1": 0.0, "q3": 0.0}
    return {
        "min": values[0],
        "max": values[-1],
        "mean": _average(values),
        "q1": _quantile(values, 0.25),
        "q3": _quantile(values, 0.75),
    }


def _vector_mean(vectors):
    if not vectors:
        return np.asarray([], dtype=np.float32)
    mean = np.zeros(len(vectors[0]), dtype=np.float64)
    for vector in vectors:
        current = np.asarray(vector, dtype=np.float32)
        if len(current) != len(mean):
            raise ValueError("embedding dimensions changed within one entity")
        np.add(mean, current, out=mean)
    return (mean / len(vectors)).astype(np.float32)


def _cosine_distance(left, right):
    if left is None or right is None or len(left) == 0 or len(right) == 0:
        return 1.0
    if len(left) != len(right):
        return 1.0
    left = np.asarray(left, dtype=np.float32)
    right = np.asarray(right, dtype=np.float32)
    dot = float(np.dot(left, right))
    left_norm = float(np.linalg.norm(left))
    right_norm = float(np.linalg.norm(right))
    if left_norm == 0 or right_norm == 0:
        return 1.0
    return max(0.0, min(2.0, 1.0 - dot / (left_norm * right_norm)))


def _pairwise(tracks):
    count = len(tracks)
    result = [[0.0] * count for _ in range(count)]
    for left in range(count):
        for right in range(left + 1, count):
            distance = _cosine_distance(
                tracks[left]["embedding"], tracks[right]["embedding"]
            )
            result[left][right] = distance
            result[right][left] = distance
    return result


def _mood_stats(tracks, artist=False):
    moods = [track["mood"] for track in tracks if track.get("mood") is not None]
    if not moods:
        empty = {"min": [], "max": [], "mean": []}
        if artist:
            empty.update({"q1": [], "q3": []})
        return empty
    by_dimension = [sorted(values) for values in zip(*moods)]
    result = {
        "min": [values[0] for values in by_dimension],
        "max": [values[-1] for values in by_dimension],
        "mean": [_average(values) for values in by_dimension],
    }
    if artist:
        result.update(
            {
                "q1": [_quantile(values, 0.25) for values in by_dimension],
                "q3": [_quantile(values, 0.75) for values in by_dimension],
            }
        )
    return result


def _assign_clusters(selected, pairwise):
    clusters = [[] for _value in selected]
    for track_index in range(len(pairwise)):
        best = min(
            range(len(selected)),
            key=lambda pole_index: pairwise[track_index][selected[pole_index]],
        )
        clusters[best].append(track_index)
    return clusters


def _refine_medoid(cluster, pairwise, tracks):
    def score(index):
        others = [pairwise[index][other] for other in cluster if other != index]
        return (_average(others), tracks[index]["order"], tracks[index]["id"])

    return min(cluster, key=score)


def _select_farthest(tracks, selected, pairwise, threshold):
    candidates = []
    for index, track in enumerate(tracks):
        if index in selected:
            continue
        distance = min(pairwise[index][other] for other in selected)
        candidates.append((-distance, track["order"], track["id"], index, distance))
    if not candidates:
        return None
    selected_row = min(candidates)
    return selected_row[3] if selected_row[4] >= threshold else None


def _album_fingerprint(key, tracks):
    if not tracks:
        return None
    tracks = sorted(tracks, key=lambda row: (row["order"], row["id"]))
    tracks = _representative_tracks(tracks)
    mean = _vector_mean([track["embedding"] for track in tracks])
    pairwise = _pairwise(tracks)
    center = min(
        range(len(tracks)),
        key=lambda index: _cosine_distance(tracks[index]["embedding"], mean),
    )
    selected = [center]
    while len(selected) < 3:
        next_index = _select_farthest(tracks, selected, pairwise, 0.12)
        if next_index is None:
            break
        selected.append(next_index)
    medoids = list(selected)
    for _pass in range(2):
        clusters = _assign_clusters(medoids, pairwise)
        medoids = [
            _refine_medoid(cluster, pairwise, tracks) if cluster else medoids[index]
            for index, cluster in enumerate(clusters)
        ]
    clusters = _assign_clusters(medoids, pairwise)
    poles = [
        {
            "trackId": tracks[medoid]["id"],
            "embedding": tracks[medoid]["embedding"],
            "weight": len(clusters[index]) / len(tracks),
        }
        for index, medoid in enumerate(medoids)
    ]
    center_distances = [
        _cosine_distance(track["embedding"], mean) for track in tracks
    ]
    distances = [
        pairwise[left][right]
        for left in range(len(tracks))
        for right in range(left + 1, len(tracks))
    ]
    steps = [pairwise[index][index + 1] for index in range(len(tracks) - 1)]
    total_path = sum(steps)
    return {
        "key": key,
        "mean": mean,
        "poles": poles,
        "spread": {
            "meanDistanceFromCenter": _average(center_distances),
            "maxDistanceFromCenter": max(center_distances, default=0.0),
            "meanPairwiseDistance": _average(distances),
            "maxPairwiseDistance": max(distances, default=0.0),
        },
        "path": {
            "meanStepDistance": _average(steps),
            "maxStepDistance": max(steps, default=0.0),
            "totalPathDistance": total_path,
            "netPathRatio": (
                pairwise[0][-1] / total_path if len(tracks) > 1 and total_path else 0.0
            ),
        },
        "energy": _range_stats([track.get("energy") for track in tracks]),
        "mood": _mood_stats(tracks),
    }


def _representative_tracks(tracks):
    if len(tracks) <= RELATIONSHIP_ENTITY_SAMPLE_LIMIT:
        return tracks
    mean = _vector_mean([track["embedding"] for track in tracks])
    edges = sorted(
        range(len(tracks)),
        key=lambda index: (
            -_cosine_distance(tracks[index]["embedding"], mean),
            tracks[index]["order"],
            tracks[index]["id"],
        ),
    )[:12]
    selected = set(edges)
    remaining = RELATIONSHIP_ENTITY_SAMPLE_LIMIT - len(selected)
    for index in range(remaining):
        ratio = 0 if remaining == 1 else index / (remaining - 1)
        selected.add(round(ratio * (len(tracks) - 1)))
    return [
        tracks[index]
        for index in sorted(selected)[:RELATIONSHIP_ENTITY_SAMPLE_LIMIT]
    ]


def _artist_fingerprint(key, tracks):
    if not tracks:
        return None
    tracks = sorted(tracks, key=lambda row: (row["order"], row["id"]))
    representative = _representative_tracks(tracks)
    pairwise = _pairwise(representative)
    core = sorted(
        range(len(representative)),
        key=lambda index: (
            _average(
                [
                    pairwise[index][other]
                    for other in range(len(representative))
                    if other != index
                ]
            ),
            representative[index]["order"],
            representative[index]["id"],
        ),
    )[: min(3, len(representative))]
    distances = [
        pairwise[left][right]
        for left in range(len(representative))
        for right in range(left + 1, len(representative))
    ]
    sorted_distances = sorted(distances)
    spread = {
        "meanPairwiseDistance": _average(sorted_distances),
        "p50PairwiseDistance": _quantile(sorted_distances, 0.5),
        "p90PairwiseDistance": _quantile(sorted_distances, 0.9),
        "maxPairwiseDistance": max(sorted_distances, default=0.0),
    }
    selected = [core[0]]
    threshold = max(0.08, spread["p50PairwiseDistance"] * 0.85)
    while len(selected) < min(4, len(representative)):
        next_index = _select_farthest(
            representative, selected, pairwise, threshold
        )
        if next_index is None:
            break
        selected.append(next_index)
    medoids = list(selected)
    for _pass in range(2):
        clusters = _assign_clusters(medoids, pairwise)
        medoids = [
            _refine_medoid(cluster, pairwise, representative)
            if cluster
            else medoids[index]
            for index, cluster in enumerate(clusters)
        ]
    clusters = _assign_clusters(medoids, pairwise)
    poles = sorted(
        [
            {
                "trackId": representative[medoid]["id"],
                "embedding": representative[medoid]["embedding"],
                "weight": len(clusters[index]) / len(representative),
            }
            for index, medoid in enumerate(medoids)
        ],
        key=lambda pole: (-pole["weight"], pole["trackId"]),
    )
    outlier_threshold = max(
        0.12,
        spread["meanPairwiseDistance"] * 1.1,
        spread["p50PairwiseDistance"] * 0.9,
    )
    outliers = sorted(
        (
            (
                -min(pairwise[index][core_index] for core_index in core),
                track["order"],
                track["id"],
                index,
            )
            for index, track in enumerate(representative)
            if index not in core
            and min(pairwise[index][core_index] for core_index in core)
            >= outlier_threshold
        )
    )[:5]

    albums = {}
    for index, track in enumerate(tracks):
        if track.get("album") is None or track.get("year") is None:
            continue
        album_key = f"{track['year']}:{str(track['album']).strip().lower()}"
        albums.setdefault(album_key, []).append(index)
    trajectory = None
    ordered_albums = sorted(
        albums,
        key=lambda key_value: (
            int(key_value.partition(":")[0]),
            key_value.partition(":")[2],
        ),
    )
    if len(ordered_albums) >= 3:
        medoid_indices = []
        for album_key in ordered_albums:
            indices = albums[album_key]
            album_mean = _vector_mean([tracks[index]["embedding"] for index in indices])
            medoid_indices.append(
                min(
                    indices,
                    key=lambda index: (
                        _cosine_distance(tracks[index]["embedding"], album_mean),
                        tracks[index]["order"],
                        tracks[index]["id"],
                    ),
                )
            )
        steps = [
            _cosine_distance(
                tracks[medoid_indices[index]]["embedding"],
                tracks[medoid_indices[index + 1]]["embedding"],
            )
            for index in range(len(medoid_indices) - 1)
        ]
        trajectory = {
            "meanStepDistance": _average(steps),
            "p50StepDistance": _quantile(sorted(steps), 0.5),
            "maxStepDistance": max(steps),
            "netDistance": _cosine_distance(
                tracks[medoid_indices[0]]["embedding"],
                tracks[medoid_indices[-1]]["embedding"],
            ),
        }
    return {
        "key": key,
        "core": [representative[index]["embedding"] for index in core],
        "poles": poles,
        "outliers": [representative[row[3]]["embedding"] for row in outliers],
        "spread": spread,
        "energy": _range_stats([track.get("energy") for track in tracks]),
        "mood": _mood_stats(tracks, artist=True),
        "trajectory": trajectory,
    }


def _normalize_distance(value):
    if not math.isfinite(value):
        return 1.0
    return max(0.0, min(1.0, value))


def _interval(stats):
    return (
        (stats["min"], stats["max"])
        if stats["q1"] == 0 and stats["q3"] == 0
        else (stats["q1"], stats["q3"])
    )


def _interval_distance(left, right):
    if left == (0.0, 0.0) or right == (0.0, 0.0):
        return 0.0
    if left[0] == left[1] and right[0] == right[1]:
        return _normalize_distance(abs(left[0] - right[0]))
    start = max(left[0], right[0])
    end = min(left[1], right[1])
    if end < start:
        return _normalize_distance(start - end)
    span = max(left[1], right[1]) - min(left[0], right[0])
    return 0.0 if span <= 0 else _normalize_distance(1 - (end - start) / span)


def _nearest_average(left, right):
    if not left or not right:
        return 1.0
    return _average(
        [min(_cosine_distance(source, target) for target in right) for source in left]
    )


def _symmetric_embedding_distance(left, right):
    if not left and not right:
        return 0.0
    if not left or not right:
        return 1.0
    return _normalize_distance(
        (_nearest_average(left, right) + _nearest_average(right, left)) / 2
    )


def _album_score(source, candidate):
    core = _normalize_distance(_cosine_distance(source["mean"], candidate["mean"]))
    if not source["poles"]:
        poles = 0.0
    elif not candidate["poles"]:
        poles = 1.0
    else:
        poles = _normalize_distance(
            _average(
                [
                    min(
                        _cosine_distance(pole["embedding"], other["embedding"])
                        for other in candidate["poles"]
                    )
                    for pole in source["poles"]
                ]
            )
        )
    spread = abs(
        source["spread"]["meanPairwiseDistance"]
        - candidate["spread"]["meanPairwiseDistance"]
    )
    if (
        source["spread"]["meanPairwiseDistance"] >= 0.18
        and candidate["spread"]["meanPairwiseDistance"]
        < source["spread"]["meanPairwiseDistance"] * 0.55
    ):
        spread += 0.12
    spread = _normalize_distance(spread)
    energy = _interval_distance(_interval(source["energy"]), _interval(candidate["energy"]))
    mood = (
        0.0
        if not source["mood"]["mean"] or not candidate["mood"]["mean"]
        else _normalize_distance(
            _cosine_distance(source["mood"]["mean"], candidate["mood"]["mean"])
        )
    )
    path = _normalize_distance(
        abs(
            source["path"]["meanStepDistance"]
            - candidate["path"]["meanStepDistance"]
        )
    )
    dimensions = {
        "core": core,
        "poles": poles,
        "spread": spread,
        "energy": energy,
        "mood": mood,
        "path": path,
    }
    reasons = [
        name
        for name, _distance in sorted(
            (
                (name, distance)
                for name, distance in dimensions.items()
                if distance < _REASON_THRESHOLD
            ),
            key=lambda item: (item[1], item[0]),
        )[:2]
    ]
    if core < _CORE_REASON_THRESHOLD and "core" not in reasons:
        reasons.insert(0, "core")
    return (
        sum(dimensions[name] * _ALBUM_WEIGHTS[name] for name in dimensions),
        reasons,
    )


def _mood_distance(left, right):
    if not left["mean"] or not right["mean"]:
        return 0.0
    dimensions = min(len(left["mean"]), len(right["mean"]))
    intervals = []
    for index in range(dimensions):
        left_interval = (
            (left["min"][index], left["max"][index])
            if left["q1"][index] == 0 and left["q3"][index] == 0
            else (left["q1"][index], left["q3"][index])
        )
        right_interval = (
            (right["min"][index], right["max"][index])
            if right["q1"][index] == 0 and right["q3"][index] == 0
            else (right["q1"][index], right["q3"][index])
        )
        intervals.append(_interval_distance(left_interval, right_interval))
    return _normalize_distance(
        (_cosine_distance(left["mean"], right["mean"]) + _average(intervals)) / 2
    )


def _artist_score(source, candidate):
    def pole_distance(left, right):
        if not left and not right:
            return 0.0
        if not left or not right:
            return 1.0

        def nearest(first, second):
            return _average(
                [
                    min(
                        _cosine_distance(pole["embedding"], other["embedding"])
                        + abs(pole["weight"] - other["weight"]) * 0.25
                        for other in second
                    )
                    for pole in first
                ]
            )

        return _normalize_distance((nearest(left, right) + nearest(right, left)) / 2)

    spread = _average(
        [
            abs(source["spread"][name] - candidate["spread"][name])
            for name in (
                "meanPairwiseDistance",
                "p50PairwiseDistance",
                "p90PairwiseDistance",
                "maxPairwiseDistance",
            )
        ]
    )
    if (
        source["spread"]["meanPairwiseDistance"] >= 0.18
        and candidate["spread"]["meanPairwiseDistance"]
        < source["spread"]["meanPairwiseDistance"] * 0.65
    ):
        spread += 0.12
    energy_mood = _normalize_distance(
        (
            _interval_distance(
                _interval(source["energy"]), _interval(candidate["energy"])
            )
            + _mood_distance(source["mood"], candidate["mood"])
        )
        / 2
    )
    trajectory = None
    if source["trajectory"] is not None and candidate["trajectory"] is not None:
        trajectory = _normalize_distance(
            _average(
                [
                    abs(source["trajectory"][name] - candidate["trajectory"][name])
                    for name in (
                        "meanStepDistance",
                        "p50StepDistance",
                        "maxStepDistance",
                        "netDistance",
                    )
                ]
            )
        )
    dimensions = [
        ("poles", pole_distance(source["poles"], candidate["poles"])),
        ("core", _symmetric_embedding_distance(source["core"], candidate["core"])),
        ("spread", _normalize_distance(spread)),
        (
            "outliers",
            _symmetric_embedding_distance(source["outliers"], candidate["outliers"]),
        ),
        ("energyMood", energy_mood),
        ("trajectory", trajectory),
    ]
    active = [(name, distance) for name, distance in dimensions if distance is not None]
    total_weight = sum(_ARTIST_WEIGHTS[name] for name, _distance in active) or 1.0
    score = sum(
        distance * (_ARTIST_WEIGHTS[name] / total_weight)
        for name, distance in active
    )
    reasons = [
        name
        for name, _distance in sorted(
            (
                (name, distance)
                for name, distance in active
                if distance < _REASON_THRESHOLD
            ),
            key=lambda item: (item[1], item[0]),
        )[:2]
    ]
    core = next(distance for name, distance in active if name == "core")
    if core < _CORE_REASON_THRESHOLD and "core" not in reasons:
        reasons.insert(0, "core")
    return score, list(dict.fromkeys(reasons))


def _edition_text(value):
    result = str(value or "").strip().lower()
    while _EDITION_SUFFIX.search(result):
        result = _EDITION_SUFFIX.sub("", result).strip()
    return result


def _rank_albums(source, albums):
    scored = []
    for candidate in albums:
        if (
            _edition_text(source["album"]) == _edition_text(candidate["album"])
            and _edition_text(source["artist"]) == _edition_text(candidate["artist"])
        ):
            continue
        score, reasons = _album_score(source["fingerprint"], candidate["fingerprint"])
        scored.append(
            {
                "albumKey": candidate["key"],
                "album": candidate["album"],
                "artist": candidate["artist"],
                "coverItemId": candidate["cover"],
                "score": score,
                "reasons": reasons,
                "_normalized_artist": _edition_text(candidate["artist"]),
            }
        )
    scored.sort(
        key=lambda row: (
            row["score"],
            row["artist"].casefold(),
            row["album"].casefold(),
            row["albumKey"],
        )
    )
    output = []
    selected = set()
    artist_counts = {}
    for cap in range(1, 4):
        for candidate in scored:
            if candidate["albumKey"] in selected:
                continue
            artist = candidate["_normalized_artist"]
            if artist_counts.get(artist, 0) >= cap:
                continue
            artist_counts[artist] = artist_counts.get(artist, 0) + 1
            selected.add(candidate["albumKey"])
            output.append({key: value for key, value in candidate.items() if not key.startswith("_")})
            if len(output) >= RELATIONSHIP_LIMIT:
                return output
    return output


def _rank_artists(source, artists):
    output = []
    for candidate in artists:
        if candidate["key"] == source["key"]:
            continue
        score, reasons = _artist_score(source["fingerprint"], candidate["fingerprint"])
        output.append(
            {
                "artistKey": candidate["key"],
                "artist": candidate["artist"],
                "coverItemId": candidate["cover"],
                "score": score,
                "reasons": reasons,
            }
        )
    return sorted(
        output,
        key=lambda row: (row["score"], row["artist"].casefold(), row["artistKey"]),
    )[:RELATIONSHIP_LIMIT]


def _load_relationship_inputs(cur, source):
    catalog_instance_id = source["catalog_instance_id"]
    catalog_generation = int(source["catalog"]["generation"])
    analysis_generation = int(source["analysis"]["generation"])
    cur.execute(
        f"""
        WITH artist_covers AS MATERIALIZED (
            SELECT lower(name) AS artist_key, MIN(cover_art_id) AS cover_art_id
              FROM {t("catalog_artists")}
             WHERE catalog_instance_id=%s AND published_generation=%s
             GROUP BY lower(name)
        )
        SELECT tr.track_id, tr.album_id, al.name, al.album_artist_display,
               tr.artist_display, tr.disc_number, tr.track_number, tr.cover_art_id,
               tr.payload,
               ac.cover_art_id,
               ai.scalar_payload,
               ai.musicnn_vector, ai.musicnn_dimensions
          FROM {t("catalog_tracks")} tr
          JOIN {t("track_analysis_links")} ln
            ON ln.catalog_instance_id=tr.catalog_instance_id
           AND ln.projection_generation=%s
           AND ln.provider_track_id=tr.track_id
           AND ln.status='ready'
          JOIN {t("analysis_items")} ai
            ON ai.catalog_instance_id=ln.catalog_instance_id
           AND ai.projection_generation=ln.projection_generation
           AND ai.analysis_id=ln.analysis_id
          LEFT JOIN {t("catalog_albums")} al
            ON al.catalog_instance_id=tr.catalog_instance_id
           AND al.published_generation=tr.published_generation
           AND al.album_id=tr.album_id
          LEFT JOIN artist_covers ac
            ON ac.artist_key=lower(COALESCE(al.album_artist_display, tr.artist_display))
         WHERE tr.catalog_instance_id=%s AND tr.published_generation=%s
           AND tr.available=TRUE AND tr.analysis_eligible=TRUE
         ORDER BY lower(COALESCE(al.album_artist_display, tr.artist_display)),
                  lower(COALESCE(al.name, '')), COALESCE(tr.disc_number, 0),
                  COALESCE(tr.track_number, 9999), tr.track_id
        """,
        (catalog_instance_id, catalog_generation,
         analysis_generation, catalog_instance_id, catalog_generation),
    )
    rows = cur.fetchall()
    tracks = []
    for order, row in enumerate(rows):
        embedding = _vector(row[11], row[12])
        if embedding is None or len(embedding) == 0:
            continue
        scalar = _json(row[10], {}) or {}
        payload = _json(row[8], {}) or {}
        rich = payload.get("_lumae") if isinstance(payload.get("_lumae"), dict) else {}
        album = str(row[2] or rich.get("album") or "").strip()
        artist = str(row[3] or row[4] or "").strip()
        if not artist:
            continue
        tracks.append(
            {
                "id": str(row[0]),
                "album_id": str(row[1]) if row[1] else None,
                "album": album or None,
                "artist": artist,
                "order": order,
                "embedding": embedding,
                "energy": _energy(scalar.get("energy")),
                "mood": _mood_vector(scalar),
                "year": rich.get("year"),
                "track_cover": str(row[7]) if row[7] else None,
                "artist_cover": str(row[9]) if row[9] else None,
            }
        )
    return tracks


def _iter_relationship_entities(tracks, completed=()):
    """Yield fingerprints in stable order, skipping durable checkpoints."""
    album_groups = {}
    artist_groups = {}
    for track in tracks:
        artist_key = track["artist"].lower()
        artist_groups.setdefault(artist_key, []).append(track)
        if track["album"]:
            album_key = f"{artist_key}::{track['album'].lower()}"
            album_groups.setdefault(album_key, []).append(track)
    for key, rows in sorted(album_groups.items()):
        if ("album", key) not in completed:
            yield "album", {
                "key": key,
                "album": rows[0]["album"],
                "artist": rows[0]["artist"],
                "cover": rows[0]["track_cover"] or min(row["id"] for row in rows),
                "fingerprint": _album_fingerprint(key, rows),
            }
    for key, rows in sorted(artist_groups.items()):
        if ("artist", key) not in completed:
            yield "artist", {
                "key": key,
                "artist": rows[0]["artist"],
                "cover": rows[0]["artist_cover"] or min(row["id"] for row in rows),
                "fingerprint": _artist_fingerprint(key, rows),
            }


def _build_entities(tracks):
    albums, artists = [], []
    for entity_type, entity in _iter_relationship_entities(tracks):
        (albums if entity_type == "album" else artists).append(entity)
    return albums, artists


def _fingerprint_query_vectors(entity_type, fingerprint):
    if entity_type == "album":
        vectors = [fingerprint.get("mean")]
        vectors.extend(pole.get("embedding") for pole in fingerprint.get("poles", []))
    else:
        vectors = list(fingerprint.get("core", []))
        vectors.extend(pole.get("embedding") for pole in fingerprint.get("poles", []))
        vectors.extend(fingerprint.get("outliers", []))
    return [
        np.asarray(vector, dtype=np.float32)
        for vector in vectors
        if vector is not None and len(vector)
    ][:8]


def _ivf_candidate_track_ids(query_vectors, per_vector_n):
    """Return a bounded provider-track shortlist from AudioMuse's paged IVF."""
    try:
        from tasks import ivf_manager
    except (AttributeError, ImportError) as exc:
        raise RelationshipIndexUnavailable(
            "AudioMuse's MusicNN IVF index is not available"
        ) from exc
    if getattr(ivf_manager, "ivf_index", None) is None:
        loader = getattr(ivf_manager, "load_ivf_index_for_querying", None)
        if callable(loader):
            try:
                loader()
            except Exception as exc:
                raise RelationshipIndexUnavailable(
                    "AudioMuse's MusicNN IVF index could not be loaded"
                ) from exc
    index = getattr(ivf_manager, "ivf_index", None)
    if index is None:
        raise RelationshipIndexUnavailable(
            "AudioMuse's MusicNN IVF index is not ready"
        )
    try:
        index_size = len(index)
    except (TypeError, AttributeError):
        index_size = int(per_vector_n)
    if index_size <= 0:
        raise RelationshipIndexUnavailable(
            "AudioMuse's MusicNN IVF index is empty"
        )
    ids = ivf_manager.multi_query_ids(
        query_vectors,
        min(max(1, int(per_vector_n)), index_size),
    )
    return [str(item_id) for item_id in ids]


def _relationship_candidates(
    source,
    entity_type,
    entities_by_key,
    track_to_entity,
    candidate_lookup,
):
    query_vectors = _fingerprint_query_vectors(entity_type, source["fingerprint"])
    if not query_vectors:
        return []
    track_ids = candidate_lookup(
        query_vectors,
        RELATIONSHIP_CANDIDATE_TRACKS_PER_VECTOR,
    )
    candidate_keys = []
    seen = set()
    for track_id in track_ids:
        key = track_to_entity.get(str(track_id))
        if key is None or key == source["key"] or key in seen:
            continue
        seen.add(key)
        candidate_keys.append(key)
        if len(candidate_keys) >= RELATIONSHIP_MAX_CANDIDATE_ENTITIES:
            break
    return [entities_by_key[key] for key in candidate_keys if key in entities_by_key]


def relationship_status(db, catalog_instance_id):
    sources = resolve_catalog_source(db, catalog_instance_id=catalog_instance_id)
    if len(sources) != 1:
        raise ValueError("An explicit catalogue source is required")
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT relationship_schema_version, algorithm_version,
               source_catalog_generation, source_analysis_generation,
               result_generation, epoch, head_seq, floor_seq, status,
               album_count, artist_count, started_at, completed_at,
               last_error, updated_at,
               (SELECT progress FROM {t('relationship_builds')} b
                 WHERE b.catalog_instance_id={t('relationship_state')}.catalog_instance_id)
          FROM {t("relationship_state")} WHERE catalog_instance_id=%s
        """,
        (catalog_instance_id,),
    )
    row = cur.fetchone()
    cur.close()
    if row is None:
        return {
            "catalog_instance_id": catalog_instance_id,
            "status": "not_initialized",
            "schema_version": RELATIONSHIP_SCHEMA_VERSION,
            "algorithm_version": RELATIONSHIP_ALGORITHM_VERSION,
        }
    return {
        "catalog_instance_id": catalog_instance_id,
        "schema_version": int(row[0]),
        "algorithm_version": int(row[1]),
        "source_catalog_generation": int(row[2]),
        "source_analysis_generation": int(row[3]),
        "generation": int(row[4]),
        "cursor": opaque_cursor(catalog_instance_id, str(row[5]), int(row[6])),
        "floor_seq": int(row[7]),
        "status": str(row[8]),
        "album_count": int(row[9]),
        "artist_count": int(row[10]),
        "started_at": _iso(row[11]) if row[11] else None,
        "completed_at": _iso(row[12]) if row[12] else None,
        "last_error": str(row[13]) if row[13] else None,
        "updated_at": _iso(row[14]) if row[14] else None,
        "build_progress": (_json(row[15], {}) or {}) if len(row) > 15 else {},
    }


def claim_relationship_preparation(db, catalog_instance_id):
    cur = db.cursor()
    cur.execute(
        f"""
        UPDATE {t("relationship_state")}
           SET status='queued', last_error=NULL, started_at=now(),
               completed_at=NULL, retry_count=0, next_retry_at=NULL, updated_at=now()
         WHERE catalog_instance_id=%s
           AND (status NOT IN ('queued', 'running')
                OR updated_at < now() - interval '{ENRICHMENT_STALE_HOURS} hours')
        RETURNING catalog_instance_id
        """,
        (catalog_instance_id,),
    )
    claimed = cur.fetchone() is not None
    if claimed:
        arm_reconcile(db, "relationship_preparation_admitted")
    db.commit()
    cur.close()
    return claimed


def prepare_relationships(catalog_instance_id, db=None, candidate_lookup=None, progress=None,
                          *, batch_size=128, time_budget_seconds=20):
    """Advance a durable build; only complete generations become visible."""
    from .relationship_build import run_relationship_build
    return run_relationship_build(
        catalog_instance_id, db=db or get_db(),
        candidate_lookup=candidate_lookup or _ivf_candidate_track_ids,
        progress=progress, batch_size=batch_size,
        time_budget_seconds=time_budget_seconds,
    )


def relationship_bootstrap_page(
    db, catalog_instance_id, page_token=None, limit=100
):
    status = relationship_status(db, catalog_instance_id)
    # A stale, queued, running, paused, waiting, or failed replacement must not
    # hide the last atomically published generation from clients.
    if int(status.get("generation") or 0) <= 0:
        return {
            **status,
            "relationships": [],
            "has_more": False,
            "next_page_token": None,
        }
    limit = max(1, min(int(limit), 250))
    token = _decode_page_token(page_token) if page_token else None
    generation = int(status["generation"])
    cursor = parse_opaque_cursor(status["cursor"])
    after_type = str(token.get("entity_type") or "") if token else ""
    after_id = str(token.get("entity_id") or "") if token else ""
    if token and (
        token.get("catalog_instance_id") != catalog_instance_id
        or token.get("epoch") != cursor["epoch"]
        or int(token.get("generation", -1)) != generation
    ):
        raise KeyError("bootstrap_required")
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT entity_type, entity_id, payload, computed_at
          FROM {t("relationship_results")}
         WHERE catalog_instance_id=%s
           AND result_generation=%s
           AND (entity_type > %s OR (entity_type=%s AND entity_id>%s))
         ORDER BY entity_type, entity_id LIMIT %s
        """,
        (
            catalog_instance_id,
            generation,
            after_type,
            after_type,
            after_id,
            limit + 1,
        ),
    )
    rows = cur.fetchall()
    cur.close()
    # The builder publishes results and its new generation atomically, but it
    # can finish between this request's status read and results query. Never
    # let that race produce a mixed (or apparently empty) bootstrap snapshot.
    verified = relationship_status(db, catalog_instance_id)
    if (
        int(verified["generation"]) != generation
        or verified["cursor"] != status["cursor"]
    ):
        raise KeyError("bootstrap_required")
    has_more = len(rows) > limit
    rows = rows[:limit]
    relationships = [
        {**(_json(row[2], {}) or {}), "computed_at": _iso(row[3])}
        for row in rows
    ]
    next_token = None
    if has_more and rows:
        next_token = _encode_page_token(
            {
                "catalog_instance_id": catalog_instance_id,
                "epoch": cursor["epoch"],
                "generation": generation,
                "entity_type": str(rows[-1][0]),
                "entity_id": str(rows[-1][1]),
            }
        )
    return {
        **status,
        "relationships": relationships,
        "has_more": has_more,
        "next_page_token": next_token,
    }


def read_relationship_changes(db, cursor_value, catalog_instance_id=None, limit=250):
    cursor = parse_opaque_cursor(cursor_value)
    expected_id = catalog_instance_id or cursor["catalog_instance_id"]
    status = relationship_status(db, expected_id)
    if cursor["catalog_instance_id"] != expected_id:
        raise ValueError("Cursor belongs to another relationship source")
    if "cursor" not in status:
        raise KeyError("bootstrap_required")
    cur = db.cursor()
    try:
        # State and events from one snapshot, checked for density (P1-7).
        epoch, head_seq, rows, _state = read_change_page(
            cur,
            catalog_instance_id=expected_id,
            cursor=cursor,
            limit=limit,
            state_table="relationship_state",
            epoch_column="epoch",
            head_column="head_seq",
            floor_column="floor_seq",
            changes_table="relationship_changes",
            columns=(
                "seq", "generation", "entity_type", "entity_id", "operation",
                "payload", "created_at",
            ),
            ahead_message="Cursor is ahead of the relationship head",
        )
    finally:
        cur.close()
    changes = [
        {
            "seq": int(row[0]),
            "generation": int(row[1]),
            "entity_type": str(row[2]),
            "entity_id": str(row[3]),
            "operation": str(row[4]),
            "payload": _json(row[5]),
            "created_at": _iso(row[6]),
        }
        for row in rows
    ]
    next_seq = changes[-1]["seq"] if changes else cursor["seq"]
    return {
        "schema_version": status["schema_version"],
        "algorithm_version": status["algorithm_version"],
        "catalog_instance_id": expected_id,
        "changes": changes,
        "cursor": opaque_cursor(expected_id, epoch, next_seq),
        "head_cursor": opaque_cursor(expected_id, epoch, head_seq),
        "has_more": next_seq < head_seq,
    }
