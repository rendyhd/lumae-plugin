import base64
import gzip
import json
import os
import re
import socket
import time
from datetime import datetime, timezone
from html import escape

from flask import Blueprint, Response, g, jsonify, request, url_for

from plugin.api import config, enqueue, get_db, get_setting, logger, render_page, set_setting, table
import plugin.api as host_api

from .loudness import (
    ProfileAnalysisTimeout,
    ProfileResourceLimitError,
    SilentAudioError,
    analyze_file,
)
from .edge_profiles import (
    analyze_edge_file, edge_runtime_available, edge_runtime_status, opaque_revision,
    METHOD as EDGE_METHOD, SCHEMA_VERSION as EDGE_SCHEMA_VERSION,
)
from .edge_profile_store import (
    migrate_edge_profiles, edge_join, claim_edge_jobs, update_edge_job,
    publish_edge_profile, edge_backfill_candidates, edge_profile_status,
    claim_edge_requests, record_edge_runtime, edge_worker_runtime, is_unsupported_failure,
    UNSUPPORTED as EDGE_UNSUPPORTED, mark_edge_jobs_deferred, claim_deferred_edge_jobs,
    edge_queue_counts, next_edge_backfill, update_edge_backfill, arm_edge_backfill,
    park_edge_backfill, edge_backfill_row, edge_statuses, EDGE_BACKFILL_RESWEEP_HOURS,
    ensure_edge_backfill_sources,
)
from . import analysis_isolation
from . import migrations
from . import optional_storage
from . import credits_service, credits_store, personal_discovery, music_metadata
from .shelves import (
    SHELVES_SCHEMA_VERSION,
    migrate_shelves,
    purge_expired_shelf_mutations,
    register_shelf_routes,
)
from . import covers, vibes
from .core_compat import (
    SUPPORTED_CORE_RANGE,
    detect_core,
    get_core_adapter,
    sanitized_server_summaries,
)
from .catalog import (
    CATALOG_FINGERPRINT_SCHEMA_VERSION,
    attempt_legacy_rebind,
    CATALOG_BUILDER_VERSION,
    CatalogScanError,
    bootstrap_page,
    create_bootstrap_session,
    ensure_catalog_sources,
    migrate_catalog,
    prune_catalog_storage,
    read_catalog_changes,
    refresh_catalog,
    release_bootstrap_session,
    resolve_catalog_source,
    source_matches_server_id,
    verify_library_scope,
)
from .catalog_analysis import (
    AnalysisProjectionDeferred,
    GenerationExpired,
    dedup_policy,
    project_analysis,
    read_analysis_changes,
    scalar_batch,
    vector_batch,
)
from .catalog_enrichment import (
    RELATIONSHIP_ALGORITHM_VERSION,
    RELATIONSHIP_SCHEMA_VERSION,
    claim_relationship_preparation,
    compact_enrichment_storage,
    migrate_enrichment,
    prepare_relationships,
    profile_bootstrap_page,
    read_profile_changes,
    read_relationship_changes,
    record_profile_change,
    relationship_bootstrap_page,
    relationship_status,
    serialize_profile,
)
from .catalog_readiness import CONTRACT_REVISION, v3_release_readiness
from . import status_model
from .catalog_providers import ProviderCatalogBridge, SUPPORTED_PROVIDER_TYPES
from .database_state import (
    bounded_reads,
    collect_database_state,
    redact_source_errors,
    redact_stored_error,
    render_database_state,
    safe_snapshot_error,
)
from .settings_ui import SETTINGS_STATUS_SCRIPT
from .provider_identity_guard import (
    TRANSITION_BLOCKER,
    complete_projection_reconcile,
    migrate_provider_identity,
    observe_provider_version,
    projection_reconcile_required,
    provider_transition_health,
    require_projection_reconcile,
)
from .provider_identity_rekey import read_transition_manifest, refresh_audiomuse_health
from .profile_publication import (
    RETRY_ARMED_SQL,
    RETRY_LIMIT,
    admit_attempts,
    backfill_due_sql,
    complete_attempt,
    migrate_attempts,
    public_failure_reason,
    published_profile_current,
    release_attempts,
    retry_delay_sql,
    scheduler_params,
)
from . import profile_bootstrap
from .collection_manager import (
    COLLECTIONS_BACKUP_VERSION,
    COLLECTIONS_CONTRACT,
    COLLECTIONS_SCHEMA_VERSION,
    collections_enabled,
    health_scope_mode,
    migrate_collections,
    purge_expired_collection_mutations,
    purge_stale_collection_restores,
    register_collection_routes,
    render_collections_settings_panel,
)
from .reconcile import (
    DEFERRED_MARKER,
    arm_reconcile,
    begin_event,
    defer_work,
    discard_event,
    finish_event,
    iso as reconcile_iso,
    migrate_reconcile,
    progress_event,
    read_reconcile_status,
    reconcile_schedule_from_state,
    set_paused as set_reconcile_paused,
    update_work_retry,
)

SCHEMA_VERSION = 1
ANALYZER_VERSION = 1
PLUGIN_VERSION = "1.5.1"
CATALOG_SCHEMA_VERSION = 3
ANALYSIS_SCHEMA_VERSION = 2
CATALOG_FEATURES = (
    "dual_core_compat",
    "stable_catalog_instance",
    "provider_occurrences",
    "rich_metadata",
    "complete_generations",
    "bootstrap_leases",
    "cursor_changes",
    "refresh_on_demand",
    "library_scope",
    "album_ids",
    "artist_credits",
    "soft_deletions",
    "shared_analysis",
    "binary_vectors",
    "v3_release_readiness",
    "contract_admission_v1",
    "independent_stream_admission",
    "automatic_sonic_verification",
    "semantic_contracts_v1",
    "progressive_analysis_admission",
    "repair_flagged_analysis_admission",
    "database_state_dashboard",
    "provider_track_scope_verification",
    "source_scoped_profiles",
    "prepare_lumae",
    "catalog_prepare_api",
    "analysis_run_finalization",
    "catalog_ready_before_profile_backfill",
    "interactive_profile_priority",
    "bounded_profile_backfill",
    "automatic_catalog_preparation",
    "catalog_builder_versioning",
    "durable_catalog_reconciliation",
    "preparation_worker_attestation",
    "profile_cursor_stream",
    "server_album_artist_relationships",
    "relationship_cursor_stream",
    "nonblocking_enrichment",
    "provider_identity_transition_shield_v1",
    "provider_identity_rekey_v1",
    "bounded_storage_retention",
)
CATALOG_FEATURE_ROUTES = {
    "bootstrap_leases": (
        ("/api/catalog/bootstrap-sessions", "POST"),
        ("/api/catalog/bootstrap-sessions", "DELETE"),
        ("/api/catalog/bootstrap", "GET"),
    ),
    "cursor_changes": (("/api/catalog/changes", "GET"),),
    "refresh_on_demand": (("/api/catalog/refresh", "POST"),),
    "provider_track_scope_verification": (("/api/catalog/verify-scope", "POST"),),
    "source_scoped_profiles": (("/api/profiles", "GET"),),
    "shared_analysis": (
        ("/api/catalog/analysis/changes", "GET"),
        ("/api/catalog/analysis/scalars", "POST"),
        ("/api/catalog/analysis/vectors", "POST"),
    ),
    "catalog_prepare_api": (
        ("/api/catalog/prepare", "POST"),
        ("/api/catalog/prepare/<operation_id>", "GET"),
    ),
    "provider_identity_rekey_v1": (
        ("/api/catalog/provider-identity/manifest", "GET"),
    ),
}
BACKFILL_TASK_TYPE = "plugin.lumae_analysis.backfill"
CATALOG_REFRESH_TASK_TYPE = "plugin.lumae_analysis.catalog_refresh"
CATALOG_RECONCILE_TASK_TYPE = "plugin.lumae_analysis.catalog_reconcile"
PROVIDER_IDENTITY_RECHECK_TASK_TYPE = "plugin.lumae_analysis.provider_identity_recheck"
ANALYSIS_PROJECTION_TASK_TYPE = "plugin.lumae_analysis.analysis_projection"
COLLECTION_RETENTION_TASK_TYPE = "plugin.lumae_analysis.collection_retention"
DEFAULT_BACKFILL_BATCH_SIZE = 3
MAX_BACKFILL_BATCH_SIZE = 10
INTERACTIVE_PROFILE_CHUNK_SIZE = 3
MAX_INTERACTIVE_PROFILE_IDS = 12
PREPARATION_STALE_HOURS = 1
BACKFILL_STALE_MINUTES = 30
ANALYSIS_RUN_SETTLE_GRACE_MINUTES = 2
ANALYSIS_RUN_STALE_MINUTES = 30
PROFILE_JOB_TIMEOUT_SECONDS = 20 * 60
PROFILE_BACKFILL_JOB_TIMEOUT_SECONDS = 30 * 60
CATALOG_JOB_TIMEOUT_SECONDS = 90 * 60
RELATIONSHIP_JOB_TIMEOUT_SECONDS = 60 * 60
COLLECTIONS_MENU_LABEL = "Living Collections"
COLLECTIONS_MENU_ENDPOINT = "lumae_analysis.collection_manager_page"

bp = Blueprint("lumae_analysis", __name__)
register_collection_routes(bp)
register_shelf_routes(bp)
vibes.register_vibe_routes(bp)
covers.register_cover_routes(bp)
personal_discovery.register_routes(bp)
music_metadata.register_routes(bp)
credits_service.register_routes(bp)


GZIP_MIN_BYTES = 1024
GZIP_LEVEL = 4  # ~99% of level 6 ratio for ~80% of the CPU on edge pages


def _accepts_gzip(header):
    """True when ``Accept-Encoding`` allows gzip. ``q=0`` refuses it (RFC 9110 12.5.3)."""
    explicit = wildcard = None
    for item in str(header or "").split(","):
        name, _, params = item.partition(";")
        name = name.strip().lower()
        if not name:
            continue
        quality = 1.0
        for param in params.split(";"):
            key, _, value = param.partition("=")
            if key.strip().lower() == "q":
                try:
                    quality = float(value.strip())
                except ValueError:
                    quality = 0.0
        if name in ("gzip", "x-gzip"):
            explicit = quality if explicit is None else max(explicit, quality)
        elif name == "*":
            wildcard = quality
    chosen = explicit if explicit is not None else wildcard
    return chosen is not None and chosen > 0


@bp.after_request
def _compress_json_response(response):
    """K1: gzip plugin JSON of at least 1 KiB for clients that accept it.

    Blueprint-scoped, so host routes are never touched. Streamed and
    passthrough bodies, non-200 statuses and already-encoded bodies are left
    as they are.
    """
    if (response.status_code != 200
            or response.mimetype != "application/json"
            or response.direct_passthrough
            or response.is_streamed
            or "Content-Encoding" in response.headers):
        return response
    body = response.get_data()
    if len(body) < GZIP_MIN_BYTES:
        return response
    response.vary.add("Accept-Encoding")
    if not _accepts_gzip(request.headers.get("Accept-Encoding")):
        return response
    compressed = gzip.compress(body, compresslevel=GZIP_LEVEL, mtime=0)
    response.set_data(compressed)
    response.headers["Content-Encoding"] = "gzip"
    response.headers["Content-Length"] = str(len(compressed))
    return response


def enqueue_bounded(func, *args, queue="default", timeout=None, **kwargs):
    """Queue root plugin work through AudioMuse's stable public API.

    ``timeout`` remains accepted for call-site and older-core compatibility,
    but queue internals are deliberately not imported by the plugin. AudioMuse
    owns execution limits and queue implementation details.

    AudioMuse enforces no execution limit on plugin tasks: RQ-era hosts
    enqueued them with an RQ ``job_timeout`` of -1 (no timeout), and the
    database task queue that replaced RQ has no per-task timeout. ``timeout`` is therefore
    not enforced by anyone. File analysis has its own hard limit per file
    instead (``run_file_analysis``, LUM-018).
    """
    del timeout
    return enqueue(func, *args, queue=queue, **kwargs)


def sync_collections_menu(enabled, manager=None):
    """Apply the collection page's enabled state to the live Plugins menu."""
    if manager is None:
        try:
            from plugin.manager import plugin_manager as manager
        except (ImportError, AttributeError):
            return False
    record = getattr(manager, "records", {}).get("lumae_analysis")
    if record is None:
        return False
    items = [
        item
        for item in record.get("menu_items", [])
        if item.get("endpoint") != COLLECTIONS_MENU_ENDPOINT
    ]
    if enabled:
        items.append(
            {
                "label": COLLECTIONS_MENU_LABEL,
                "endpoint": COLLECTIONS_MENU_ENDPOINT,
                "admin_only": False,
            }
        )
    record["menu_items"] = items
    return True


class MediaDownloadError(Exception):
    pass


def profiles_table():
    return table("profiles")


def source_profiles_table():
    return table("source_profiles")


def preparation_state_table():
    return table("preparation_state")


def profile_backfill_state_table():
    return table("profile_backfill_state")


def analysis_runs_table():
    return table("analysis_runs")


def utc_now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def media_signature(path):
    try:
        stat = os.stat(path)
    except OSError:
        return None
    return f"{path}|{stat.st_size}|{int(stat.st_mtime)}"


def media_server_download_available():
    fields_by_type = getattr(config, "MEDIASERVER_FIELDS_BY_TYPE", {})
    media_type = str(getattr(config, "MEDIASERVER_TYPE", "") or "").lower()
    required_fields = fields_by_type.get(media_type)
    if not required_fields:
        return False
    return all(str(getattr(config, field, "") or "").strip() for field in required_fields)


def media_server_item(item_id, file_path=None, title=None, author=None):
    track_id = str(item_id)
    path = str(file_path or "")
    name = str(title or track_id)
    item = {
        "id": track_id,
        "Id": track_id,
        "title": name,
        "Name": name,
        "path": path,
        "Path": path,
        "FilePath": path,
    }
    if author:
        item["artist"] = str(author)
        item["AlbumArtist"] = str(author)
    suffix = os.path.splitext(path)[1].lstrip(".")
    if suffix:
        item["suffix"] = suffix
    return item


def download_track_to_temp(item):
    from tasks.mediaserver import download_track

    return download_track(config.TEMP_DIR, item)


def remove_downloaded_file(path):
    if not path:
        return
    try:
        os.remove(path)
    except OSError:
        logger.warning("lumae_analysis could not remove temporary analysis file %s", path)


def configured_backfill_limit():
    raw = get_setting("backfill_batch_size", DEFAULT_BACKFILL_BATCH_SIZE)
    return normalize_backfill_limit(raw)


def analysis_time_limit_seconds():
    """Per-file time limit (setting ``analysis_time_limit_seconds``).

    It is the analyzers' soft deadline; the analysis child is killed 30 s
    after it (``analysis_isolation.HARD_LIMIT_HEADROOM_SECONDS``).
    """
    return analysis_isolation.normalize_limit(
        get_setting("analysis_time_limit_seconds", analysis_isolation.DEFAULT_LIMIT_SECONDS)
    )


def run_file_analysis(analyzer, path, **kwargs):
    """Run one file analysis in a child process under the hard limit (LUM-018).

    The host puts no timeout on the task (see ``enqueue_bounded``), and the
    analyzer's soft deadline cannot interrupt a decoder hung in native code.
    The setting is the analyzer's soft deadline, passed with each file, and
    the child is killed 30 s after it, so a progressing analysis stops at the
    soft deadline first. Failures raise with a LUM-007 category.
    """
    return analysis_isolation.run_isolated(
        analyzer, path, limit_seconds=analysis_time_limit_seconds(), **kwargs
    )


def analysis_failure_code(track_id, exc, context="failed"):
    """The LUM-007 category of an analysis failure; logs it.

    A child's failure is logged with its safe diagnostics only. An in-process
    exception is logged as before (its text can name a temporary file).
    """
    code = analysis_isolation.failure_category(exc)
    if code == "silent_audio":
        return code
    if isinstance(exc, analysis_isolation.IsolatedAnalysisError):
        logger.warning(
            "lumae_analysis analysis %s for %s: %s %s",
            context, track_id, exc, exc.diagnostics or {},
        )
    elif code in ("analysis_timeout", "resource_limit"):
        logger.warning("lumae_analysis bounded profile rejection for %s: %s", track_id, exc)
    else:
        logger.exception("lumae_analysis %s for %s", context, track_id)
    return code


def maintenance_paused():
    value = get_setting("maintenance_paused", False)
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on")
    return bool(value)


def normalize_backfill_limit(raw):
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return DEFAULT_BACKFILL_BATCH_SIZE
    return min(max(value, 1), MAX_BACKFILL_BATCH_SIZE)


def format_count(value):
    return f"{int(value):,}"


def track_count_label(value):
    count = int(value)
    suffix = "track" if count == 1 else "tracks"
    return f"{format_count(count)} {suffix}"


def disable_legacy_backfill_schedule(db):
    cur = db.cursor()
    cur.execute(
        "UPDATE cron SET enabled=FALSE WHERE task_type=%s",
        (BACKFILL_TASK_TYPE,),
    )
    cur.close()


def ensure_catalog_refresh_schedule(db):
    cur = db.cursor()
    cur.execute(
        "INSERT INTO cron (name, task_type, cron_expr, enabled) "
        "VALUES (%s, %s, %s, FALSE) ON CONFLICT (task_type) DO NOTHING",
        (CATALOG_REFRESH_TASK_TYPE, CATALOG_REFRESH_TASK_TYPE, "17 */6 * * *"),
    )
    cur.close()


def ensure_catalog_reconcile_schedule(db):
    """Install additive reconciliation state and an initially quiet schedule."""
    migrate_reconcile(db)


def ensure_provider_identity_recheck_schedule(db):
    cur = db.cursor()
    cur.execute(
        "INSERT INTO cron (name, task_type, cron_expr, enabled) "
        "VALUES (%s, %s, %s, TRUE) ON CONFLICT (task_type) DO UPDATE SET "
        "cron_expr=EXCLUDED.cron_expr, enabled=TRUE",
        (
            PROVIDER_IDENTITY_RECHECK_TASK_TYPE,
            PROVIDER_IDENTITY_RECHECK_TASK_TYPE,
            "2,32 * * * *",
        ),
    )
    cur.close()


def ensure_analysis_projection_schedule(db):
    cur = db.cursor()
    cur.execute(
        "INSERT INTO cron (name, task_type, cron_expr, enabled) "
        "VALUES (%s, %s, %s, FALSE) ON CONFLICT (task_type) DO NOTHING",
        (ANALYSIS_PROJECTION_TASK_TYPE, ANALYSIS_PROJECTION_TASK_TYPE, "47 */6 * * *"),
    )
    cur.close()


def ensure_collection_retention_schedule(db):
    """Daily bounded cleanup of expired collection, shelf and Vibe receipts and
    abandoned restore progress (F2). Enabled on install; an administrator's
    later change to the row is kept."""
    cur = db.cursor()
    cur.execute(
        "INSERT INTO cron (name, task_type, cron_expr, enabled) "
        "VALUES (%s, %s, %s, TRUE) ON CONFLICT (task_type) DO NOTHING",
        (COLLECTION_RETENTION_TASK_TYPE, COLLECTION_RETENTION_TASK_TYPE, "23 3 * * *"),
    )
    cur.close()


def _resolve_task_server_id(adapter, server_id):
    requested = str(server_id or adapter.active_server_id() or "")
    if adapter.mode != "v3_registry" or requested != "legacy-default":
        return requested or None
    if any(
        str(server.get("server_id") or "") == requested
        for server in adapter.list_servers()
    ):
        return requested
    try:
        aliases = [
            source
            for source in resolve_catalog_source(get_db())
            if source.get("rebind_status") == "active"
            and source.get("continuity_from") == requested
        ]
    except Exception:
        aliases = []
    if len(aliases) == 1:
        return aliases[0]["server_id"]
    logger.warning(
        "lumae_analysis skipped stale v2 task for legacy-default while v3 source rebind is pending"
    )
    return None


def wake_profile_backfill_after_catalog_refresh(result, db=None):
    """Keep one exact-source repair wake even if a batch is finishing."""
    source = result["catalog_instance_id"]
    server_id = result["server_id"]
    db = db or get_db()
    force_now = bool(result.get("changes") or
                     result.get("change_reason") == "fingerprint_schema_rebase")
    with db.cursor() as cur:
        cur.execute(
            f"""UPDATE {profile_backfill_state_table()}
                   SET refresh_wake_pending=CASE WHEN %s THEN TRUE
                                                 ELSE refresh_wake_pending END,
                       next_retry_at=CASE WHEN %s AND status='queued' THEN NULL
                                          ELSE next_retry_at END,
                       updated_at=now()
                 WHERE catalog_instance_id=%s AND status IN ('queued', 'running')
                 RETURNING catalog_instance_id""",
            (force_now, force_now, source),
        )
        active = cur.fetchone() is not None
    if active:
        arm_reconcile(db, "catalog_profile_repair")
        db.commit()
        return True
    db.commit()
    return start_profile_backfill(
        catalog_instance_id=source, server_id=server_id, enqueue_job=False,
    )


def catalog_refresh_task(server_id=None):
    if maintenance_paused():
        return {"status": "paused", "reason": "maintenance_paused"}
    adapter = get_core_adapter()
    resolved_server_id = _resolve_task_server_id(adapter, server_id)
    if not resolved_server_id:
        return {"status": "skipped", "reason": "source_rebind_required"}
    result = refresh_catalog(server_id=resolved_server_id)
    try:
        source = result["catalog_instance_id"]
        changed = bool(result.get("changes") or
                       result.get("change_reason") == "fingerprint_schema_rebase")
        if (changed or
                find_backfill_ids(1, catalog_instance_id=source,
                                  server_id=result["server_id"]) or
                next_profile_retry_at(source)):
            wake_profile_backfill_after_catalog_refresh(result)
        if changed and arm_edge_backfill(get_db(), source):
            arm_reconcile(get_db(), "edge_backfill_ready", commit=True)
    except Exception:
        _rollback_if_possible(get_db())
        logger.exception("Could not arm source profile repair after catalogue publication")
    try:
        db = get_db()
        optional_storage.prune(db)
        db.commit()
    except Exception:
        _rollback_if_possible(get_db())
        logger.exception("Optional measurement retention will retry on the next catalogue refresh")
    # The publication may have withdrawn profiles; /settings/status reads
    # these counts (P2-1).
    refresh_status_snapshot(get_db(), result.get("catalog_instance_id"))
    return result


def next_settled_analysis_run(db=None, server_id=None):
    """Return one durable run whose AudioMuse parent can no longer emit hooks."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT r.server_id, r.catalog_instance_id, r.run_id, r.retry_count
          FROM {analysis_runs_table()} r
          LEFT JOIN task_status parent
            ON parent.task_id=r.run_id AND parent.task_type='main_analysis'
         WHERE (r.status IN ('pending', 'registering', 'queued',
                             'enqueue_failed', 'failed')
                OR (r.status='running' AND r.updated_at
                    < now() - interval '{ANALYSIS_RUN_STALE_MINUTES} minutes'))
           AND (r.next_retry_at IS NULL OR r.next_retry_at <= now())
           AND (%s IS NULL OR r.server_id=%s)
           AND (
                parent.status IN ('SUCCESS', 'FAILURE', 'FAIL', 'REVOKED')
                OR (
                    parent.task_id IS NULL
                    AND r.last_seen_at
                        < now() - interval '{ANALYSIS_RUN_SETTLE_GRACE_MINUTES} minutes'
                    AND NOT EXISTS (
                        SELECT 1 FROM task_status live
                         WHERE live.parent_task_id IS NULL
                           AND live.task_type='main_analysis'
                           AND live.status IN (
                               'NEW', 'QUEUED', 'PENDING', 'STARTED',
                               'RUNNING', 'PROGRESS'
                           )
                    )
                )
           )
         ORDER BY r.last_seen_at, r.catalog_instance_id, r.run_id
         LIMIT 1
        """,
        (server_id, server_id),
    )
    row = cur.fetchone()
    cur.close()
    if row is None:
        return None
    return {
        "server_id": str(row[0]),
        "catalog_instance_id": str(row[1]),
        "run_id": str(row[2]),
        "retry_count": int(row[3] or 0) if len(row) > 3 else 0,
    }


def next_preparation_run(db=None, server_id=None):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT server_id, catalog_instance_id, retry_count
          FROM {preparation_state_table()}
         WHERE (status='queued'
            OR (status='failed' AND (next_retry_at IS NULL OR next_retry_at <= now()))
            OR (status='running' AND updated_at
                < now() - interval '{PREPARATION_STALE_HOURS} hours'))
           AND (%s IS NULL OR server_id=%s)
         ORDER BY updated_at, catalog_instance_id
         LIMIT 1
        """,
        (server_id, server_id),
    )
    row = cur.fetchone()
    cur.close()
    return (str(row[0]), str(row[1]), int(row[2] or 0)) if row else None


def next_relationship_run(db=None, server_id=None):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT s.current_core_server_id, r.catalog_instance_id, r.retry_count
          FROM {table('relationship_state')} r
          JOIN {table('catalog_sources')} s USING (catalog_instance_id)
         WHERE s.rebind_status='active'
           AND (r.status='queued'
                OR (r.status IN ('failed', 'waiting_for_index')
                    AND (r.next_retry_at IS NULL OR r.next_retry_at <= now()))
                OR (r.status='running' AND r.updated_at
                    < now() - interval '2 minutes'))
           AND (%s IS NULL OR s.current_core_server_id=%s)
         ORDER BY r.updated_at, r.catalog_instance_id
         LIMIT 1
        """,
        (server_id, server_id),
    )
    row = cur.fetchone()
    cur.close()
    return (str(row[0]), str(row[1]), int(row[2] or 0)) if row else None


def next_profile_backfill_run(db=None, server_id=None):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT server_id, catalog_instance_id, retry_count
          FROM {profile_backfill_state_table()}
         WHERE ((status='queued' AND (next_retry_at IS NULL OR next_retry_at <= now()))
            OR (status='failed' AND (next_retry_at IS NULL OR next_retry_at <= now()))
            OR (status='running' AND updated_at
                < now() - interval '{BACKFILL_STALE_MINUTES} minutes'))
           AND (%s IS NULL OR server_id=%s)
         ORDER BY updated_at, catalog_instance_id
         LIMIT 1
        """,
        (server_id, server_id),
    )
    row = cur.fetchone()
    cur.close()
    return (str(row[0]), str(row[1]), int(row[2] or 0)) if row else None


def _rollback_if_possible(db):
    rollback = getattr(db, "rollback", None)
    if callable(rollback):
        rollback()


def _safe_reconcile_schedule(db, paused=None):
    try:
        return reconcile_schedule_from_state(
            db,
            paused=maintenance_paused() if paused is None else bool(paused),
        )
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not update the adaptive reconcile schedule")
        return None


def _safe_progress(phase, current=None, total=None):
    try:
        progress_event(phase, current=current, total=total)
    except Exception:
        db = get_db()
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not update reconcile progress")


def _reconcile_result_summary(result):
    if not isinstance(result, dict):
        return {"status": str(result)[:200]}
    allowed = (
        "status",
        "songs_seen",
        "processed",
        "attempted",
        "ready",
        "failed",
        "skipped",
        "already_ready",
        "promoted",
        "queued_next",
        "queued_profiles",
        "generation",
        "changes",
        "album_count",
        "artist_count",
        "track_count",
    )
    return {key: result[key] for key in allowed if key in result}


def _run_reconcile_action(
    db,
    action,
    server_id,
    catalog_instance_id,
    work_key,
    retry_count,
    function,
    *args,
):
    event_id = None
    try:
        event_id = begin_event(
            db,
            action,
            server_id,
            catalog_instance_id,
            work_key=work_key,
            attempt=int(retry_count or 0) + 1,
        )
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not start the reconcile status event")
    try:
        _safe_progress("starting")
        result = function(*args)
        result_status = str((result or {}).get("status") or "complete")
        if result_status in ("coalesced", "already_finalized", "paused"):
            try:
                discard_event(db, event_id)
            except Exception:
                _rollback_if_possible(db)
            return result
        if result_status == "waiting_for_index":
            next_retry_at = None
            try:
                next_retry_at = defer_work(
                    db,
                    action,
                    catalog_instance_id,
                    work_key=work_key,
                    minutes=60,
                )
                finish_event(
                    db,
                    event_id,
                    "deferred",
                    phase="waiting for AudioMuse index",
                    summary=_reconcile_result_summary(result),
                    next_retry_at=next_retry_at,
                )
            except Exception:
                _rollback_if_possible(db)
                logger.exception("lumae_analysis could not record deferred reconcile work")
            return result
        if action == "relationships" and result_status == "queued":
            # A committed checkpoint is continuation work, not a failed build
            # or a published generation. Keep minute cadence without backoff.
            update_work_retry(db, action, catalog_instance_id, failed=False)
            finish_event(db, event_id, "deferred", phase="relationship build checkpointed",
                         summary=_reconcile_result_summary(result))
            return result
        if result_status in ("failed", "failure", "error"):
            raise RuntimeError(str((result or {}).get("error") or result_status))
        if action == "edge_backfill":
            # The pass keeps its own next_retry_at (the re-sweep after a
            # finished pass); resetting it here would make it due at once.
            finish_event(db, event_id, "success", phase=result_status,
                         summary=_reconcile_result_summary(result))
            return result
        # Track failures do not mean the batch itself crashed. Keep its normal
        # retry lifecycle, but persist a warning verdict for the journal.
        has_track_failures = (
            action == "profile_backfill" and int((result or {}).get("failed") or 0) > 0
        )
        try:
            update_work_retry(
                db,
                action,
                catalog_instance_id,
                work_key=work_key,
                failed=False,
            )
            finish_event(
                db,
                event_id,
                "success",
                phase="completed with warnings" if has_track_failures else "complete",
                summary=_reconcile_result_summary(result),
            )
        except Exception:
            _rollback_if_possible(db)
            logger.exception("lumae_analysis could not finish reconcile success state")
        return result
    except Exception as exc:
        _rollback_if_possible(db)
        retry = {"next_retry_at": None}
        try:
            retry = update_work_retry(
                db,
                action,
                catalog_instance_id,
                work_key=work_key,
                failed=True,
            )
        except Exception:
            _rollback_if_possible(db)
            logger.exception("lumae_analysis could not record reconcile retry state")
        try:
            finish_event(
                db,
                event_id,
                "failed",
                phase="failed",
                error=exc,
                next_retry_at=retry.get("next_retry_at"),
            )
        except Exception:
            _rollback_if_possible(db)
            logger.exception("lumae_analysis could not finish the reconcile status event")
        raise


def _safe_credits_reconcile(db, server_id, before_background):
    try:
        return credits_service.reconcile(db, server_id, before_background=before_background)
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis credits reconciliation unavailable")
        return None


def _safe_metadata_reconcile(db, before_background):
    try:
        return music_metadata.reconcile(db, before_background=before_background)
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis MusicBrainz lookups unavailable")
        return None


def catalog_reconcile_task():
    """Execute at most one durable action for the active source, then retune cadence."""
    db = get_db()
    if maintenance_paused():
        try:
            set_reconcile_paused(db, True)
        except Exception:
            _rollback_if_possible(db)
            logger.exception("lumae_analysis could not pause the reconcile schedule")
        return {
            "status": "paused",
            "requested": 0,
            "plugin_version": PLUGIN_VERSION,
            "catalog_builder_version": CATALOG_BUILDER_VERSION,
        }

    try:
        server_id = str(get_core_adapter().active_server_id() or "") or None
    except Exception:
        server_id = None

    requested = 0
    try:
        report_edge_runtime()
        # On-demand work the host refused to queue goes before everything.
        served = serve_deferred_interactive()
        if served:
            return {"status": "processed", "action": "interactive", "served": served}
        run = next_settled_analysis_run(db=db, server_id=server_id)
        if run:
            result = _run_reconcile_action(
                db,
                "analysis_run",
                run["server_id"],
                run["catalog_instance_id"],
                run["run_id"],
                run.get("retry_count", 0),
                finalize_analysis_run_task,
                run["server_id"],
                run["catalog_instance_id"],
                run["run_id"],
            )
            return {"status": "processed", "action": "analysis_run", "result": result}

        requested = enqueue_required_catalog_preparations(db=db, server_id=server_id)
        preparation = next_preparation_run(db=db, server_id=server_id)
        if preparation:
            result = _run_reconcile_action(
                db,
                "catalog_preparation",
                preparation[0],
                preparation[1],
                preparation[1],
                preparation[2] if len(preparation) > 2 else 0,
                prepare_lumae_task,
                *preparation[:2],
            )
            return {
                "status": "processed",
                "action": "catalog_preparation",
                "requested": int(requested),
                "result": result,
            }

        credits_result = _safe_credits_reconcile(db, server_id, before_background=True)
        if credits_result:
            return {"status": "processed", "action": "credits", "result": credits_result}

        metadata_result = _safe_metadata_reconcile(db, before_background=True)
        if metadata_result:
            return {"status": "processed", "action": "music_metadata", "result": metadata_result}

        relationship = next_relationship_run(db=db, server_id=server_id)
        if relationship:
            result = _run_reconcile_action(
                db,
                "relationships",
                relationship[0],
                relationship[1],
                relationship[1],
                relationship[2] if len(relationship) > 2 else 0,
                relationship_preparation_task,
                *relationship[:2],
            )
            return {"status": "processed", "action": "relationships", "result": result}

        profile = next_profile_backfill_run(db=db, server_id=server_id)
        if profile:
            result = _run_reconcile_action(
                db,
                "profile_backfill",
                profile[0],
                profile[1],
                profile[1],
                profile[2] if len(profile) > 2 else 0,
                profile_backfill_task,
                *profile[:2],
            )
            return {"status": "processed", "action": "profile_backfill", "result": result}

        edge = next_edge_backfill(db, server_id=server_id) if edge_profiles_enabled() else None
        if edge:
            result = _run_reconcile_action(
                db,
                "edge_backfill",
                edge[0],
                edge[1],
                edge[1],
                0,
                edge_backfill_task,
                edge[0],
                edge[1],
            )
            return {"status": "processed", "action": "edge_backfill", "result": result}

        credits_result = _safe_credits_reconcile(db, server_id, before_background=False)
        if credits_result:
            return {"status": "processed", "action": "credits", "result": credits_result}

        metadata_result = _safe_metadata_reconcile(db, before_background=False)
        if metadata_result:
            return {"status": "processed", "action": "music_metadata", "result": metadata_result}

        return {
            "status": "current",
            "requested": int(requested),
            "plugin_version": PLUGIN_VERSION,
            "catalog_builder_version": CATALOG_BUILDER_VERSION,
        }
    finally:
        _safe_reconcile_schedule(db)
        # The tick ran at most one action (a profile batch, a finalization, a
        # catalogue publication); the waveform counts that /settings/status
        # reads follow it, and a publication left without a summary gets one
        # (P2-1).
        refresh_status_snapshot(db, publications=True)


def analysis_projection_task(server_id=None):
    if maintenance_paused():
        return {"status": "paused", "reason": "maintenance_paused"}
    adapter = get_core_adapter()
    resolved_server_id = _resolve_task_server_id(adapter, server_id)
    if not resolved_server_id:
        return {"status": "skipped", "reason": "source_rebind_required"}
    try:
        result = project_analysis(server_id=resolved_server_id, adapter=adapter)
    except AnalysisProjectionDeferred as exc:
        # Held back by design, and a retry seconds later cannot change that:
        # the published projection stays, and the next trigger (this
        # schedule, an analysis run, catalogue preparation or the identity
        # recheck) projects. Raising made AudioMuse retry twice and mark the
        # task FAIL (1.5.0 and earlier).
        _rollback_if_possible(get_db())
        # A server Lumae does not mirror (not Navidrome) is skipped on every
        # all-servers run; its task row says so, which is enough.
        if exc.reason != "catalog_source_missing":
            logger.warning(
                "lumae_analysis deferred the analysis projection for %s (%s): %s",
                resolved_server_id,
                exc.reason,
                exc,
            )
        return {
            "status": "deferred",
            "reason": exc.reason,
            "server_id": resolved_server_id,
            "message": f"Analysis projection deferred: {exc}",
        }
    if not result.get("catalog_instance_id"):
        return result
    complete_projection_reconcile(get_db(), result["catalog_instance_id"])
    try:
        result["relationships"] = start_relationship_preparation(
            catalog_instance_id=result["catalog_instance_id"],
            server_id=resolved_server_id,
            enqueue_job=False,
        )
    except Exception as exc:
        logger.exception(
            "lumae_analysis could not request album and artist relationship preparation"
        )
        result["relationships"] = {
            "queued": False,
            "coalesced": False,
            "error": str(exc),
        }
    return result


def enqueue_required_catalog_preparations(db=None, server_id=None):
    """Durably request first-run and builder-upgrade preparation.

    The historical name remains API-compatible. No queue operation occurs;
    ``catalog_reconcile_task`` executes admitted work on a later watchdog tick.
    """
    if maintenance_paused():
        return 0
    db = db or get_db()
    try:
        sources = resolve_catalog_source(db)
    except Exception:
        logger.exception(
            "lumae_analysis could not discover catalogues requiring post-install preparation"
        )
        return 0
    requested = 0
    for source in sources:
        if server_id is not None and str(source.get("server_id") or "") != str(server_id):
            continue
        catalog = source.get("catalog") or {}
        if source.get("rebind_status") != "active":
            continue
        state = preparation_state(source["catalog_instance_id"], db=db)
        requires_publication = (
            int(catalog.get("generation") or 0) <= 0
            or bool(catalog.get("refresh_required", False))
            or not preparation_attestation_is_current(state)
        )
        if not requires_publication:
            continue
        try:
            if not claim_preparation(source, db=db):
                continue
            requested += 1
        except Exception:
            logger.exception(
                "lumae_analysis could not record required catalogue preparation"
            )
    return requested


def provider_identity_recheck_task(server_id=None):
    """Advance pending ID proofs and hand completed AudioMuse migrations off."""

    db = get_db()
    bridge = ProviderCatalogBridge()
    adapter = get_core_adapter()
    candidates = [
        server
        for server in bridge.list_servers()
        if server.get("supported") and (not server_id or server["server_id"] == server_id)
    ]
    results = []
    for server in candidates:
        sources = resolve_catalog_source(db, server_id=server["server_id"])
        transition = (
            provider_transition_health(db, sources[0]["catalog_instance_id"])
            if len(sources) == 1
            else None
        )
        if not transition:
            continue
        if transition.get("state") == "transition_pending":
            results.append(refresh_catalog(server_id=server["server_id"], db=db, bridge=bridge))
            continue
        if transition.get("state") != "applied":
            continue
        previous_health = transition.get("audiomuse_health")
        reconcile_required = projection_reconcile_required(
            db, sources[0]["catalog_instance_id"]
        )
        if previous_health == "ready" and not reconcile_required:
            continue
        result = {
            "catalog_instance_id": sources[0]["catalog_instance_id"],
            "server_id": server["server_id"],
            "previous_health": previous_health,
            "reconcile_required": reconcile_required,
            "projection_queued": False,
            "projection_processed": False,
        }
        try:
            health = previous_health
            if health != "ready":
                health = refresh_audiomuse_health(
                    db,
                    sources[0]["catalog_instance_id"],
                    server["server_id"],
                    adapter,
                    commit=False,
                )
            result["audiomuse_health"] = health
            if health == "ready":
                # Persist the transition-health verdict before projection does
                # its own transactional publication. This task already owns a
                # root worker slot, so it must not enqueue another root task.
                db.commit()
                projection = analysis_projection_task(server["server_id"])
                result["projection"] = projection
                # A projection that did not run (deferred: e.g. the provider
                # stopped answering since the health check) leaves the durable
                # reconcile request set, so the next recheck projects again.
                result["projection_processed"] = (projection or {}).get("status") not in (
                    "deferred",
                    "paused",
                    "skipped",
                )
            else:
                db.commit()
        except Exception as exc:
            rollback = getattr(db, "rollback", None)
            if callable(rollback):
                rollback()
            logger.exception(
                "lumae_analysis could not reconcile AudioMuse provider migration for %s",
                server["server_id"],
            )
            result["error"] = str(exc)
        results.append(result)
    return {"checked": len(results), "results": results}


def collection_retention_task():
    """Delete idempotency receipts and stale restore progress past their
    retention window, in bounded batches (F2, docs/plan P3-4 item 6:
    collections growth). Runs from the same cron watchdog as the other
    periodic maintenance tasks; see collection_manager and shelves for
    the retention windows, batch limits and lock order."""
    if maintenance_paused():
        return {"status": "paused", "reason": "maintenance_paused"}
    db = get_db()
    try:
        mutations_deleted = purge_expired_collection_mutations(db)
        restores_deleted = purge_stale_collection_restores(db)
        shelf_deleted = purge_expired_shelf_mutations(db)
        vibe_deleted = vibes.purge_expired_vibe_mutations(db)
        cover_deleted = covers.purge_expired_cover_mutations(db)
        cover_images_deleted = covers.purge_unused_cover_images(db)
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis collection retention cleanup failed")
        return {"status": "error"}
    return {
        "status": "ok",
        "collection_mutations_deleted": mutations_deleted,
        "collection_restores_deleted": restores_deleted,
        "shelf_mutations_deleted": shelf_deleted,
        "vibe_mutations_deleted": vibe_deleted,
        "cover_mutations_deleted": cover_deleted,
        "cover_images_deleted": cover_images_deleted,
    }


def observe_provider_identities_on_start():
    """Bounded, best-effort observation that never delays Flask startup indefinitely."""

    db = get_db()
    if db is None:
        return
    try:
        # AudioMuse records a plugin update even when an install hook fails. In
        # that case PostgreSQL rolls the hook transaction back while the new
        # plugin code remains active. Re-running this additive migration here
        # repairs the provider-identity tables before any startup read needs
        # them, including upgrades from releases that predate the transition
        # shield.
        migrate_provider_identity(db)
        db.commit()
    except Exception:
        rollback = getattr(db, "rollback", None)
        if callable(rollback):
            rollback()
        logger.exception("lumae_analysis could not ensure provider identity schema")
        return
    try:
        migrate_reconcile(db)
        db.commit()
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not ensure reconcile schema")
    try:
        # The P2-1 status summary, repaired the same way. Only generations
        # without a summary are counted, so this is normally a few lookups.
        cur = db.cursor()
        try:
            status_model.migrate_status_summary(cur)
            db.commit()
            status_model.backfill_publication_summaries(cur, commit=db.commit)
        finally:
            cur.close()
        db.commit()
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not ensure the status summary")
    try:
        log_integrity_on_start(db)
    except Exception:
        logger.exception("lumae_analysis could not check upgrade integrity")
    bridge = ProviderCatalogBridge()
    for server in bridge.list_servers():
        if not server.get("supported"):
            continue
        try:
            observe_provider_version(db, bridge, server["server_id"], commit=True)
        except Exception:
            rollback = getattr(db, "rollback", None)
            if callable(rollback):
                rollback()
            logger.exception(
                "lumae_analysis could not observe provider identity for %s",
                server["server_id"],
            )
    enqueue_required_catalog_preparations(db=db)
    _safe_reconcile_schedule(db)
    # The scheduled provider-identity recheck consumes durable transition
    # state. Startup never reaches into queue internals or creates root work.


def _drop_dj_tables(db):
    with db.cursor() as cur:
        for name in (
            "dj_worker_capability",
            "dj_analyses",
            "dj_analysis_jobs",
            "dj_analyses_v3",
            "dj_analysis_jobs_v3",
            "dj_control",
        ):
            cur.execute(f"DROP TABLE IF EXISTS {table(name)} CASCADE")
        # Match only the retired registrations; LIKE treats underscores as wildcards.
        # Let failures abort the migration transaction instead of hiding them.
        cur.execute(
            "DELETE FROM cron WHERE task_type IN (%s, %s)",
            ("plugin.lumae_analysis.dj_analysis", "plugin.lumae_analysis.dj_reconcile"),
        )


def migrate(db):
    cur = db.cursor()
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {profiles_table()} (
            track_id TEXT PRIMARY KEY,
            sample_rate INTEGER NOT NULL,
            duration_ms INTEGER NOT NULL,
            ref_lufs REAL NOT NULL,
            start_ramp BYTEA NOT NULL,
            end_ramp BYTEA NOT NULL,
            analyzer_ver INTEGER NOT NULL,
            profile_schema_ver INTEGER NOT NULL,
            media_signature TEXT,
            analyzed_at TIMESTAMP NOT NULL DEFAULT now(),
            status TEXT NOT NULL,
            last_error TEXT
        )
        """
    )
    cur.close()
    migrate_catalog(db)
    ensure_catalog_sources(db)
    migrate_provider_identity(db)
    require_projection_reconcile(db)
    cur = db.cursor()
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {source_profiles_table()} (
            catalog_instance_id TEXT NOT NULL REFERENCES {table('catalog_sources')}(catalog_instance_id)
                ON DELETE CASCADE,
            track_id TEXT NOT NULL,
            sample_rate INTEGER NOT NULL,
            duration_ms INTEGER NOT NULL,
            ref_lufs REAL NOT NULL,
            start_ramp BYTEA NOT NULL,
            end_ramp BYTEA NOT NULL,
            analyzer_ver INTEGER NOT NULL,
            profile_schema_ver INTEGER NOT NULL,
            media_signature TEXT,
            analyzed_at TIMESTAMP NOT NULL DEFAULT now(),
            status TEXT NOT NULL,
            last_error TEXT,
            PRIMARY KEY (catalog_instance_id, track_id)
        )
        """
    )
    migrations.ensure_index(
        cur,
        f"CREATE INDEX IF NOT EXISTS {table('source_profiles_status_idx')} "
        f"ON {source_profiles_table()} (catalog_instance_id, status)",
    )
    migrate_attempts(cur)
    migrations.ensure_index(
        cur,
        f"CREATE INDEX IF NOT EXISTS {source_profiles_table()}_deferred_idx "
        f"ON {source_profiles_table()} (analyzed_at) "
        f"WHERE status='pending_interactive' AND last_error='{DEFERRED_MARKER}'",
    )
    migrate_edge_profiles(db)
    _drop_dj_tables(db)
    optional_storage.migrate(db)
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {table('profile_migrations')} (
            name TEXT PRIMARY KEY,
            completed_at TIMESTAMP NOT NULL DEFAULT now()
        )
        """
    )
    # Releases before 0.8 could only analyze the default provider. Preserve
    # those expensive waveform results only when exactly one active source
    # makes their ownership unambiguous. Record the one-shot attempt even on a
    # multi-source install so a later default-provider change cannot misassign
    # legacy rows.
    cur.execute(
        f"""
        WITH migration AS (
            INSERT INTO {table('profile_migrations')} (name)
            VALUES ('legacy_default_profiles_v1')
            ON CONFLICT (name) DO NOTHING
            RETURNING name
        ), active_sources AS (
            SELECT catalog_instance_id
              FROM {table('catalog_sources')}
             WHERE rebind_status='active' AND provider_type='navidrome'
        ), default_source AS (
            SELECT catalog_instance_id
              FROM active_sources
             WHERE (SELECT COUNT(*) FROM active_sources)=1
        )
        INSERT INTO {source_profiles_table()}
            (catalog_instance_id, track_id, sample_rate, duration_ms, ref_lufs,
             start_ramp, end_ramp, analyzer_ver, profile_schema_ver,
             media_signature, analyzed_at, status, last_error)
        SELECT d.catalog_instance_id, p.track_id, p.sample_rate, p.duration_ms,
               p.ref_lufs, p.start_ramp, p.end_ramp, p.analyzer_ver,
               p.profile_schema_ver, p.media_signature, p.analyzed_at,
               p.status, p.last_error
          FROM migration CROSS JOIN default_source d CROSS JOIN {profiles_table()} p
        ON CONFLICT (catalog_instance_id, track_id) DO NOTHING
        """
    )
    # P3-6 (LUM-007): before 1.3.0 a stale transition kept the category of an
    # earlier failure, and the scheduler selects a stale row only without one
    # (or a released one after its cooldown), so such rows were never retried.
    # Stale transitions now clear it; clear it once on the rows left behind
    # with attempts left, keeping retry_count (an exhausted row stays so). The marker is read first, so a re-run takes no
    # lock on source_profiles.
    cur.execute(
        f"SELECT 1 FROM {table('profile_migrations')} WHERE name='stale_retry_category_v1'"
    )
    if cur.fetchone() is None:
        cur.execute(
            f"""
            WITH migration AS (
                INSERT INTO {table('profile_migrations')} (name)
                VALUES ('stale_retry_category_v1')
                ON CONFLICT (name) DO NOTHING
                RETURNING name
            )
            UPDATE {source_profiles_table()} p
               SET retry_category=NULL, failure_diagnostics=NULL
              FROM migration
             WHERE p.status='stale' AND p.retry_category IS NOT NULL
               AND p.retry_category <> 'queue_unavailable'
               AND p.retry_count < %s
            """,
            (RETRY_LIMIT,),
        )
    # Published validity is independent of the current analysis attempt. This
    # additive table is seeded once; runtime routing is introduced separately.
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {table('published_source_profiles')} (
            catalog_instance_id TEXT NOT NULL REFERENCES {table('catalog_sources')}(catalog_instance_id)
                ON DELETE CASCADE,
            track_id TEXT NOT NULL,
            sample_rate INTEGER NOT NULL,
            duration_ms INTEGER NOT NULL,
            ref_lufs REAL NOT NULL,
            start_ramp BYTEA NOT NULL,
            end_ramp BYTEA NOT NULL,
            analyzer_ver INTEGER NOT NULL,
            profile_schema_ver INTEGER NOT NULL,
            media_signature TEXT,
            analyzed_at TIMESTAMP NOT NULL,
            PRIMARY KEY (catalog_instance_id, track_id)
        )
        """
    )
    # Use a distinct durable marker, even when there are no ready rows.
    # The marker and copy share one SQL statement and the migration transaction:
    # a later default-source change or deleted publication cannot trigger a copy.
    cur.execute(
        f"""
        WITH migration AS (
            INSERT INTO {table('profile_migrations')} (name)
            VALUES ('published_source_profiles_seed_v1')
            ON CONFLICT (name) DO NOTHING
            RETURNING name
        )
        INSERT INTO {table('published_source_profiles')}
            (catalog_instance_id, track_id, sample_rate, duration_ms, ref_lufs,
             start_ramp, end_ramp, analyzer_ver, profile_schema_ver,
             media_signature, analyzed_at)
        SELECT p.catalog_instance_id, p.track_id, p.sample_rate, p.duration_ms,
               p.ref_lufs, p.start_ramp, p.end_ramp, p.analyzer_ver,
               p.profile_schema_ver, p.media_signature, p.analyzed_at
          FROM migration CROSS JOIN {source_profiles_table()} p
         WHERE p.status='ready'
        ON CONFLICT (catalog_instance_id, track_id) DO NOTHING
        """
    )
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {preparation_state_table()} (
            catalog_instance_id TEXT PRIMARY KEY REFERENCES {table('catalog_sources')}(catalog_instance_id)
                ON DELETE CASCADE,
            server_id TEXT NOT NULL,
            status TEXT NOT NULL,
            phase TEXT NOT NULL,
            queued_profiles INTEGER NOT NULL DEFAULT 0,
            profile_jobs INTEGER NOT NULL DEFAULT 0,
            target_plugin_version TEXT,
            target_catalog_builder_version INTEGER,
            worker_plugin_version TEXT,
            worker_catalog_builder_version INTEGER,
            last_error TEXT,
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT now()
        )
        """
    )
    migrations.ensure_columns(
        cur, preparation_state_table(),
        "target_plugin_version TEXT",
        "target_catalog_builder_version INTEGER",
        "worker_plugin_version TEXT",
        "worker_catalog_builder_version INTEGER",
    )
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {profile_backfill_state_table()} (
            catalog_instance_id TEXT PRIMARY KEY REFERENCES {table('catalog_sources')}(catalog_instance_id)
                ON DELETE CASCADE,
            server_id TEXT NOT NULL,
            status TEXT NOT NULL,
            processed_profiles INTEGER NOT NULL DEFAULT 0,
            queued_profiles INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT now()
        )
        """
    )
    migrations.ensure_columns(
        cur, profile_backfill_state_table(),
        "refresh_wake_pending BOOLEAN NOT NULL DEFAULT FALSE",
    )
    cur.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {analysis_runs_table()} (
            catalog_instance_id TEXT NOT NULL REFERENCES {table('catalog_sources')}(catalog_instance_id)
                ON DELETE CASCADE,
            run_id TEXT NOT NULL,
            server_id TEXT NOT NULL,
            status TEXT NOT NULL,
            songs_seen INTEGER NOT NULL DEFAULT 0,
            finalizer_job_id TEXT,
            queued_profiles INTEGER NOT NULL DEFAULT 0,
            profile_jobs INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            first_seen_at TIMESTAMP NOT NULL DEFAULT now(),
            last_seen_at TIMESTAMP NOT NULL DEFAULT now(),
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT now(),
            PRIMARY KEY (catalog_instance_id, run_id)
        )
        """
    )
    migrations.ensure_index(
        cur,
        f"CREATE INDEX IF NOT EXISTS {table('analysis_runs_status_idx')} "
        f"ON {analysis_runs_table()} (status, updated_at)",
    )
    # Releases through 1.1.6 could strand rows while importing AudioMuse/RQ
    # queue internals. Re-admit them to the database-driven reconciler.
    cur.execute(
        f"""
        UPDATE {analysis_runs_table()}
           SET status='pending', finalizer_job_id=NULL, last_error=NULL,
               completed_at=NULL, updated_at=now()
         WHERE status IN ('registering', 'queued', 'enqueue_failed', 'failed')
            OR (status='running' AND updated_at
                < now() - interval '{ANALYSIS_RUN_STALE_MINUTES} minutes')
        """
    )
    # Retarget work admitted by an older plugin process so a reloaded worker can
    # attest and execute it. The claim remains coalesced in SQL.
    cur.execute(
        f"""
        UPDATE {preparation_state_table()}
           SET status='queued', phase='queued',
               target_plugin_version=%s,
               target_catalog_builder_version=%s,
               worker_plugin_version=NULL,
               worker_catalog_builder_version=NULL,
               last_error=NULL, completed_at=NULL, updated_at=now()
         WHERE status IN ('queued', 'running', 'failed')
        """,
        (PLUGIN_VERSION, CATALOG_BUILDER_VERSION),
    )
    cur.close()
    migrate_enrichment(db)
    credits_store.migrate(db)
    prune_catalog_storage(db)
    # Must run after the published-profile seed above (marker
    # published_source_profiles_seed_v1): its edge sweep deletes every edge
    # no published profile reaches, which before the seed is every edge of a
    # 1.2.5 install (P2-3). After that sweep it withdraws the seed's
    # orphans and republishes ready-but-unpublished profiles (P3-7).
    compact_enrichment_storage(db, profile_versions=(ANALYZER_VERSION, SCHEMA_VERSION))
    migrate_collections(db)
    refresh_integrity_snapshot(db)
    refresh_status_summaries(db)
    migrate_shelves(db)
    vibes.migrate_vibes(db)
    covers.migrate_covers(db)
    personal_discovery.migrate(db)
    music_metadata.migrate(db)
    music_metadata.retire_schedule(db)
    ensure_catalog_refresh_schedule(db)
    ensure_catalog_reconcile_schedule(db)
    ensure_provider_identity_recheck_schedule(db)
    ensure_analysis_projection_schedule(db)
    ensure_collection_retention_schedule(db)
    disable_legacy_backfill_schedule(db)
    db.commit()
    # Installation is schema work, not a reason to rebuild the full analysis
    # and relationship projections. Only a missing/stale catalogue publication
    # is admitted here; ordinary analysis hooks and explicit prepare requests
    # own later enrichment.
    enqueue_required_catalog_preparations(db=db)
    _safe_reconcile_schedule(db)
    # Provider and catalogue watchdogs consume the durable requests above.
    # Install hooks remain schema-only and never queue root work.


def parse_ids(value):
    if not value:
        return []
    ids = []
    seen = set()
    for raw in str(value).split(","):
        track_id = raw.strip()
        if track_id and track_id not in seen:
            ids.append(track_id)
            seen.add(track_id)
    return ids[:500]


def fetch_profile_rows(ids, catalog_instance_id=None):
    if not ids:
        return []
    db = get_db()
    cur = db.cursor()
    if catalog_instance_id:
        cur.execute(
            f"""
            SELECT p.track_id, p.sample_rate, p.duration_ms, p.ref_lufs, p.start_ramp, p.end_ramp,
                   p.analyzer_ver, p.analyzed_at, p.media_signature, p.status, p.last_error,
                   edge.payload AS edge_profile
              FROM {source_profiles_table()} p {edge_join()}
             WHERE p.catalog_instance_id=%s AND p.track_id = ANY(%s)
            """,
            (catalog_instance_id, ids),
        )
    else:
        # Compatibility path for pre-0.8 clients on a single-provider install.
        cur.execute(
            f"""
            SELECT track_id, sample_rate, duration_ms, ref_lufs, start_ramp, end_ramp,
                   analyzer_ver, analyzed_at, media_signature, status, last_error
              FROM {profiles_table()}
             WHERE track_id = ANY(%s)
            """,
            (ids,),
        )
    columns = [desc[0] for desc in cur.description]
    rows = [dict(zip(columns, row)) for row in cur.fetchall()]
    cur.close()
    return rows


def fetch_published_profile_rows(ids, catalog_instance_id):
    if not ids:
        return []
    db = get_db()
    cur = db.cursor()
    cur.execute(
        f"""SELECT p.track_id, p.sample_rate, p.duration_ms, p.ref_lufs,
                  p.start_ramp, p.end_ramp, p.analyzer_ver, p.analyzed_at,
                  p.media_signature, edge.payload AS edge_profile
             FROM {table('published_source_profiles')} p {edge_join()}
            WHERE p.catalog_instance_id=%s AND p.track_id=ANY(%s)""",
        (catalog_instance_id, ids),
    )
    columns = [desc[0] for desc in cur.description]
    rows = [dict(zip(columns, row)) for row in cur.fetchall()]
    cur.close()
    return rows


def _bytes(value):
    if value is None:
        return b""
    if isinstance(value, memoryview):
        return value.tobytes()
    if isinstance(value, bytes):
        return value
    return bytes(value)


def serialize_ready_profile(row):
    return serialize_profile(
        row["track_id"], row["sample_rate"], row["duration_ms"], row["ref_lufs"],
        row["start_ramp"], row["end_ramp"], row["analyzer_ver"], row["analyzed_at"],
        row.get("media_signature"), edge_profile=row.get("edge_profile"),
    )


def split_analyze_ids(ids, catalog_instance_id=None):
    rows = fetch_profile_rows(ids, catalog_instance_id=catalog_instance_id)
    by_id = {row["track_id"]: row for row in rows}
    accepted = []
    already_ready = []
    already_pending = []
    for track_id in ids:
        row = by_id.get(track_id)
        status = row.get("status") if row else None
        if status == "ready":
            current_signature = (
                catalog_media_signature(
                    track_id, catalog_instance_id=catalog_instance_id
                )
                if catalog_instance_id else None
            )
            if current_signature and row.get("media_signature") != current_signature:
                accepted.append(track_id)
            else:
                already_ready.append(track_id)
        elif is_pending_profile_status(status):
            already_pending.append(track_id)
        else:
            accepted.append(track_id)
    return accepted, already_ready, already_pending


def is_pending_profile_status(status):
    return str(status or "") in ("pending", "pending_interactive")


def arm_profile_claim_recovery(catalog_instance_id, db=None, commit=True):
    """Keep a durable wake for an abandoned token, including hook-only work."""
    db = db or get_db()
    cur = db.cursor()
    try:
        cur.execute(
            f"""INSERT INTO {profile_backfill_state_table()}
                    (catalog_instance_id, server_id, status, next_retry_at)
                   SELECT s.catalog_instance_id, s.current_core_server_id,
                          'queued', now() + interval '{PREPARATION_STALE_HOURS} hours'
                     FROM {table('catalog_sources')} s
                    WHERE s.catalog_instance_id=%s AND s.rebind_status='active'
                   ON CONFLICT (catalog_instance_id) DO UPDATE SET
                       status=CASE WHEN {profile_backfill_state_table()}.status='running'
                                   THEN 'running' ELSE 'queued' END,
                       next_retry_at=CASE
                           WHEN {profile_backfill_state_table()}.status='running'
                               THEN {profile_backfill_state_table()}.next_retry_at
                           WHEN {profile_backfill_state_table()}.status='queued'
                                AND {profile_backfill_state_table()}.next_retry_at IS NULL
                               THEN NULL
                           ELSE LEAST(
                               COALESCE({profile_backfill_state_table()}.next_retry_at,
                                        EXCLUDED.next_retry_at),
                               EXCLUDED.next_retry_at)
                           END,
                       refresh_wake_pending=CASE
                           WHEN {profile_backfill_state_table()}.status='running'
                               THEN TRUE
                           ELSE {profile_backfill_state_table()}.refresh_wake_pending END,
                       updated_at=now()
                   RETURNING catalog_instance_id""",
            (catalog_instance_id,),
        )
        armed = cur.fetchone() is not None
        if armed:
            arm_reconcile(db, "profile_claim_recovery")
        if commit:
            db.commit()
        return armed
    except Exception:
        db.rollback()
        raise
    finally:
        cur.close()


def mark_pending(ids, catalog_instance_id=None, priority="background"):
    if not ids:
        return {}
    if catalog_instance_id:
        db = get_db()
        return admit_attempts(
            db, catalog_instance_id, ids, priority=priority,
            analyzer_version=ANALYZER_VERSION, schema_version=SCHEMA_VERSION,
            recovery_arm=arm_profile_claim_recovery,
        )
    pending_status = "pending_interactive" if priority == "interactive" else "pending"
    db = get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {profiles_table()}
            (track_id, sample_rate, duration_ms, ref_lufs, start_ramp, end_ramp,
             analyzer_ver, profile_schema_ver, analyzed_at, status, last_error)
        SELECT unnest(%s::text[]), 0, 0, 0, decode('', 'hex'), decode('', 'hex'),
               %s, %s, now(), %s, NULL
        ON CONFLICT (track_id) DO UPDATE SET
            analyzed_at = EXCLUDED.analyzed_at,
            status = EXCLUDED.status,
            last_error = NULL
        """,
        (ids, ANALYZER_VERSION, SCHEMA_VERSION, pending_status),
    )
    db.commit()
    cur.close()
    return {}

def release_pending(ids, catalog_instance_id=None,
                    reason="Profile job could not be queued", tokens=None,
                    count_failure=True):
    """Release admitted attempts. ``count_failure=False`` for a release that
    never tried the analysis (pause, legacy migration, batch abort), so it
    does not use up the retry budget (LUM-007)."""
    if not ids:
        return
    if catalog_instance_id:
        return release_attempts(
            get_db(), catalog_instance_id,
            {track_id: tokens[track_id] for track_id in ids if tokens and track_id in tokens},
            reason,
            count_failure=count_failure,
        )
    db = get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        UPDATE {profiles_table()}
           SET status='stale', last_error=%s, analyzed_at=now()
         WHERE track_id=ANY(%s) AND status IN ('pending', 'pending_interactive')
        """,
        (str(reason)[:2000], ids),
    )
    db.commit()
    cur.close()

def enqueue_profile_analysis(
    ids,
    catalog_instance_id=None,
    server_id=None,
    *,
    priority="background",
):
    queue_name = "high" if priority == "interactive" else "default"
    tokens = mark_pending(
        ids, catalog_instance_id=catalog_instance_id, priority=priority
    )
    if catalog_instance_id and not tokens:
        return None
    admitted_ids = [track_id for track_id in ids if not catalog_instance_id or track_id in tokens]
    try:
        return enqueue_bounded(
            analyze_tracks_task,
            admitted_ids,
            catalog_instance_id,
            server_id,
            priority,
            tokens if catalog_instance_id else None,
            queue=queue_name,
            timeout=PROFILE_JOB_TIMEOUT_SECONDS,
        )
    except Exception as exc:
        if priority == "interactive" and catalog_instance_id and host_queue_busy(exc):
            # Saved, not lost: the next worker task serves it.
            mark_profiles_deferred(get_db(), catalog_instance_id, tokens)
            _wake_for_deferred()
            return DEFERRED
        release_pending(
            admitted_ids,
            catalog_instance_id=catalog_instance_id,
            reason=f"Profile job could not be queued: {exc}",
            tokens=tokens,
        )
        raise

def load_track_file(track_id, catalog_instance_id=None, server_id=None):
    db = get_db()
    adapter = get_core_adapter()
    server_id = server_id or adapter.active_server_id()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT t.track_id, t.title, t.artist_display, t.media_fp,
               s.current_core_server_id
          FROM {table('catalog_sources')} s
          JOIN {table('catalog_state')} c USING (catalog_instance_id)
          JOIN {table('catalog_tracks')} t
            ON t.catalog_instance_id=s.catalog_instance_id
           AND t.published_generation=c.published_generation
         WHERE t.track_id=%s AND t.available=TRUE
           AND s.rebind_status='active'
           AND (%s IS NULL OR s.catalog_instance_id=%s)
           AND (%s IS NULL OR s.current_core_server_id=%s)
         ORDER BY s.is_default DESC
         LIMIT 1
        """,
        (track_id, catalog_instance_id, catalog_instance_id, server_id, server_id),
    )
    row = cur.fetchone()
    cur.close()
    if not row:
        return None
    if len(row) < 5:
        # Rollback-compatible path for a pre-catalogue profile migration. New
        # installations and completed catalogue refreshes always use the rich
        # five-column provider occurrence row below.
        item_id = row[0]
        file_path = row[1] if len(row) > 1 else None
        title = row[2] if len(row) > 2 else None
        author = row[3] if len(row) > 3 else None
        if file_path and os.path.exists(file_path):
            return {
                "track_id": str(item_id),
                "file_path": file_path,
                "media_signature": media_signature(file_path),
                "cleanup_path": None,
            }
        if not media_server_download_available():
            return None
        item = media_server_item(item_id, file_path, title, author)
        downloaded_path = download_track_to_temp(item)
        if not downloaded_path or not os.path.exists(downloaded_path):
            raise MediaDownloadError("media server download failed")
        return {
            "track_id": str(item_id),
            "file_path": downloaded_path,
            "media_signature": media_signature(downloaded_path),
            "cleanup_path": downloaded_path,
        }
    item_id = row[0]
    title = row[1] if len(row) > 1 else None
    author = row[2] if len(row) > 2 else None
    media_fp = row[3] if len(row) > 3 else None
    source_server_id = row[4] if len(row) > 4 else server_id

    try:
        item = media_server_item(item_id, None, title, author)
        downloaded_path = ProviderCatalogBridge(adapter).download_track(
            source_server_id, config.TEMP_DIR, item
        )
    except Exception as exc:
        logger.warning("lumae_analysis could not download %s for analysis: %s", track_id, exc)
        raise MediaDownloadError("media server download failed") from exc

    if not downloaded_path or not os.path.exists(downloaded_path):
        raise MediaDownloadError("media server download failed")
    return {
        "track_id": str(item_id),
        "file_path": downloaded_path,
        "media_signature": f"catalog-media:{media_fp}" if media_fp else media_signature(downloaded_path),
        "cleanup_path": downloaded_path,
    }


def upsert_profile(
    track_id,
    result,
    status,
    last_error=None,
    media_sig=None,
    catalog_instance_id=None,
    attempt_token=None,
    failure_code=None,
    diagnostics=None,
):
    if catalog_instance_id:
        return complete_attempt(
            get_db(), catalog_instance_id, track_id, attempt_token,
            result, status, last_error, media_sig, ANALYZER_VERSION, SCHEMA_VERSION,
            failure_code=failure_code, diagnostics=diagnostics,
        )
    # The pre-source compatibility table has no public profile stream.
    db = get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {profiles_table()}
            (track_id, sample_rate, duration_ms, ref_lufs, start_ramp, end_ramp,
             analyzer_ver, profile_schema_ver, media_signature, analyzed_at, status, last_error)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, now(), %s, %s)
        ON CONFLICT (track_id) DO UPDATE SET
            sample_rate=EXCLUDED.sample_rate, duration_ms=EXCLUDED.duration_ms,
            ref_lufs=EXCLUDED.ref_lufs, start_ramp=EXCLUDED.start_ramp,
            end_ramp=EXCLUDED.end_ramp, analyzer_ver=EXCLUDED.analyzer_ver,
            profile_schema_ver=EXCLUDED.profile_schema_ver,
            media_signature=EXCLUDED.media_signature, analyzed_at=EXCLUDED.analyzed_at,
            status=EXCLUDED.status, last_error=EXCLUDED.last_error
        """,
        (track_id, int(getattr(result, "sample_rate", 0)),
         int(getattr(result, "duration_ms", 0)),
         float(getattr(result, "ref_lufs", 0.0)),
         getattr(result, "start_ramp_blob", b""),
         getattr(result, "end_ramp_blob", b""),
         ANALYZER_VERSION, SCHEMA_VERSION, media_sig, status, last_error),
    )
    db.commit()
    cur.close()
    return True


def catalog_capability():
    return {
        "contract_revision": CONTRACT_REVISION,
        "catalog_schema_version": CATALOG_SCHEMA_VERSION,
        "analysis_schema_version": ANALYSIS_SCHEMA_VERSION,
        "catalog_builder_version": CATALOG_BUILDER_VERSION,
        "supported_core_range": SUPPORTED_CORE_RANGE,
        "supported_provider_types": sorted(SUPPORTED_PROVIDER_TYPES),
        "features": list(CATALOG_FEATURES),
    }


def sync_contract(compatibility):
    """Describe breaking schemas and semantic formats independently of core version."""
    return {
        "revision": CONTRACT_REVISION,
        "producer": "lumae_analysis",
        "core_api_contract": compatibility.api_contract,
        "streams": {
            "catalog": {
                "schema_version": CATALOG_SCHEMA_VERSION,
                "semantic_contracts": [
                    "provider_track_ids_v1",
                    "complete_catalog_generation_v1",
                    "contiguous_change_journal_v1",
                ],
            },
            "analysis": {
                "schema_version": ANALYSIS_SCHEMA_VERSION,
                "semantic_contracts": [
                    "analysis_link_evidence_v1",
                    "musicnn_f32le_200_v1",
                    "clap_f32le_512_v1",
                    "audiomuse_musicnn_scalars_v1",
                ],
            },
            "profiles": {
                "schema_version": SCHEMA_VERSION,
                "analyzer_version": ANALYZER_VERSION,
                "semantic_contracts": ["lumae_playback_profile_v1"],
            },
            "credits": credits_service.capability(),
            "relationships": {
                "schema_version": RELATIONSHIP_SCHEMA_VERSION,
                "algorithm_version": RELATIONSHIP_ALGORITHM_VERSION,
                "semantic_contracts": ["lumae_album_artist_relationships_v1"],
            },
        },
    }


def resolve_profile_source(catalog_instance_id=None, server_id=None, db=None):
    """Resolve one exact profile namespace; never fall through across providers."""
    sources = resolve_catalog_source(
        db or get_db(),
        server_id=str(server_id) if server_id else None,
        catalog_instance_id=str(catalog_instance_id) if catalog_instance_id else None,
    )
    if len(sources) != 1:
        raise ValueError(
            "An explicit catalog_instance_id is required when multiple music servers are configured."
        )
    source = sources[0]
    if catalog_instance_id and source["catalog_instance_id"] != str(catalog_instance_id):
        raise ValueError("Profile catalogue source identity changed")
    if server_id and not source_matches_server_id(source, server_id):
        raise ValueError("Profile music-server identity changed")
    return source


def profiles_unpublished_ready_count(db):
    """Current 'ready' source profiles that have no published row (AUD-05).

    A 1.2.5 worker wrote 'ready' rows and journal events but never a
    published_source_profiles row, and 1.3.0 then treats the track as current.
    "Current" means what ``published_profile_current`` checks: an active
    source, the track available in the published generation with the same
    media fingerprint, and the current analyzer and schema versions. An
    anti-join, then one key lookup per unpublished row; the repair is in
    docs/runbooks/UPGRADE_1.3.md (repair D).
    Returns None before the publication table exists.
    """
    cur = db.cursor()
    try:
        cur.execute("SELECT to_regclass(%s)", (table("published_source_profiles"),))
        exists = cur.fetchone()
        if not exists or exists[0] is None:
            return None
        # Anti-join first (normally empty), then check currency by key.
        cur.execute(
            f"""
            WITH unpublished AS MATERIALIZED (
                SELECT s.catalog_instance_id, s.track_id, s.media_signature
                  FROM {source_profiles_table()} s
                 WHERE s.status='ready'
                   AND s.analyzer_ver=%s AND s.profile_schema_ver=%s
                   AND NOT EXISTS (
                       SELECT 1 FROM {table('published_source_profiles')} p
                        WHERE p.catalog_instance_id=s.catalog_instance_id
                          AND p.track_id=s.track_id
                   )
            )
            SELECT count(*)
              FROM unpublished s
              JOIN {table('catalog_sources')} src
                ON src.catalog_instance_id=s.catalog_instance_id
               AND src.rebind_status='active'
              JOIN {table('catalog_state')} c
                ON c.catalog_instance_id=s.catalog_instance_id
             CROSS JOIN LATERAL (
                   -- One key lookup per row (P3-7). As a plain join on the
                   -- source the planner compared every unpublished row with
                   -- every track: 1,000 rows took 20 s at 132k tracks.
                   SELECT 1 FROM {table('catalog_tracks')} t
                    WHERE t.catalog_instance_id=s.catalog_instance_id
                      AND t.published_generation=c.published_generation
                      AND t.track_id=s.track_id
                      AND t.available=TRUE AND COALESCE(t.media_fp, '') <> ''
                      AND s.media_signature='catalog-media:' || t.media_fp
                    LIMIT 1) t
            """,
            (ANALYZER_VERSION, SCHEMA_VERSION),
        )
        row = cur.fetchone()
        return int(row[0]) if row and row[0] is not None else None
    finally:
        cur.close()


def integrity_state_table():
    return table("integrity_state")


def refresh_integrity_snapshot(db):
    """Recount ``profiles_unpublished_ready`` and ``profiles_orphaned`` (AUD-05, P3-7).

    The anti-joins read every 'ready' and every published profile (together
    about 250 ms at 94k profiles and 132k tracks), so health never runs them:
    install, web-worker start and the publication repair refresh these rows
    and health reads them by primary key. Runs in the caller's transaction. Returns the
    unpublished-ready count.
    """
    from .profile_publication import orphaned_publication_count

    cur = db.cursor()
    try:
        cur.execute(
            f"""
            CREATE TABLE IF NOT EXISTS {integrity_state_table()} (
                name TEXT PRIMARY KEY,
                value BIGINT,
                checked_at TIMESTAMPTZ NOT NULL DEFAULT now()
            )
            """
        )
        count = profiles_unpublished_ready_count(db)
        orphaned = None if count is None else orphaned_publication_count(cur)
        cur.execute(
            f"""
            INSERT INTO {integrity_state_table()} (name, value, checked_at)
            VALUES ('profiles_unpublished_ready', %s, now()),
                   ('profiles_orphaned', %s, now())
            ON CONFLICT (name) DO UPDATE
               SET value=EXCLUDED.value, checked_at=EXCLUDED.checked_at
            """,
            (count, orphaned),
        )
        return count
    finally:
        cur.close()


def upgrade_fences_installed(cur):
    """True when every AUD-05 fence is in the schema (one catalogue lookup).

    ``profile_changes.writer_generation`` and ``catalog_changes.writer_generation``
    are NOT NULL without a default, and ``collection_changes.seq`` has no
    default. False means the 1.3.0 migration has not (fully) run, so 1.2.5
    workers are not fenced.
    """
    cur.execute(
        """
        SELECT
          (SELECT count(*) FROM pg_attribute
            WHERE attrelid IN (to_regclass(%s), to_regclass(%s))
              AND attname='writer_generation' AND attnotnull
              AND NOT atthasdef AND NOT attisdropped) = 2
          AND EXISTS (
            SELECT 1 FROM pg_attribute
             WHERE attrelid = to_regclass(%s) AND attname='seq'
               AND NOT atthasdef AND NOT attisdropped)
        """,
        (table("profile_changes"), table("catalog_changes"),
         table("collection_changes")),
    )
    row = cur.fetchone()
    return bool(row[0]) if row else None


def _persisted_profile_integrity(cur):
    """The persisted profile counts and when they were taken ({} before any)."""
    cur.execute("SELECT to_regclass(%s)", (integrity_state_table(),))
    if cur.fetchone()[0] is None:
        return {}
    cur.execute(
        f"SELECT name, value, checked_at FROM {integrity_state_table()} "
        "WHERE name IN ('profiles_unpublished_ready', 'profiles_orphaned')"
    )
    result = {}
    for name, value, checked_at in cur.fetchall():
        result[name] = int(value) if value is not None else None
        if name == "profiles_unpublished_ready":
            result["profiles_checked_at"] = (
                checked_at.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
                if checked_at is not None else None
            )
    return result


def edge_profiles_stored(db=None):
    """Health ``edge_profiles.stored``: whether any edge profile is stored.

    ``available``/``enabled`` describe this process's PyAV runtime and the
    setting; edges are computed by the analysis worker, so a web process
    without PyAV still serves them (``served``). ``stored`` answers whether
    profile transfers can carry edges at all: True when at least one edge row
    exists, False when none does, None when unknown (no database or an older
    schema). One ``LIMIT 1`` probe; never raises.
    """
    try:
        db = db or get_db()
    except Exception:
        db = None
    if db is None:
        return None
    try:
        cur = db.cursor()
        try:
            cur.execute(f"SELECT 1 FROM {table('edge_profiles')} LIMIT 1")
            return cur.fetchone() is not None
        finally:
            cur.close()
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis could not probe stored edge profiles")
        return None


def edge_profiles_capability():
    """Health ``capabilities.edge_profiles``.

    ``available``/``enabled`` describe the answering process; ``analyzable``
    whether queued edge jobs will be computed (a worker reported a qualified
    runtime); ``worker_runtime`` that report; ``server_backfill`` that the
    server walks the library itself; ``queue`` the job counts (null unknown).
    """
    worker_analyzable, worker = edge_worker_state()
    if not edge_setting_enabled():
        analyzable = False
    elif worker_analyzable or edge_runtime_available():
        analyzable = True
    else:
        analyzable = worker_analyzable
    try:
        queue = edge_queue_counts(get_db())
    except Exception:
        queue = None
        try:
            _rollback_if_possible(get_db())
        except Exception:
            pass
    return {"schema_version": EDGE_SCHEMA_VERSION, "method": EDGE_METHOD,
            "available": edge_runtime_available(), "enabled": edge_profiles_enabled(),
            "analyzable": analyzable, "worker_runtime": worker,
            "served": True, "stored": edge_profiles_stored(),
            "server_backfill": True, "edge_status": True, "deferred_requests": True,
            "queue": queue}


def integrity_status(db=None):
    """Health ``integrity``: fail-closed invariants of the 1.3.0 upgrade (AUD-05).

    ``collections_feed_ok`` is live: False when a collection change row sits
    past the feed head (collection writes then return 503
    ``collection_feed_invariant``). ``profiles_unpublished_ready`` and
    ``profiles_orphaned`` (P3-7: published profiles whose track the current
    catalogue generation lacks) are the counts persisted by the last install,
    web-worker start or publication repair, and ``profiles_checked_at`` is
    when they were taken. ``fences_installed`` is False
    until the 1.3.0 migration has installed every old-writer fence. Values are
    None when unknown. All reads are index or catalogue lookups.
    """
    from .collection_manager import collection_feed_integrity

    result = {
        "collections_feed_ok": None,
        "profiles_unpublished_ready": None,
        "profiles_orphaned": None,
        "profiles_checked_at": None,
        "fences_installed": None,
    }
    try:
        db = db or get_db()
    except Exception:
        db = None
    if db is None:
        return result
    try:
        cur = db.cursor()
        try:
            result["collections_feed_ok"] = collection_feed_integrity(cur)
            result["fences_installed"] = upgrade_fences_installed(cur)
            result.update(_persisted_profile_integrity(cur))
        finally:
            cur.close()
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not read upgrade integrity")
    return result


def log_integrity_on_start(db):
    """Refresh the persisted profile count and log any violated invariant."""
    try:
        refresh_integrity_snapshot(db)
        db.commit()
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not refresh upgrade integrity")
    status = integrity_status(db)
    _rollback_if_possible(db)
    if status["fences_installed"] is False:
        logger.error(
            "lumae_analysis 1.3.0 migration is incomplete: 1.2.5 writers are not "
            "fenced. Re-run the plugin install before starting RQ workers "
            "(docs/runbooks/UPGRADE_1.3.md)"
        )
    if status["collections_feed_ok"] is False:
        logger.error(
            "lumae_analysis collection feed invariant violated (MAX(seq) > head_seq); "
            "collection writes return 503 until repaired: docs/runbooks/UPGRADE_1.3.md"
        )
    if status["profiles_unpublished_ready"]:
        logger.warning(
            "lumae_analysis found %s ready source profiles without a published row; "
            "repair: docs/runbooks/UPGRADE_1.3.md",
            status["profiles_unpublished_ready"],
        )
    if status["profiles_orphaned"]:
        logger.warning(
            "lumae_analysis found %s published profiles whose tracks are no longer "
            "in the catalogue; the next catalogue refresh withdraws them, or repair: "
            "docs/runbooks/UPGRADE_1.3.md",
            status["profiles_orphaned"],
        )
    return status


def repair_profile_publications(db=None):
    """Repair D (P3-7): make the published profiles agree with the catalogue.

    For each active source, bounded per run: withdraw published profiles
    whose track the current catalogue generation lacks (delete events), and
    republish 'ready' profiles that have no published row (upsert events,
    through complete_attempt's checks). Each batch is a short transaction
    under the source's catalog_state row lock, so it is safe while analysis
    and catalogue refreshes run, and running it again changes nothing. Then
    recounts the persisted integrity counts, which health reports.
    """
    from .profile_publication import republish_ready_profiles, withdraw_orphaned_profiles

    db = db or get_db()
    cur = db.cursor()
    try:
        cur.execute(
            f"SELECT catalog_instance_id FROM {table('catalog_sources')} "
            "WHERE rebind_status='active' ORDER BY catalog_instance_id"
        )
        sources = [str(row[0]) for row in cur.fetchall()]
    finally:
        cur.close()
    db.commit()
    withdrawn = republished = 0
    for source in sources:
        withdrawn += len(withdraw_orphaned_profiles(db, source))
        republished += len(
            republish_ready_profiles(db, source, ANALYZER_VERSION, SCHEMA_VERSION)
        )
    try:
        refresh_integrity_snapshot(db)
        db.commit()
        cur = db.cursor()
        try:
            counts = _persisted_profile_integrity(cur)
        finally:
            cur.close()
        db.commit()
    except Exception:
        _rollback_if_possible(db)
        raise
    return {
        "withdrawn": withdrawn,
        "republished": republished,
        "profiles_unpublished_ready": counts.get("profiles_unpublished_ready"),
        "profiles_orphaned": counts.get("profiles_orphaned"),
    }


@bp.get("/api/health")
def health():
    compatibility = detect_core()
    return jsonify(
        {
            "plugin": "lumae_analysis",
            "plugin_version": PLUGIN_VERSION,
            "core_version": compatibility.core_version,
            "core_adapter": compatibility.adapter,
            "supported_core_range": SUPPORTED_CORE_RANGE,
            "sync_contract": sync_contract(compatibility),
            "schema_version": SCHEMA_VERSION,
            "analyzer_version": ANALYZER_VERSION,
            "capabilities": {
                "profile_bootstrap": {
                    "protocol_version": 2,
                    "schema_version": 1,
                    "auth": "host_authenticated",
                    "auth_enabled": _host_auth_enabled(),
                    "transfer_contract": profile_bootstrap.TRANSFER_CONTRACT,
                    "available": profile_bootstrap.availability(),
                    "sliding_expiry": True,
                    "idempotent_create": True,
                    "create_adoption": True,
                },
                "edge_profiles": edge_profiles_capability(),
                "personal_discovery": {"schema_version": 1, "enabled": collections_enabled(), "scope": health_scope_mode(), "features": ["album_memory_context", "enjoyment_feedback"]},
                "music_metadata": {"schema_version": 1, "enabled": not maintenance_paused(), "provider": "musicbrainz", "daily_request_limit": 80, "recording_membership": True},
                "shelves": {
                    "schema_version": SHELVES_SCHEMA_VERSION,
                    "enabled": collections_enabled(),
                    "scope": health_scope_mode(),
                },
                "vibes": vibes.capability(collections_enabled(), health_scope_mode()),
                "covers": covers.capability(collections_enabled(), health_scope_mode()),
                "collections": {
                    "schema_version": COLLECTIONS_SCHEMA_VERSION,
                    "backup_version": COLLECTIONS_BACKUP_VERSION,
                    "enabled": collections_enabled(),
                    "scope": health_scope_mode(),
                    "feed_epoch": True,
                    "contract": COLLECTIONS_CONTRACT,
                    "source_scoped_items": True,
                },
                "catalog_mirror": catalog_capability(),
                "credits": credits_service.capability(),
                "transport": {"gzip": True},
                "profile_stream": {"edge_refs": True},
                "analysis_vectors": {"generation_fallback": True, "missing": True, "strict_generation": True},
            },
            "integrity": integrity_status(),
            "status": "ok" if compatibility.supported else compatibility.status,
        }
    )


@bp.get("/api/catalog/health")
def catalog_health():
    compatibility = detect_core()
    db = None
    try:
        servers = sanitized_server_summaries(compatibility)
    except Exception as exc:
        logger.exception("lumae_analysis could not enumerate AudioMuse servers")
        payload = compatibility.as_dict()
        payload.update(
            {
                "plugin": "lumae_analysis",
                "plugin_version": PLUGIN_VERSION,
                "catalog_schema_version": CATALOG_SCHEMA_VERSION,
                "analysis_schema_version": ANALYSIS_SCHEMA_VERSION,
                "capability": catalog_capability(),
                "sync_contract": sync_contract(compatibility),
                "servers": [],
                "status": "server_discovery_failed",
                "reason": redact_stored_error(str(exc)),
            }
        )
        return jsonify(payload), 503

    persisted = []
    if compatibility.supported:
        try:
            db = get_db()
        except Exception:
            db = None
            logger.exception("lumae_analysis could not open catalogue health database")
        if db is not None:
            try:
                bridge = ProviderCatalogBridge()
                for candidate in bridge.list_servers():
                    if candidate.get("supported"):
                        # Pinged on every request, written only when the state
                        # or version changed (P2-1). An applied transition's
                        # AudioMuse health is refreshed by the
                        # provider_identity_recheck cron, not by this GET.
                        observation = observe_provider_version(
                            db,
                            bridge,
                            candidate["server_id"],
                            commit=False,
                            refresh_health=False,
                        )
                        if (observation or {}).get("written"):
                            # The route owns its transaction: a changed
                            # identity is durable before the next server or
                            # the readiness below is read.
                            db.commit()
            except Exception:
                _rollback_if_possible(db)
                logger.exception("lumae_analysis could not observe provider identity")
        try:
            if db is not None:
                persisted = resolve_catalog_source(db)
        except Exception:
            logger.exception("lumae_analysis could not read persisted catalogue health")
    if persisted:
        servers = persisted
        for server in servers:
            catalog_instance_id = server.get("catalog_instance_id")
            if not catalog_instance_id:
                continue
            try:
                state = preparation_state(catalog_instance_id, db=db)
                server["preparation"] = state
                if not preparation_attestation_is_current(state):
                    server["catalog"]["refresh_required"] = True
                    server["catalog"]["refresh_reason"] = "worker_version_mismatch"
            except Exception:
                logger.exception(
                    "lumae_analysis could not read catalogue preparation health"
                )
    servers = [
        {
            **server,
            "supported": str(server.get("provider_type") or "").strip().lower()
            in SUPPORTED_PROVIDER_TYPES,
            **(
                {"status": "provider_unsupported"}
                if str(server.get("provider_type") or "").strip().lower()
                not in SUPPORTED_PROVIDER_TYPES
                else {}
            ),
        }
        for server in servers
    ]
    policy = dedup_policy()
    if compatibility.adapter == "v3_registry":
        servers = [
            {
                **server,
                **(
                    {
                        "v3_readiness": v3_release_readiness(
                            db,
                            compatibility,
                            server,
                            policy,
                        )
                    }
                    if server["supported"]
                    else {}
                ),
            }
            for server in servers
        ]
    if db is not None:
        guarded_servers = []
        for server in servers:
            transition = None
            catalog_instance_id = server.get("catalog_instance_id")
            if catalog_instance_id:
                try:
                    transition = provider_transition_health(db, catalog_instance_id)
                except Exception:
                    logger.exception(
                        "lumae_analysis could not read provider transition health for %s",
                        catalog_instance_id,
                    )
            if transition:
                server = {
                    **server,
                    "provider_identity_transition": transition,
                    "catalog_sync_allowed": transition["catalog_sync_allowed"],
                    "analysis_sync_allowed": transition["analysis_sync_allowed"],
                    "audiomuse_projection_ingest_allowed": transition[
                        "audiomuse_projection_ingest_allowed"
                    ],
                    "provider_mutations_allowed": transition["provider_mutations_allowed"],
                    "audiomuse_health": transition.get("audiomuse_health"),
                }
                if not transition["catalog_sync_allowed"] and server.get("v3_readiness"):
                    readiness = dict(server["v3_readiness"])
                    readiness["ready"] = False
                    readiness["fully_verified"] = False
                    readiness["analysis_sync_allowed"] = False
                    readiness["blockers"] = list(
                        dict.fromkeys([*(readiness.get("blockers") or []), TRANSITION_BLOCKER])
                    )
                    admission = dict(readiness.get("admission") or {})
                    for stream in ("catalog", "analysis"):
                        stream_admission = dict(admission.get(stream) or {})
                        stream_admission["admitted"] = False
                        stream_admission["status"] = "denied"
                        stream_admission["blockers"] = list(
                            dict.fromkeys(
                                [*(stream_admission.get("blockers") or []), TRANSITION_BLOCKER]
                            )
                        )
                        admission[stream] = stream_admission
                    readiness["admission"] = admission
                    server["v3_readiness"] = readiness
            guarded_servers.append(server)
        servers = guarded_servers
    payload = compatibility.as_dict()
    payload.update(
        {
            "plugin": "lumae_analysis",
            "plugin_version": PLUGIN_VERSION,
            "catalog_schema_version": CATALOG_SCHEMA_VERSION,
            "analysis_schema_version": ANALYSIS_SCHEMA_VERSION,
            "catalog_builder_version": CATALOG_BUILDER_VERSION,
            "capability": catalog_capability(),
            "sync_contract": sync_contract(compatibility),
            "dedup_policy": policy,
            "servers": [redact_source_errors(server) for server in servers],
        }
    )
    response = jsonify(payload)
    response.headers["Cache-Control"] = "private, no-cache"
    response.headers["Vary"] = "Authorization, Cookie"
    return response, 200 if compatibility.supported else 409


def _catalog_principal_key():
    username = getattr(g, "auth_user", None)
    if username:
        return f"user:{username}"
    return f"client:{request.remote_addr or 'unknown'}"


def _private_json(payload, status=200, no_store=True):
    response = jsonify(payload)
    response.status_code = status
    response.headers["Cache-Control"] = "private, no-store" if no_store else "private, no-cache"
    response.headers["Vary"] = "Authorization, Cookie"
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


def _catalog_error(code, message, status):
    return _private_json({"error": code, "message": message}, status)


def _json_body(max_bytes=16_384):
    if request.content_length and request.content_length > max_bytes:
        raise ValueError("Request body is too large")
    body = request.get_json(silent=True)
    if body is None:
        return {}
    if not isinstance(body, dict):
        raise ValueError("JSON body must be an object")
    return body


def _preparation_api_payload(source, state=None):
    catalog = source.get("catalog") or {}
    analysis = source.get("analysis") or {}
    state = state if state is not None else preparation_state(source["catalog_instance_id"])
    catalog_ready = int(catalog.get("generation") or 0) > 0
    fingerprint_schema_version = int(
        catalog.get("fingerprint_schema_version", 1) or 1
    )
    fingerprint_current = (
        fingerprint_schema_version == CATALOG_FINGERPRINT_SCHEMA_VERSION
    )
    attestation_current = preparation_attestation_is_current(state)
    effective_refresh_required = (
        bool(catalog.get("refresh_required", False))
        or not fingerprint_current
        or not attestation_current
    )
    effective_refresh_reason = (
        "fingerprint_schema_rebase"
        if not fingerprint_current
        else (
            "worker_version_mismatch"
            if not attestation_current
            else catalog.get("refresh_reason")
        )
    )
    current = (
        catalog_ready
        and int(catalog.get("builder_version") or 0) >= CATALOG_BUILDER_VERSION
        and not effective_refresh_required
    )
    active = preparation_is_active(state)
    if active:
        status = state["status"]
        phase = state["phase"]
    elif current:
        status = "ready"
        phase = "ready"
    elif state and state.get("status") == "failed":
        status = "failed"
        phase = state.get("phase") or "failed"
    else:
        status = "required"
        phase = (
            effective_refresh_reason
            or ("analysis_projection" if catalog_ready else "catalog_refresh")
        )
    attestation_error = None
    if not attestation_current and not active:
        attestation_error = (
            "The catalogue worker did not attest the plugin version requested by the "
            "AudioMuse API. Restart AudioMuse workers; repair will retry automatically."
        )
    return {
        "operation_id": source["catalog_instance_id"],
        "status": status,
        "phase": phase,
        "server_id": source["server_id"],
        "catalog_instance_id": source["catalog_instance_id"],
        "catalog_ready": catalog_ready,
        "publication_current": current,
        "generation": int(catalog.get("generation") or 0),
        "counts": catalog.get("entity_counts") or {},
        "published_builder_version": int(catalog.get("builder_version") or 0),
        "current_builder_version": CATALOG_BUILDER_VERSION,
        "fingerprint_schema_version": fingerprint_schema_version,
        "current_fingerprint_schema_version": CATALOG_FINGERPRINT_SCHEMA_VERSION,
        "snapshot_estimated_bytes": int(
            catalog.get("snapshot_estimated_bytes", 0) or 0
        ),
        "last_scan_change_counts": catalog.get("last_scan_change_counts") or {},
        "last_scan_change_reason": catalog.get("last_scan_change_reason"),
        "last_scan_duration_ms": catalog.get("last_scan_duration_ms"),
        "refresh_required": effective_refresh_required,
        "refresh_reason": effective_refresh_reason,
        "analysis_ready": analysis.get("status") == "complete",
        "target_plugin_version": (state or {}).get("target_plugin_version"),
        "target_catalog_builder_version": (state or {}).get(
            "target_catalog_builder_version"
        ),
        "worker_plugin_version": (state or {}).get("worker_plugin_version"),
        "worker_catalog_builder_version": (state or {}).get(
            "worker_catalog_builder_version"
        ),
        "worker_attested": attestation_current,
        "last_error": redact_stored_error(
            (state or {}).get("last_error")
            or attestation_error
            or catalog.get("last_error")
        ),
        "updated_at": (state or {}).get("updated_at"),
    }


def _resolve_preparation_source(body):
    sources = resolve_catalog_source(
        get_db(),
        server_id=body.get("server_id"),
        catalog_instance_id=body.get("catalog_instance_id"),
    )
    if len(sources) != 1:
        raise ValueError(
            "An explicit server_id is required when multiple music servers are configured."
        )
    source = sources[0]
    if source.get("rebind_status") != "active":
        raise CatalogScanError(
            "AudioMuse was upgraded; confirm source continuity before preparing Lumae."
        )
    return source


@bp.post("/api/catalog/prepare")
def catalog_prepare_api():
    try:
        body = _json_body()
        source = _resolve_preparation_source(body)
        initial = _preparation_api_payload(source)
        if initial["publication_current"]:
            return _private_json(initial, 200)
        if not preparation_is_active(preparation_state(source["catalog_instance_id"])):
            if claim_preparation(source):
                try:
                    enqueue_bounded(
                        prepare_lumae_task,
                        source["server_id"],
                        source["catalog_instance_id"],
                        queue="default",
                        timeout=CATALOG_JOB_TIMEOUT_SECONDS,
                    )
                except Exception:
                    logger.exception(
                        "lumae_analysis could not queue catalogue preparation; "
                        "the durable watchdog will retry it"
                    )
        payload = _preparation_api_payload(
            source, preparation_state(source["catalog_instance_id"])
        )
        response = _private_json(payload, 202)
        response.headers["Retry-After"] = "2"
        response.headers["Location"] = (
            f"/plugins/lumae_analysis/api/catalog/prepare/{source['catalog_instance_id']}"
        )
        return response
    except KeyError:
        return _catalog_error("source_not_found", "Catalogue source was not found.", 404)
    except CatalogScanError as exc:
        return _catalog_error("preparation_blocked", str(exc), 409)
    except ValueError as exc:
        return _catalog_error("invalid_preparation", str(exc), 400)
    except Exception:
        logger.exception("lumae_analysis could not queue catalogue preparation")
        return _catalog_error(
            "preparation_queue_failed",
            "Catalogue preparation could not be queued. Try again in a moment.",
            503,
        )


@bp.get("/api/catalog/prepare/<operation_id>")
def catalog_prepare_status_api(operation_id):
    try:
        sources = resolve_catalog_source(get_db(), catalog_instance_id=operation_id)
        if len(sources) != 1:
            raise KeyError("Unknown catalogue source")
        source = sources[0]
        payload = _preparation_api_payload(
            source, preparation_state(source["catalog_instance_id"])
        )
        response = _private_json(payload, 200, no_store=False)
        if payload["status"] in ("queued", "running"):
            response.headers["Retry-After"] = "2"
        return response
    except KeyError:
        return _catalog_error("source_not_found", "Catalogue source was not found.", 404)


@bp.post("/api/catalog/refresh")
def catalog_refresh_api():
    try:
        body = _json_body()
        server_id = body.get("server_id")
        catalog_instance_id = body.get("catalog_instance_id")
        sources = resolve_catalog_source(
            get_db(), server_id=server_id, catalog_instance_id=catalog_instance_id
        )
        if len(sources) != 1:
            return _catalog_error(
                "source_required",
                "An explicit server_id is required when multiple music servers are configured.",
                409,
            )
        source = sources[0]
        if catalog_instance_id and source["catalog_instance_id"] != catalog_instance_id:
            return _catalog_error("source_mismatch", "Catalogue source identity changed.", 409)
        if source.get("rebind_status") != "active":
            return _catalog_error(
                "rebind_required",
                "AudioMuse was upgraded; confirm source continuity before refreshing.",
                409,
            )
        stale_for = max(0, min(int(body.get("if_stale_for_seconds", 0) or 0), 604_800))
        completed_at = source["catalog"].get("completed_at")
        if stale_for and completed_at and source["catalog"]["status"] == "complete":
            try:
                completed = datetime.fromisoformat(completed_at.replace("Z", "+00:00"))
                age = (datetime.now(timezone.utc) - completed).total_seconds()
                if age < stale_for:
                    return _private_json(
                        {
                            "status": "fresh",
                            "server_id": source["server_id"],
                            "catalog_instance_id": source["catalog_instance_id"],
                            "generation": source["catalog"]["generation"],
                        },
                        200,
                    )
            except ValueError:
                pass
        enqueue_bounded(
            catalog_refresh_task,
            source["server_id"],
            queue="default",
            timeout=CATALOG_JOB_TIMEOUT_SECONDS,
        )
        return _private_json(
            {
                "status": "queued",
                "server_id": source["server_id"],
                "catalog_instance_id": source["catalog_instance_id"],
            },
            202,
        )
    except (KeyError, ValueError, CatalogScanError) as exc:
        return _catalog_error("invalid_refresh", str(exc), 400)


@bp.post("/api/catalog/rebind")
def catalog_rebind_api():
    """Prove and accept an exact v2-to-v3 source continuity match."""
    try:
        body = _json_body()
        catalog_instance_id = str(body.get("catalog_instance_id") or "").strip()
        server_id = str(body.get("server_id") or "").strip()
        if not catalog_instance_id or not server_id:
            return _catalog_error(
                "identity_required", "Catalogue instance and candidate server are required.", 400
            )
        result = attempt_legacy_rebind(get_db(), catalog_instance_id, server_id)
        if result["status"] != "active":
            return _catalog_error(
                "continuity_not_proven",
                "The v3 provider catalogue does not exactly match the stored v2 source.",
                409,
            )
        return _private_json(result)
    except KeyError:
        return _catalog_error("source_not_found", "Catalogue source was not found.", 404)
    except (ValueError, CatalogScanError) as exc:
        return _catalog_error("invalid_rebind", str(exc), 409)


@bp.post("/api/catalog/verify-scope")
def catalog_verify_scope_api():
    try:
        body = _json_body()
        catalog_instance_id = str(body.get("catalog_instance_id") or "").strip()
        if not catalog_instance_id:
            return _catalog_error("identity_required", "Catalogue instance is required.", 400)
        result = verify_library_scope(
            get_db(),
            catalog_instance_id,
            body.get("library_ids"),
            body.get("provider_track_ids") if "provider_track_ids" in body else None,
        )
        return _private_json(result)
    except KeyError:
        return _catalog_error("source_not_found", "Catalogue source was not found.", 404)
    except ValueError as exc:
        return _catalog_error("invalid_scope", str(exc), 400)


@bp.post("/api/catalog/bootstrap-sessions")
def catalog_bootstrap_session_api():
    try:
        body = _json_body()
        result = create_bootstrap_session(
            get_db(),
            _catalog_principal_key(),
            stream=str(body.get("stream") or "catalog"),
            server_id=body.get("server_id"),
            catalog_instance_id=body.get("catalog_instance_id"),
        )
        return _private_json(result, 201)
    except KeyError:
        return _catalog_error("source_not_found", "Catalogue source was not found.", 404)
    except (ValueError, CatalogScanError) as exc:
        return _catalog_error("bootstrap_unavailable", str(exc), 409)


@bp.delete("/api/catalog/bootstrap-sessions")
def catalog_bootstrap_release_api():
    token = request.headers.get("X-Lumae-Bootstrap-Token")
    if not token:
        return _catalog_error("token_required", "Bootstrap token header is required.", 400)
    released = release_bootstrap_session(get_db(), token, _catalog_principal_key())
    return _private_json({"released": released})


@bp.get("/api/catalog/bootstrap")
def catalog_bootstrap_api():
    token = request.headers.get("X-Lumae-Bootstrap-Token")
    if not token:
        return _catalog_error("token_required", "Bootstrap token header is required.", 400)
    try:
        result = bootstrap_page(
            get_db(),
            token,
            _catalog_principal_key(),
            stream=str(request.args.get("stream") or "catalog"),
            page_token=request.args.get("page_token"),
            limit=request.args.get("limit", 500),
        )
        return _private_json(result)
    except KeyError:
        return _catalog_error(
            "bootstrap_required", "Bootstrap lease expired or was released.", 410
        )
    except ValueError as exc:
        return _catalog_error("invalid_page", str(exc), 400)


@bp.get("/api/catalog/changes")
def catalog_changes_api():
    cursor = request.args.get("cursor")
    if not cursor:
        return _catalog_error("cursor_required", "Catalogue cursor is required.", 400)
    try:
        result = read_catalog_changes(
            get_db(),
            cursor,
            server_id=request.args.get("server_id"),
            catalog_instance_id=request.args.get("catalog_instance_id"),
            limit=request.args.get("limit", 500),
        )
        return _private_json(result, no_store=False)
    except KeyError:
        return _catalog_error(
            "bootstrap_required", "Catalogue cursor expired or belongs to an old epoch.", 410
        )
    except ValueError as exc:
        return _catalog_error("invalid_cursor", str(exc), 400)


@bp.get("/api/catalog/provider-identity/manifest")
def provider_identity_manifest_api():
    try:
        manifest = read_transition_manifest(
            get_db(),
            transition_id=request.args.get("transition_id"),
            catalog_instance_id=request.args.get("catalog_instance_id"),
        )
    except KeyError:
        return _catalog_error(
            "transition_manifest_not_found",
            "No retained provider identity manifest was found.",
            404,
        )
    except ValueError as exc:
        return _catalog_error("identity_required", str(exc), 400)
    payload = json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2)
    response = Response(payload, mimetype="application/json")
    response.headers["Content-Disposition"] = (
        f'attachment; filename="lumae-provider-rekey-{manifest["transition_id"]}.json"'
    )
    response.headers["Cache-Control"] = "private, no-store"
    response.headers["Vary"] = "Authorization, Cookie"
    return response


@bp.get("/api/catalog/analysis/changes")
def analysis_changes_api():
    cursor = request.args.get("cursor")
    if not cursor:
        return _catalog_error("cursor_required", "Analysis cursor is required.", 400)
    try:
        result = read_analysis_changes(
            get_db(),
            cursor,
            server_id=request.args.get("server_id"),
            catalog_instance_id=request.args.get("catalog_instance_id"),
            limit=request.args.get("limit", 500),
        )
        return _private_json(result, no_store=False)
    except KeyError:
        return _catalog_error(
            "bootstrap_required", "Analysis cursor expired or belongs to an old epoch.", 410
        )
    except ValueError as exc:
        return _catalog_error("invalid_cursor", str(exc), 400)


@bp.post("/api/catalog/analysis/scalars")
def analysis_scalars_api():
    try:
        body = _json_body(max_bytes=64_000)
        catalog_instance_id = str(body.get("catalog_instance_id") or "")
        ids = body.get("provider_track_ids") or []
        if not catalog_instance_id or not isinstance(ids, list):
            raise ValueError("catalog_instance_id and provider_track_ids are required")
        return _private_json(
            {
                "catalog_instance_id": catalog_instance_id,
                "items": scalar_batch(get_db(), catalog_instance_id, ids),
            }
        )
    except (KeyError, ValueError) as exc:
        return _catalog_error("invalid_batch", str(exc), 400)


@bp.post("/api/catalog/analysis/vectors")
def analysis_vectors_api():
    try:
        body = _json_body(max_bytes=64_000)
        catalog_instance_id = str(body.get("catalog_instance_id") or "")
        ids = body.get("analysis_ids") or []
        family = str(body.get("family") or "musicnn")
        generation = body.get("generation")
        strict_generation = body.get("strict_generation") is True
        if not catalog_instance_id or not isinstance(ids, list):
            raise ValueError("catalog_instance_id and analysis_ids are required")
        payload = vector_batch(
            get_db(), catalog_instance_id, ids, family=family, generation=generation,
            strict_generation=strict_generation,
        )
        response = Response(payload, mimetype="application/vnd.lumae.f32le-v1")
        response.headers["Cache-Control"] = "private, no-store"
        response.headers["Vary"] = "Authorization, Cookie"
        response.headers["X-Content-Type-Options"] = "nosniff"
        return response
    except GenerationExpired as exc:
        return _private_json(
            {
                "error": "generation_expired",
                "message": str(exc),
                "requested_generation": exc.requested_generation,
                "current_generation": exc.current_generation,
            },
            410,
        )
    except (KeyError, ValueError, CatalogScanError) as exc:
        return _catalog_error("invalid_batch", str(exc), 400)


@bp.get("/api/profiles")
def profiles():
    try:
        source = resolve_profile_source(
            catalog_instance_id=request.args.get("catalog_instance_id")
        )
    except (KeyError, ValueError, CatalogScanError) as exc:
        return _catalog_error("source_required", str(exc), 409)
    ids = parse_ids(request.args.get("ids", ""))
    source_id = source["catalog_instance_id"]
    published = {
        row["track_id"]: row
        for row in fetch_published_profile_rows(ids, source_id)
    }
    attempts = {
        row["track_id"]: row
        for row in fetch_profile_rows(ids, catalog_instance_id=source_id)
    }
    ready = []
    failed = []
    missing = []
    for track_id in ids:
        row = published.get(track_id)
        if row is not None:
            try:
                ready.append(serialize_ready_profile(row))
            except Exception as exc:
                failed.append({"track_id": track_id, "reason": str(exc)})
        elif attempts.get(track_id, {}).get("status") in ("failed", "skipped_no_file"):
            failed.append({
                "track_id": track_id,
                "reason": public_failure_reason(attempts[track_id].get("last_error")) or "failed",
            })
        else:
            missing.append(track_id)
    body = {
        "schema_version": SCHEMA_VERSION,
        "analyzer_version": ANALYZER_VERSION,
        "catalog_instance_id": source["catalog_instance_id"],
        "profiles": ready,
        "missing": missing,
        "failed": failed,
    }
    if str(request.args.get("edge_status") or "").strip().lower() in ("1", "true"):
        # Opt-in (capabilities.edge_profiles.edge_status): without it the
        # response is unchanged.
        body["edge_status"] = edge_statuses(get_db(), source_id, ids)
    return _private_json(body)


@bp.get("/api/profiles/bootstrap")
def profiles_bootstrap_api():
    try:
        catalog_instance_id = str(request.args.get("catalog_instance_id") or "")
        if not catalog_instance_id:
            raise ValueError("catalog_instance_id is required")
        return _private_json(
            profile_bootstrap_page(
                get_db(),
                catalog_instance_id,
                page_token=request.args.get("page_token"),
                limit=request.args.get("limit", 250),
            ),
            no_store=False,
        )
    except KeyError:
        return _catalog_error(
            "bootstrap_required", "Profile bootstrap cursor expired.", 410
        )
    except (CatalogScanError, ValueError) as exc:
        return _catalog_error("invalid_profile_bootstrap", str(exc), 400)


def _edge_refs_requested():
    """K6 (P3-2): ``edge_refs=1`` (or ``true``) on a profile stream route.

    Any other value, or none, keeps the default: every edge in full.
    """
    return str(request.args.get("edge_refs") or "").strip().lower() in ("1", "true")


@bp.get("/api/profiles/changes")
def profile_changes_api():
    cursor = request.args.get("cursor")
    if not cursor:
        return _catalog_error("cursor_required", "Profile cursor is required.", 400)
    try:
        return _private_json(
            read_profile_changes(
                get_db(),
                cursor,
                catalog_instance_id=request.args.get("catalog_instance_id"),
                limit=request.args.get("limit", 250),
                edge_refs=_edge_refs_requested(),
            ),
            no_store=False,
        )
    except KeyError:
        return _catalog_error(
            "bootstrap_required", "Profile cursor expired or belongs to an old epoch.", 410
        )
    except (CatalogScanError, ValueError) as exc:
        return _catalog_error("invalid_cursor", str(exc), 400)


def _host_auth_enabled():
    """The host's live AUTH_ENABLED (K4); health ``auth`` stays the design string."""
    value = getattr(host_api.config, "AUTH_ENABLED", False)
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    return bool(value)


def _bootstrap_caller():
    """Who a v2 create counts against for the per-source rate limit."""
    username = getattr(g, "auth_user", None)
    if username:
        return f"user:{username}"
    if getattr(g, "auth_method", None) == "bearer":
        return "bearer"
    return profile_bootstrap.ANONYMOUS_CALLER


V2_BODY_MAX_BYTES = 16_384


def _v2_body(max_bytes=V2_BODY_MAX_BYTES):
    """The v2 JSON body, reading at most ``max_bytes`` + 1 bytes from the stream.

    ``Content-Length`` is checked first; a chunked body has none, so the read
    itself is bounded too. Non-JSON content types read as an empty body, like
    ``request.get_json(silent=True)``.
    """
    if request.content_length is not None and request.content_length > max_bytes:
        raise ValueError("Request body is too large")
    # A host hook may already have read (and cached) the body.
    raw = getattr(request, "_cached_data", None)
    if raw is None:
        # Read until EOF or one byte past the cap: a stream may return short reads.
        chunks, size = [], 0
        while size <= max_bytes:
            chunk = request.stream.read(max_bytes + 1 - size)
            if not chunk:
                break
            chunks.append(chunk)
            size += len(chunk)
        raw = b"".join(chunks)
    if len(raw) > max_bytes:
        raise ValueError("Request body is too large")
    if not request.is_json or not raw:
        return {}
    try:
        body = json.loads(raw)
    except ValueError:
        return {}
    if body is None:
        return {}
    if not isinstance(body, dict):
        raise ValueError("JSON body must be an object")
    return body


def _bootstrap_error(code, message, status, retry_after=None):
    response = _catalog_error(code, message, status)
    if status == 503:
        retry_after = retry_after or profile_bootstrap.UNAVAILABLE_RETRY_AFTER_S
    if status in (429, 503) and retry_after:
        response.headers["Retry-After"] = str(int(retry_after))
    return response


def _profile_bootstrap_v2(operation, **options):
    if not getattr(host_api.config, "DATABASE_URL", None):
        return _bootstrap_error("bootstrap_unavailable", "bootstrap_unavailable", 503)
    try:
        body = _v2_body()
    except ValueError:
        return _bootstrap_error("invalid_profile_bootstrap", "Invalid bootstrap request.", 400)
    try:
        result = operation(body, **options)
        return _private_json(result)
    except profile_bootstrap.BootstrapError as exc:
        return _bootstrap_error(exc.code, exc.code, exc.status, exc.retry_after)
    except Exception as exc:
        logger.exception("lumae_analysis profile bootstrap route failed (%s)", type(exc).__name__)
        return _bootstrap_error("bootstrap_unavailable", "bootstrap_unavailable", 503)


@bp.post("/api/profiles/bootstrap/sessions")
def profile_bootstrap_sessions_api():
    return _profile_bootstrap_v2(profile_bootstrap.create_session, caller=_bootstrap_caller())


@bp.post("/api/profiles/bootstrap/sessions/page")
def profile_bootstrap_sessions_page_api():
    return _profile_bootstrap_v2(profile_bootstrap.snapshot_page)


@bp.post("/api/profiles/bootstrap/sessions/catchup")
def profile_bootstrap_sessions_catchup_api():
    return _profile_bootstrap_v2(profile_bootstrap.catchup_page)


@bp.post("/api/profiles/bootstrap/sessions/release")
def profile_bootstrap_sessions_release_api():
    return _profile_bootstrap_v2(profile_bootstrap.release_session)


@bp.post("/api/catalog/relationships/prepare")
def relationships_prepare_api():
    try:
        body = _json_body(max_bytes=16_000)
        source = resolve_profile_source(
            catalog_instance_id=body.get("catalog_instance_id"),
            server_id=body.get("server_id"),
        )
        result = start_relationship_preparation(
            catalog_instance_id=source["catalog_instance_id"],
            server_id=source["server_id"],
        )
        return _private_json(
            {
                **result,
                "relationships": relationship_status(
                    get_db(), source["catalog_instance_id"]
                ),
            }
        )
    except (CatalogScanError, KeyError, ValueError) as exc:
        return _catalog_error("source_required", str(exc), 409)


@bp.get("/api/catalog/relationships/status")
def relationships_status_api():
    try:
        catalog_instance_id = str(request.args.get("catalog_instance_id") or "")
        if not catalog_instance_id:
            raise ValueError("catalog_instance_id is required")
        return _private_json(relationship_status(get_db(), catalog_instance_id))
    except (CatalogScanError, KeyError, ValueError) as exc:
        return _catalog_error("source_required", str(exc), 409)


@bp.get("/api/catalog/relationships/bootstrap")
def relationships_bootstrap_api():
    try:
        catalog_instance_id = str(request.args.get("catalog_instance_id") or "")
        if not catalog_instance_id:
            raise ValueError("catalog_instance_id is required")
        return _private_json(
            relationship_bootstrap_page(
                get_db(),
                catalog_instance_id,
                page_token=request.args.get("page_token"),
                limit=request.args.get("limit", 100),
            ),
            no_store=False,
        )
    except KeyError:
        return _catalog_error(
            "bootstrap_required", "Relationship bootstrap cursor expired.", 410
        )
    except (CatalogScanError, ValueError) as exc:
        return _catalog_error("invalid_relationship_bootstrap", str(exc), 400)


@bp.get("/api/catalog/relationships/changes")
def relationship_changes_api():
    cursor = request.args.get("cursor")
    if not cursor:
        return _catalog_error(
            "cursor_required", "Relationship cursor is required.", 400
        )
    try:
        return _private_json(
            read_relationship_changes(
                get_db(),
                cursor,
                catalog_instance_id=request.args.get("catalog_instance_id"),
                limit=request.args.get("limit", 250),
            ),
            no_store=False,
        )
    except KeyError:
        return _catalog_error(
            "bootstrap_required",
            "Relationship cursor expired or belongs to an old epoch.",
            410,
        )
    except (CatalogScanError, ValueError) as exc:
        return _catalog_error("invalid_cursor", str(exc), 400)


@bp.post("/api/analyze")
def analyze():
    if maintenance_paused():
        return _catalog_error(
            "maintenance_paused",
            "Lumae background analysis is paused by the administrator.",
            503,
        )
    body = request.get_json(silent=True) or {}
    try:
        source = resolve_profile_source(catalog_instance_id=body.get("catalog_instance_id"))
    except (KeyError, ValueError, CatalogScanError) as exc:
        return _catalog_error("source_required", str(exc), 409)
    ids = parse_ids(",".join(body.get("ids", [])))[:MAX_INTERACTIVE_PROFILE_IDS]
    catalog_instance_id = source["catalog_instance_id"]
    server_id = source["server_id"]
    accepted, already_ready, already_pending = split_analyze_ids(
        ids, catalog_instance_id=catalog_instance_id
    )
    # A library catch-up may already have marked these rows pending on the
    # default queue. Re-enqueue them in tiny high-priority chunks so current
    # playback is never trapped behind an hours-long library backfill. The
    # default task re-checks readiness before each track and becomes a no-op.
    interactive_ids = accepted + already_pending
    deferred = []
    for start in range(0, len(interactive_ids), INTERACTIVE_PROFILE_CHUNK_SIZE):
        chunk = interactive_ids[start : start + INTERACTIVE_PROFILE_CHUNK_SIZE]
        if enqueue_profile_analysis(
            chunk,
            catalog_instance_id,
            server_id,
            priority="interactive",
        ) == DEFERRED:
            deferred.extend(chunk)
    return jsonify(
        {
            "accepted": [track_id for track_id in accepted if track_id not in deferred],
            "already_ready": already_ready,
            "already_pending": already_pending,
            "deferred": deferred,
        }
    ), 202


def edge_setting_enabled():
    return str(get_setting("edge_profiles_enabled", "true")).lower() in ("true", "1", "yes")


def edge_profiles_enabled():
    """This process can compute edges: the setting is on and its runtime qualifies."""
    return edge_setting_enabled() and edge_runtime_available()


def edge_worker_state(db=None):
    """``(analyzable, status)`` from the workers' runtime reports; never raises."""
    try:
        db = db or get_db()
    except Exception:
        db = None
    if db is None:
        return None, None
    try:
        return edge_worker_runtime(db)
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis could not read the edge worker runtime")
        return None, None


def edge_profiles_analyzable(db=None):
    """Health ``edge_profiles.analyzable``: edge jobs queued now will be computed.

    False when the setting is off. Otherwise True when this process or a
    worker that reported within the freshness window has a qualified runtime,
    False when fresh reports all lack one, None when no worker reported.
    """
    if not edge_setting_enabled():
        return False
    analyzable, _status = edge_worker_state(db)
    if analyzable or edge_runtime_available():
        return True
    return analyzable


def edge_scheduling_allowed():
    return not maintenance_paused() and edge_profiles_analyzable() is True


# A worker re-reports its edge runtime at most this often; health treats a
# report as fresh for edge_profile_store.EDGE_RUNTIME_FRESH_HOURS.
EDGE_RUNTIME_REPORT_SECONDS = 600
_edge_runtime_reported_at = None


def report_edge_runtime(force=False):
    """Record this worker's edge runtime verdict; worker processes only.

    Called at worker start, by every edge task and by the reconcile tick. A
    qualified worker creates missing pass rows and resumes parked passes, and
    when either happened wakes the reconcile watchdog, so a fresh install or
    upgrade starts the library pass within a minute instead of at the next
    idle (hourly) tick. A worker without a qualified runtime parks due passes
    so the watchdog can go idle.
    """
    global _edge_runtime_reported_at
    now = time.monotonic()
    if (not force and _edge_runtime_reported_at is not None
            and now - _edge_runtime_reported_at < EDGE_RUNTIME_REPORT_SECONDS):
        return
    db = None
    try:
        db = get_db()
        status = edge_runtime_status()
        record_edge_runtime(db, socket.gethostname(), status)
        if status.get("available") and edge_setting_enabled():
            if ensure_edge_backfill_sources(db) + arm_edge_backfill(db, include_complete=False):
                arm_reconcile(db, "edge_backfill_ready", commit=True)
        else:
            park_edge_backfill(db)
        _edge_runtime_reported_at = now
    except Exception:
        if db is not None:
            _rollback_if_possible(db)
        logger.warning("lumae_analysis could not report the edge runtime")


def report_edge_runtime_on_start():
    report_edge_runtime(force=True)


# AudioMuse refuses a new root task from the web process while any plugin
# task or AudioMuse main job runs (``ERR_TASK_IN_PROGRESS``). On-demand work
# refused that way stays pending with this marker, and the next worker task
# serves it (serve_deferred_interactive).
HOST_BUSY_ERROR_CODE = 1201
DEFERRED = "deferred"
# A queued background edge batch yields its slot after this long; its
# unstarted jobs are released and due again at once.
EDGE_BACKGROUND_BUDGET_SECONDS = 60
# One library-pass tick analyses edges for about this long, one track at a
# time, serving on-demand work between tracks.
EDGE_BACKFILL_TICK_SECONDS = 30
EDGE_BACKFILL_TICK_MAX_TRACKS = 25


def host_queue_busy(exc):
    """The host refused a root task because another one is running."""
    return getattr(exc, "code", None) == HOST_BUSY_ERROR_CODE


def enqueue_edge_profiles(ids, catalog_instance_id, server_id, *, priority="background"):
    empty = {"available": False, "accepted": [], "already_ready": [], "already_pending": [],
             "unsupported": [], "deferred": []}
    if not edge_scheduling_allowed():
        return empty
    db = get_db()
    jobs, ready, pending, unsupported = claim_edge_requests(db, catalog_instance_id, ids, priority)
    deferred = []
    if jobs:
        try:
            # AudioMuse admits one root task per plugin. Submit the bounded
            # source-bound batch as one task; per-track tasks would make the
            # second item contend with the first and strand its durable job.
            enqueue_bounded(analyze_edges_task, jobs, catalog_instance_id, server_id, priority,
                            queue="high" if priority == "interactive" else "default",
                            timeout=PROFILE_JOB_TIMEOUT_SECONDS)
        except Exception as exc:
            if not host_queue_busy(exc):
                for job in jobs:
                    update_edge_job(get_db(), catalog_instance_id, job, "failed", "edge-enqueue-failed")
                raise
            if priority == "interactive":
                mark_edge_jobs_deferred(get_db(), catalog_instance_id, jobs, DEFERRED_MARKER)
                _wake_for_deferred()
            else:
                # Due again at once; the library pass also covers them.
                for job in jobs:
                    update_edge_job(get_db(), catalog_instance_id, job, "failed", "edge-enqueue-failed")
            deferred = [job["track_id"] for job in jobs]
    waiting = set(pending) | set(deferred)
    return {"available": True,
            "accepted": [job["track_id"] for job in jobs if job["track_id"] not in waiting],
            "already_ready": ready, "already_pending": pending, "unsupported": unsupported,
            "deferred": deferred}


def _schedule_edge_upgrade(track_id, catalog_instance_id, server_id, priority="background"):
    if not catalog_instance_id or not edge_profiles_enabled():
        return
    try:
        enqueue_edge_profiles([track_id], catalog_instance_id, server_id, priority=priority)
    except Exception:
        rollback = getattr(get_db(), "rollback", None)
        if callable(rollback):
            rollback()
        logger.warning("lumae_analysis optional edge upgrade could not be scheduled")


@bp.post("/api/profiles/edges/analyze")
def edge_analyze_api():
    try:
        body = _json_body(max_bytes=64000)
        source = resolve_profile_source(catalog_instance_id=body.get("catalog_instance_id"))
        ids = body.get("ids")
        if not isinstance(ids, list) or len(ids) > 100 or any(not isinstance(i, str) or not 0 < len(i) <= 512 for i in ids):
            raise ValueError("ids must contain at most 100 track IDs")
        return _private_json(enqueue_edge_profiles(ids, source["catalog_instance_id"], source["server_id"], priority="interactive")), 202
    except (KeyError, ValueError, CatalogScanError) as exc:
        return _catalog_error("invalid_edge_request", str(exc), 400)


@bp.post("/api/profiles/edges/backfill")
def edge_backfill_api():
    """Compatibility: the server walks the library itself (``server_backfill``)."""
    try:
        body = _json_body(max_bytes=64000)
        source = resolve_profile_source(catalog_instance_id=body.get("catalog_instance_id"))
        after = body.get("after", "")
        if not isinstance(after, str) or len(after) > 512:
            raise ValueError("invalid backfill cursor")
        limit = body.get("limit", 100)
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100:
            raise ValueError("limit must be an integer from 1 to 100")
        ids = edge_backfill_candidates(get_db(), source["catalog_instance_id"], after, limit)
        result = enqueue_edge_profiles(ids, source["catalog_instance_id"], source["server_id"])
        result["next_after"] = ids[-1] if ids else None
        return _private_json(result), 202
    except (KeyError, ValueError, CatalogScanError) as exc:
        return _catalog_error("invalid_edge_request", str(exc), 400)


def analyze_edges_task(jobs, catalog_instance_id, server_id, priority="background",
                       budget_seconds=EDGE_BACKGROUND_BUDGET_SECONDS):
    """Compute edges for claimed jobs, one file at a time.

    A background batch serves refused on-demand work before each track and
    releases its unstarted jobs once ``budget_seconds`` have passed (None: no
    budget), so it never holds the plugin's task slot for long.
    """
    report_edge_runtime()
    outcomes = []
    background = priority != "interactive"
    deadline = time.monotonic() + budget_seconds if background and budget_seconds else None
    jobs = list(jobs)[:100]
    for index, job in enumerate(jobs):
        if background:
            serve_deferred_interactive()
            if deadline is not None and time.monotonic() > deadline:
                for rest in jobs[index:]:
                    update_edge_job(get_db(), catalog_instance_id, rest, "failed", "edge-enqueue-failed")
                    outcomes.append({"track_id": rest["track_id"], "status": "released"})
                break
        if not update_edge_job(get_db(), catalog_instance_id, job, "running"):
            continue
        info = None
        try:
            if maintenance_paused() or not edge_profiles_enabled():
                raise ValueError("edge-worker-unavailable")
            info = load_track_file(job["track_id"], catalog_instance_id=catalog_instance_id, server_id=server_id)
            if not info or opaque_revision(info.get("media_signature")) != job["media_revision"]:
                raise ValueError("edge-source-replaced")
            payload = run_file_analysis(analyze_edge_file, info["file_path"],
                                        catalog_instance_id=catalog_instance_id,
                                        track_id=job["track_id"], media_revision=job["media_revision"])
            applied = publish_edge_profile(get_db(), catalog_instance_id, job, payload, info["media_signature"])
            if not applied:
                update_edge_job(get_db(), catalog_instance_id, job, "failed", "edge-source-replaced")
            outcomes.append({"track_id": job["track_id"], "status": "ready" if applied else "superseded"})
        except Exception as exc:
            rollback = getattr(get_db(), "rollback", None)
            if callable(rollback):
                rollback()
            if is_unsupported_failure(exc):
                # Terminal for this media revision: never retried until it changes.
                update_edge_job(get_db(), catalog_instance_id, job, EDGE_UNSUPPORTED,
                                analysis_isolation.edge_failure_reason(exc))
                outcomes.append({"track_id": job["track_id"], "status": EDGE_UNSUPPORTED})
            else:
                update_edge_job(get_db(), catalog_instance_id, job, "failed",
                                analysis_isolation.edge_failure_reason(exc))
                outcomes.append({"track_id": job["track_id"], "status": "failed"})
        finally:
            if info:
                remove_downloaded_file(info.get("cleanup_path"))
    return outcomes


def edge_backfill_task(server_id, catalog_instance_id):
    """One library-pass tick: edges for a few published tracks, then yield.

    Runs inside the reconcile tick after the waveform backfill. Analyses one
    track at a time for about EDGE_BACKFILL_TICK_SECONDS, serving on-demand
    work between tracks, and keeps its cursor at the last track it reached.
    """
    if maintenance_paused():
        return {"status": "paused", "processed": 0}
    db = get_db()
    if not edge_profiles_enabled():
        park_edge_backfill(db)
        return {"status": "paused", "reason": "edge_runtime_unavailable", "processed": 0}
    row = edge_backfill_row(db, catalog_instance_id) or {}
    cursor = row.get("cursor") or ""
    started = not cursor
    try:
        ids = edge_backfill_candidates(db, catalog_instance_id, cursor, EDGE_BACKFILL_TICK_MAX_TRACKS)
        if not ids:
            update_edge_backfill(db, catalog_instance_id, "complete", cursor="",
                                 next_retry_hours=EDGE_BACKFILL_RESWEEP_HOURS, completed=True)
            return {"status": "complete", "processed": 0}
        update_edge_backfill(db, catalog_instance_id, "running", started=started)
        deadline = time.monotonic() + EDGE_BACKFILL_TICK_SECONDS
        reached, counts = cursor, {}
        for track_id in ids:
            if reached != cursor and time.monotonic() > deadline:
                break
            jobs, _ready = claim_edge_jobs(get_db(), catalog_instance_id, [track_id])
            for outcome in analyze_edges_task(jobs, catalog_instance_id, server_id,
                                              budget_seconds=None):
                counts[outcome["status"]] = counts.get(outcome["status"], 0) + 1
            reached = track_id
        processed = sum(counts.values())
        update_edge_backfill(db, catalog_instance_id, "queued", cursor=reached, processed=processed)
        return {"status": "queued", "processed": processed, **counts}
    except Exception as exc:
        _rollback_if_possible(db)
        update_edge_backfill(db, catalog_instance_id, "failed", error=exc)
        raise


def serve_deferred_interactive(limit=None):
    """Serve on-demand work the host refused to queue; returns tracks served.

    Called by background batches before each track, first thing by every
    reconcile tick, and after each AudioMuse song hook, so a refused request
    waits about one track. Waveform first, then edges. Never raises.
    """
    global _serving_deferred
    if _serving_deferred or maintenance_paused():
        return 0
    limit = limit or INTERACTIVE_PROFILE_CHUNK_SIZE
    _serving_deferred = True
    served = 0
    db = None
    try:
        db = get_db()
        by_source = {}
        for source, track_id, token in claim_deferred_profiles(db, limit):
            by_source.setdefault(source, {})[track_id] = token
        for source, tokens in by_source.items():
            server = resolve_profile_source(catalog_instance_id=source)["server_id"]
            analyze_tracks_task(list(tokens), catalog_instance_id=source, server_id=server,
                                priority="interactive", attempt_tokens=tokens)
            served += len(tokens)
        if edge_profiles_enabled():
            by_source = {}
            for job in claim_deferred_edge_jobs(db, DEFERRED_MARKER, limit):
                by_source.setdefault(job.pop("catalog_instance_id"), []).append(job)
            for source, jobs in by_source.items():
                server = resolve_profile_source(catalog_instance_id=source)["server_id"]
                analyze_edges_task(jobs, source, server, "interactive")
                served += len(jobs)
    except Exception:
        if db is not None:
            _rollback_if_possible(db)
        logger.exception("lumae_analysis could not serve deferred on-demand work")
    finally:
        _serving_deferred = False
    return served


_serving_deferred = False


def _wake_for_deferred():
    """Put the reconcile watchdog on minute cadence for saved on-demand work.

    The schedule also counts deferred work as ready, so it stays active until
    that work is served. Never fails the request that deferred.
    """
    db = None
    try:
        db = get_db()
        arm_reconcile(db, "deferred_on_demand", commit=True)
    except Exception:
        if db is not None:
            _rollback_if_possible(db)
        logger.warning("lumae_analysis could not wake the watchdog for deferred work")


def claim_deferred_profiles(db, limit):
    """Take refused on-demand waveform attempts, oldest first: (source, track, token)."""
    cur = db.cursor()
    cur.execute(
        f"""UPDATE {source_profiles_table()} p SET last_error=NULL
              FROM (SELECT catalog_instance_id, track_id FROM {source_profiles_table()}
                     WHERE status='pending_interactive' AND last_error=%s
                       AND attempt_token IS NOT NULL
                     ORDER BY analyzed_at, track_id LIMIT %s FOR UPDATE SKIP LOCKED) d
             WHERE p.catalog_instance_id=d.catalog_instance_id AND p.track_id=d.track_id
         RETURNING p.catalog_instance_id, p.track_id, p.attempt_token""",
        (DEFERRED_MARKER, int(limit)),
    )
    rows = cur.fetchall()
    db.commit()
    cur.close()
    return [(row[0], row[1], row[2]) for row in rows]


def mark_profiles_deferred(db, catalog_instance_id, tokens):
    """Keep refused on-demand attempts pending, marked for the next worker task."""
    cur = db.cursor()
    for track_id, token in tokens.items():
        cur.execute(
            f"""UPDATE {source_profiles_table()} SET last_error=%s
                 WHERE catalog_instance_id=%s AND track_id=%s AND attempt_token=%s
                   AND status='pending_interactive'""",
            (DEFERRED_MARKER, catalog_instance_id, track_id, token),
        )
    db.commit()
    cur.close()


def interactive_demand_pending(db):
    """Whether on-demand waveform or edge work is waiting (credits and metadata yield)."""
    cur = db.cursor()
    cur.execute(
        f"""SELECT EXISTS(SELECT 1 FROM {source_profiles_table()} WHERE status='pending_interactive')
                OR EXISTS(SELECT 1 FROM {table('edge_profile_jobs')}
                           WHERE status='pending' AND priority='interactive')"""
    )
    row = cur.fetchone()
    cur.close()
    return bool(row and row[0])


def analyze_one_track(track_id, catalog_instance_id=None, server_id=None,
                      attempt_token=None, priority="background"):
    if maintenance_paused():
        release_pending(
            [track_id], catalog_instance_id=catalog_instance_id,
            reason="Lumae background maintenance is paused",
            tokens={track_id: attempt_token} if attempt_token else None,
            count_failure=False,
        )
        return {"track_id": track_id, "status": "skipped_maintenance_paused"}
    if catalog_instance_id and not attempt_token:
        return {"track_id": track_id, "status": "superseded"}

    def complete(result, status, error=None, media_sig=None, failure_code=None,
                 diagnostics=None):
        applied = upsert_profile(
            track_id, result, status, error, media_sig,
            catalog_instance_id=catalog_instance_id,
            attempt_token=attempt_token,
            **({"failure_code": failure_code} if failure_code else {}),
            **({"diagnostics": diagnostics} if diagnostics else {}),
        )
        return {"track_id": track_id, "status": status if applied else "superseded"}

    try:
        info = load_track_file(
            track_id, catalog_instance_id=catalog_instance_id, server_id=server_id,
        )
    except MediaDownloadError as exc:
        return complete(object(), "failed", str(exc), failure_code="download_unavailable")
    if info is None:
        return complete(object(), "skipped_no_file", "missing file path", failure_code="media_unavailable")
    try:
        result = run_file_analysis(analyze_file, info["file_path"])
        outcome = complete(result, "ready", media_sig=info["media_signature"])
        if outcome["status"] == "ready":
            # An on-demand track's edge follows at on-demand priority.
            _schedule_edge_upgrade(track_id, catalog_instance_id, server_id, priority)
        return outcome
    except Exception as exc:
        code = analysis_failure_code(track_id, exc)
        return complete(object(), "failed", str(exc), info["media_signature"], code,
                        analysis_isolation.failure_diagnostics(exc))
    finally:
        remove_downloaded_file(info.get("cleanup_path"))


def hook_track_id(song):
    song = song or {}
    media_item = song.get("media_item") or {}
    track_id = song.get("item_id") or media_item.get("Id") or media_item.get("id")
    return str(track_id) if track_id else ""


def hook_source_path(song):
    song = song or {}
    media_item = song.get("media_item") or {}
    metadata = song.get("metadata") or {}
    return (
        media_item.get("FilePath")
        or media_item.get("Path")
        or media_item.get("path")
        or metadata.get("file_path")
        or ""
    )


def hook_media_signature(song, audio_path):
    track_id = hook_track_id(song)
    source_path = hook_source_path(song)
    audio_sig = media_signature(audio_path) or ""
    return f"analysis-hook|{track_id}|{source_path}|{audio_sig}"


def catalog_media_signature(track_id, server_id=None, catalog_instance_id=None):
    db = get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT t.media_fp
          FROM {table('catalog_sources')} s
          JOIN {table('catalog_state')} c USING (catalog_instance_id)
          JOIN {table('catalog_tracks')} t
            ON t.catalog_instance_id=s.catalog_instance_id
           AND t.published_generation=c.published_generation
         WHERE t.track_id=%s AND t.available=TRUE AND s.rebind_status='active'
           AND (%s IS NULL OR s.current_core_server_id=%s)
           AND (%s IS NULL OR s.catalog_instance_id=%s)
         ORDER BY s.is_default DESC LIMIT 1
        """,
        (track_id, server_id, server_id, catalog_instance_id, catalog_instance_id),
    )
    row = cur.fetchone()
    cur.close()
    return f"catalog-media:{row[0]}" if row and row[0] else None


def update_analysis_run(
    catalog_instance_id,
    run_id,
    status,
    *,
    finalizer_job_id=None,
    queued_profiles=None,
    profile_jobs=None,
    last_error=None,
    completed=False,
    db=None,
):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        UPDATE {analysis_runs_table()}
           SET status=%s,
               finalizer_job_id=COALESCE(%s, finalizer_job_id),
               queued_profiles=COALESCE(%s, queued_profiles),
               profile_jobs=COALESCE(%s, profile_jobs),
               last_error=%s,
               started_at=CASE WHEN %s='running' THEN COALESCE(started_at, now()) ELSE started_at END,
               completed_at=CASE WHEN %s THEN now() ELSE completed_at END,
               updated_at=now()
         WHERE catalog_instance_id=%s AND run_id=%s
        """,
        (
            status,
            finalizer_job_id,
            queued_profiles,
            profile_jobs,
            str(last_error)[:2000] if last_error else None,
            status,
            bool(completed),
            catalog_instance_id,
            run_id,
        ),
    )
    db.commit()
    cur.close()


def record_analysis_run(server_id, catalog_instance_id, run_id, db=None):
    """Count a hook and durably request reconciliation after its parent settles."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {analysis_runs_table()}
            (catalog_instance_id, run_id, server_id, status, songs_seen,
             first_seen_at, last_seen_at, updated_at)
        VALUES (%s, %s, %s, 'pending', 1, now(), now(), now())
        ON CONFLICT (catalog_instance_id, run_id) DO UPDATE SET
            server_id=EXCLUDED.server_id,
            songs_seen={analysis_runs_table()}.songs_seen + 1,
            last_seen_at=now(),
            status=CASE
                WHEN {analysis_runs_table()}.status IN ('running', 'complete')
                    THEN {analysis_runs_table()}.status
                ELSE 'pending'
            END,
            finalizer_job_id=CASE
                WHEN {analysis_runs_table()}.status IN ('running', 'complete')
                    THEN {analysis_runs_table()}.finalizer_job_id
                ELSE NULL
            END,
            last_error=CASE
                WHEN {analysis_runs_table()}.status IN ('running', 'complete')
                    THEN {analysis_runs_table()}.last_error
                ELSE NULL
            END,
            retry_count=CASE
                WHEN {analysis_runs_table()}.status IN ('running', 'complete')
                    THEN {analysis_runs_table()}.retry_count
                ELSE 0
            END,
            next_retry_at=CASE
                WHEN {analysis_runs_table()}.status IN ('running', 'complete')
                    THEN {analysis_runs_table()}.next_retry_at
                ELSE NULL
            END,
            updated_at=now()
        RETURNING status, songs_seen
        """,
        (catalog_instance_id, run_id, server_id),
    )
    row = cur.fetchone()
    arm_reconcile(db, "analysis_hook")
    db.commit()
    cur.close()
    return {
        "queued": False,
        "coalesced": bool(row and int(row[1] or 0) > 1),
        "status": str(row[0]) if row else "pending",
    }


def claim_analysis_run(catalog_instance_id, run_id, finalizer_job_id=None, db=None):
    del finalizer_job_id
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        UPDATE {analysis_runs_table()}
           SET status='running', started_at=COALESCE(started_at, now()),
               last_error=NULL, next_retry_at=NULL, updated_at=now()
         WHERE catalog_instance_id=%s AND run_id=%s
           AND (status IN ('pending', 'registering', 'queued',
                           'enqueue_failed', 'failed')
                OR (status='running' AND updated_at
                    < now() - interval '{ANALYSIS_RUN_STALE_MINUTES} minutes'))
        RETURNING songs_seen
        """,
        (catalog_instance_id, run_id),
    )
    row = cur.fetchone()
    db.commit()
    cur.close()
    return int(row[0] or 0) if row else None


def finalize_analysis_run_task(server_id, catalog_instance_id, run_id):
    """Publish one complete source update after an AudioMuse analysis run settles."""
    if maintenance_paused():
        return {
            "status": "paused",
            "reason": "maintenance_paused",
            "run_id": run_id,
        }
    songs_seen = claim_analysis_run(catalog_instance_id, run_id)
    if songs_seen is None:
        return {"status": "already_finalized", "run_id": run_id}
    try:
        _safe_progress("refreshing catalogue")
        source = resolve_profile_source(
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
        )
        if source["catalog_instance_id"] != catalog_instance_id:
            raise CatalogScanError("Catalogue identity changed before run finalization")
        catalog_result = refresh_catalog(server_id=server_id)
        if catalog_result["catalog_instance_id"] != catalog_instance_id:
            raise CatalogScanError("Catalogue identity changed during run finalization")
        _safe_progress("projecting AudioMuse analysis")
        projection_result = project_analysis(
            server_id=server_id,
            adapter=get_core_adapter(),
        )
        if projection_result["catalog_instance_id"] != catalog_instance_id:
            raise CatalogScanError("Analysis identity changed during run finalization")
        _safe_progress("admitting volume and ramp work")
        profile_result = start_profile_backfill(
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
            enqueue_job=False,
        )
        try:
            _safe_progress("admitting relationship work")
            relationship_result = start_relationship_preparation(
                catalog_instance_id=catalog_instance_id,
                server_id=server_id,
                enqueue_job=False,
            )
        except Exception as exc:
            logger.exception(
                "lumae_analysis could not start relationship enrichment after analysis"
            )
            relationship_result = {
                "queued": False,
                "coalesced": False,
                "error": str(exc),
            }
        update_analysis_run(
            catalog_instance_id,
            run_id,
            "complete",
            queued_profiles=(profile_result["batch_size"] if profile_result["queued"] else 0),
            profile_jobs=(
                1
                if profile_result["queued"] and not profile_result.get("deferred")
                else 0
            ),
            completed=True,
        )
        return {
            "status": "complete",
            "run_id": run_id,
            "songs_seen": songs_seen,
            "catalog": catalog_result,
            "analysis": projection_result,
            "profiles": profile_result,
            "relationships": relationship_result,
        }
    except Exception as exc:
        update_analysis_run(
            catalog_instance_id,
            run_id,
            "failed",
            last_error=exc,
        )
        raise


def analyze_song_hook(song):
    """AudioMuse per-song hook; while AudioMuse's own analysis runs no plugin
    task can start, so each song also serves one deferred on-demand track."""
    try:
        return _analyze_song_hook(song)
    finally:
        serve_deferred_interactive(limit=1)


def _analyze_song_hook(song):
    event = {}
    source_server_id = None
    catalog_instance_id = None
    try:
        event = get_core_adapter().normalize_analysis_hook(song)
        source_server_id = event["server_id"]
        catalog_instance_id = resolve_profile_source(server_id=source_server_id)[
            "catalog_instance_id"
        ]
    except Exception:
        logger.exception("lumae_analysis could not resolve the analysis source")
    if catalog_instance_id and maintenance_paused():
        return {"track_id": hook_track_id(song), "status": "skipped_maintenance_paused"}
    if catalog_instance_id:
        run_id = str((event or {}).get("run_id") or "").strip()
        if run_id:
            try:
                record_analysis_run(source_server_id, catalog_instance_id, run_id)
            except Exception:
                logger.exception(
                    "lumae_analysis could not record source finalization for run %s",
                    run_id,
                )
        else:
            logger.warning("lumae_analysis analysis hook did not include run_id")
    track_id = hook_track_id(song)
    if not track_id:
        logger.warning("lumae_analysis song hook skipped payload without item_id")
        return {"track_id": "", "status": "skipped_no_file"}
    if not catalog_instance_id:
        logger.warning("lumae_analysis song hook skipped %s without an exact source", track_id)
        return {"track_id": track_id, "status": "skipped_source_unresolved"}
    # An AudioMuse re-analysis pass fires this hook for every song. A current
    # published profile needs no new attempt (AUD-03); changed media, a new
    # analyzer or schema, and failed rows still requalify (LUM-007).
    if published_profile_current(
        get_db(), catalog_instance_id, track_id, ANALYZER_VERSION, SCHEMA_VERSION
    ):
        # Still heal a missing edge; a current edge makes this a no-op.
        _schedule_edge_upgrade(track_id, catalog_instance_id, source_server_id)
        return {"track_id": track_id, "status": "current"}
    tokens = mark_pending([track_id], catalog_instance_id, priority="interactive")
    token = tokens.get(track_id)
    if not token:
        return {"track_id": track_id, "status": "skipped_source_unresolved"}
    audio_path = (song or {}).get("audio_path")
    media_sig = catalog_media_signature(
        track_id, source_server_id, catalog_instance_id=catalog_instance_id
    )

    def complete(result, status, error=None, failure_code=None, diagnostics=None):
        applied = upsert_profile(
            track_id, result, status, error, media_sig,
            catalog_instance_id=catalog_instance_id, attempt_token=token,
            **({"failure_code": failure_code} if failure_code else {}),
            **({"diagnostics": diagnostics} if diagnostics else {}),
        )
        # An AudioMuse run completes profiles song by song. Keep the settings
        # counts moving without counting the library for every song (P2-1).
        refresh_status_snapshot(
            catalog_instance_id=catalog_instance_id,
            min_age_seconds=status_model.PROFILE_COUNTS_MIN_AGE_SECONDS,
        )
        return {"track_id": track_id, "status": status if applied else "superseded"}

    if not audio_path or not os.path.exists(audio_path):
        return complete(object(), "skipped_no_file", "missing analysis audio path", "media_unavailable")
    try:
        result = run_file_analysis(analyze_file, audio_path)
        outcome = complete(result, "ready")
        if outcome["status"] == "ready":
            _schedule_edge_upgrade(track_id, catalog_instance_id, source_server_id)
        return outcome
    except Exception as exc:
        code = analysis_failure_code(track_id, exc, "hook failed")
        return complete(object(), "failed", str(exc), code,
                        analysis_isolation.failure_diagnostics(exc))


def profile_task_disposition(track_id, catalog_instance_id=None, server_id=None, priority="background"):
    rows = fetch_profile_rows([track_id], catalog_instance_id=catalog_instance_id)
    row = rows[0] if rows else None
    if not row:
        return "analyze"
    if priority != "interactive" and row.get("status") == "pending_interactive":
        return "promoted"
    if row.get("status") != "ready" or int(row.get("analyzer_ver") or 0) < ANALYZER_VERSION:
        return "analyze"
    expected_signature = catalog_media_signature(
        track_id, server_id, catalog_instance_id=catalog_instance_id
    )
    stored_signature = row.get("media_signature")
    if expected_signature and stored_signature != expected_signature:
        return "analyze"
    return "already_ready"


def analyze_tracks_task(
    ids,
    catalog_instance_id=None,
    server_id=None,
    priority="background",
    attempt_tokens=None,
):
    ids = parse_ids(",".join(ids or []))
    if maintenance_paused():
        release_pending(
            ids,
            catalog_instance_id=catalog_instance_id,
            reason="Lumae background maintenance is paused",
            tokens=attempt_tokens,
            count_failure=False,
        )
        return {
            "attempted": 0,
            "ready": 0,
            "already_ready": 0,
            "promoted": 0,
            "failed": 0,
            "skipped": len(ids),
            "deferred": len(ids),
            "paused": True,
        }
    if catalog_instance_id and not attempt_tokens:
        # Persisted jobs from before token admission cannot publish or release.
        return {
            "attempted": 0, "ready": 0, "already_ready": 0,
            "promoted": 0, "failed": 0, "skipped": len(ids),
            "deferred": len(ids), "superseded": len(ids),
        }

    if priority == "background" and len(ids) > MAX_BACKFILL_BATCH_SIZE:
        # Drain 0.8.0's already-persisted 250-track RQ jobs quickly after an
        # upgrade. Their rows become retryable and one bounded chain owns the
        # remaining durable work; interactive requests can promote any of them now.
        release_pending(
            ids,
            catalog_instance_id=catalog_instance_id,
            reason="Migrated to bounded 0.8.1 background enrichment",
            tokens=attempt_tokens,
            count_failure=False,
        )
        if catalog_instance_id or server_id:
            try:
                start_profile_backfill(
                    catalog_instance_id=catalog_instance_id,
                    server_id=server_id,
                    enqueue_job=False,
                )
            except Exception:
                logger.exception("lumae_analysis could not migrate a legacy backfill job")
        return {
            "attempted": 0,
            "ready": 0,
            "already_ready": 0,
            "promoted": 0,
            "failed": 0,
            "skipped": 0,
            "deferred": len(ids),
        }
    results = []
    attempted = 0
    for index, track_id in enumerate(ids):
        _safe_progress("analyzing volume and ramps", current=index, total=len(ids))
        if priority == "background":
            serve_deferred_interactive()
        if priority == "background" and catalog_instance_id:
            heartbeat_profile_backfill(catalog_instance_id)
        if maintenance_paused():
            remaining = ids[index:]
            release_pending(
                remaining,
                catalog_instance_id=catalog_instance_id,
                reason="Lumae background maintenance was paused during the batch",
                tokens=attempt_tokens,
                count_failure=False,
            )
            results.extend(
                {"track_id": item_id, "status": "skipped_maintenance_paused"}
                for item_id in remaining
            )
            break
        if catalog_instance_id and track_id not in attempt_tokens:
            results.append({"track_id": track_id, "status": "superseded"})
            continue
        disposition = profile_task_disposition(
            track_id,
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
            priority=priority,
        )
        if disposition != "analyze":
            results.append({"track_id": track_id, "status": disposition})
            continue
        attempted += 1
        results.append(
            analyze_one_track(
                track_id,
                catalog_instance_id=catalog_instance_id,
                server_id=server_id,
                attempt_token=attempt_tokens.get(track_id) if catalog_instance_id else None,
                priority=priority,
            )
        )
        _safe_progress("analyzing volume and ramps", current=index + 1, total=len(ids))
        if priority == "background" and catalog_instance_id:
            heartbeat_profile_backfill(catalog_instance_id)
    summary = {
        "attempted": attempted,
        "ready": sum(1 for result in results if result["status"] == "ready"),
        "already_ready": sum(
            1 for result in results if result["status"] == "already_ready"
        ),
        "promoted": sum(1 for result in results if result["status"] == "promoted"),
        "failed": sum(1 for result in results if result["status"] == "failed"),
        "skipped": sum(1 for result in results if result["status"].startswith("skipped")),
        "deferred": 0,
    }
    if catalog_instance_id:
        finalize_preparation_if_settled(catalog_instance_id)
        if priority != "background":
            # Background batches run inside a watchdog tick, which refreshes
            # the settings counts when it ends; an interactive batch refreshes
            # them itself (P2-1).
            refresh_status_snapshot(catalog_instance_id=catalog_instance_id)
    return summary


def is_backfill_candidate(file_path, stored_sig, analyzer_ver, status):
    if is_pending_profile_status(status):
        return False
    current_sig = (
        file_path if str(file_path or "").startswith("catalog-media:") else media_signature(file_path)
    )
    if status == "deferred_no_media_revision":
        return bool(current_sig and current_sig != "catalog-media:")
    if status == "skipped_no_file":
        return bool(current_sig or media_server_download_available())
    if analyzer_ver is None:
        return True
    if int(analyzer_ver) < ANALYZER_VERSION:
        return True
    if status == "stale":
        return True
    if status == "ready" and current_sig and current_sig != "catalog-media:" and current_sig != stored_sig:
        return True
    return False


def fetch_analysis_rows(catalog_instance_id=None, server_id=None):
    db = get_db()
    cur = db.cursor()
    profile_table = source_profiles_table() if catalog_instance_id else profiles_table()
    profile_source_join = (
        "AND p.catalog_instance_id=source.catalog_instance_id" if catalog_instance_id else ""
    )
    source_filters = ""
    params = ()
    if catalog_instance_id or server_id:
        source_filters = """
               AND (%s IS NULL OR s.catalog_instance_id=%s)
               AND (%s IS NULL OR s.current_core_server_id=%s)
        """
        params = (catalog_instance_id, catalog_instance_id, server_id, server_id)
    sql = f"""
        WITH source AS (
            SELECT s.catalog_instance_id, c.published_generation
              FROM {table('catalog_sources')} s
              JOIN {table('catalog_state')} c USING (catalog_instance_id)
             WHERE s.rebind_status='active' AND c.status='complete'
               {source_filters}
             ORDER BY s.is_default DESC, s.server_name, s.catalog_instance_id
             LIMIT 1
        )
        SELECT t.track_id, 'catalog-media:' || COALESCE(t.media_fp, ''),
               p.media_signature, p.analyzer_ver, p.status
          FROM source
          JOIN {table('catalog_tracks')} t
            ON t.catalog_instance_id=source.catalog_instance_id
           AND t.published_generation=source.published_generation
          LEFT JOIN {profile_table} p ON p.track_id=t.track_id
               {profile_source_join}
         WHERE t.available=TRUE AND t.analysis_eligible=TRUE
         ORDER BY t.track_id
        """
    if params:
        cur.execute(sql, params)
    else:
        cur.execute(sql)
    rows = cur.fetchall()
    cur.close()
    return rows


def fetch_backfill_rows(
    limit,
    catalog_instance_id=None,
    server_id=None,
    include_failed=False,
):
    """Select only one retryable profile batch in PostgreSQL."""
    db = get_db()
    cur = db.cursor()
    profile_table = source_profiles_table() if catalog_instance_id else profiles_table()
    profile_source_join = (
        "AND p.catalog_instance_id=source.catalog_instance_id" if catalog_instance_id else ""
    )
    source_filters = ""
    params = scheduler_params(ANALYZER_VERSION, SCHEMA_VERSION)
    params.update(
        source=catalog_instance_id, server_id=server_id,
        include_failed=bool(include_failed), limit=max(1, int(limit)),
    )
    if catalog_instance_id or server_id:
        source_filters = """
               AND (%(source)s IS NULL OR s.catalog_instance_id=%(source)s)
               AND (%(server_id)s IS NULL OR s.current_core_server_id=%(server_id)s)
        """
    # The source table's predicates are profile_publication's, shared with
    # next_profile_retry_at and the /database-state work states (LUM-007).
    # Published catalogue occurrences are downloaded through
    # ProviderCatalogBridge, so a skipped row stays retryable on the legacy
    # table even when a v3 registry source has no matching legacy global
    # MEDIASERVER_* configuration.
    due = backfill_due_sql() if catalog_instance_id else backfill_due_sql(
        stale="p.status='stale'",
        failure="((%(include_failed)s AND p.status='failed') "
                "OR p.status='skipped_no_file')",
    )
    cur.execute(
        f"""
        WITH source AS (
            SELECT s.catalog_instance_id, c.published_generation
              FROM {table('catalog_sources')} s
              JOIN {table('catalog_state')} c USING (catalog_instance_id)
             WHERE s.rebind_status='active' AND c.status='complete'
               {source_filters}
             ORDER BY s.is_default DESC, s.server_name, s.catalog_instance_id
             LIMIT 1
        )
        SELECT t.track_id, 'catalog-media:' || COALESCE(t.media_fp, ''),
               p.media_signature, p.analyzer_ver, p.status
          FROM source
          JOIN {table('catalog_tracks')} t
            ON t.catalog_instance_id=source.catalog_instance_id
           AND t.published_generation=source.published_generation
          LEFT JOIN {profile_table} p ON p.track_id=t.track_id
               {profile_source_join}
         WHERE t.available=TRUE AND t.analysis_eligible=TRUE
           AND {due}
         ORDER BY t.track_id
         LIMIT %(limit)s
        """,
        params,
    )
    rows = cur.fetchall()
    cur.close()
    return rows


def find_backfill_ids(
    limit=25,
    catalog_instance_id=None,
    server_id=None,
    include_failed=False,
):
    batch_limit = normalize_backfill_limit(limit or configured_backfill_limit())
    ids = []
    rows = fetch_backfill_rows(
        batch_limit,
        catalog_instance_id=catalog_instance_id,
        server_id=server_id,
        include_failed=include_failed,
    )
    for item_id, file_path, stored_sig, analyzer_ver, status in rows:
        if (
            (catalog_instance_id and status in ("failed", "skipped_no_file"))
            or (include_failed and status == "failed")
            or is_backfill_candidate(
                file_path, stored_sig, analyzer_ver, status
            )
        ):
            ids.append(str(item_id))
            if len(ids) >= batch_limit:
                break
    return ids


def find_all_backfill_ids(catalog_instance_id=None, server_id=None, include_failed=False):
    ids = []
    rows = (
        fetch_analysis_rows(catalog_instance_id=catalog_instance_id, server_id=server_id)
        if catalog_instance_id or server_id
        else fetch_analysis_rows()
    )
    for item_id, file_path, stored_sig, analyzer_ver, status in rows:
        if (include_failed and status == "failed") or is_backfill_candidate(
            file_path, stored_sig, analyzer_ver, status
        ):
            ids.append(str(item_id))
    return ids


def _analysis_status_counts_query(catalog_instance_id=None, server_id=None):
    """The waveform status aggregate. Its sixth column is the counted generation.

    ``analysis_status_counts`` runs it live; ``refresh_status_snapshot`` stores
    its result for ``/settings/status`` (P2-1).
    """
    profile_table = source_profiles_table() if catalog_instance_id else profiles_table()
    profile_source_join = (
        "AND p.catalog_instance_id=source.catalog_instance_id" if catalog_instance_id else ""
    )
    source_filters = ""
    params = []
    if catalog_instance_id or server_id:
        source_filters = """
               AND (%s IS NULL OR s.catalog_instance_id=%s)
               AND (%s IS NULL OR s.current_core_server_id=%s)
        """
        params.extend((catalog_instance_id, catalog_instance_id, server_id, server_id))
    # A published catalogue occurrence is retried through ProviderCatalogBridge,
    # including v3 registry sources whose credentials are not represented by
    # the legacy global MEDIASERVER_* configuration fields.
    retry_skipped = True
    params.extend((ANALYZER_VERSION, retry_skipped))
    sql = f"""
        WITH source AS (
            SELECT s.catalog_instance_id, c.published_generation
              FROM {table('catalog_sources')} s
              JOIN {table('catalog_state')} c USING (catalog_instance_id)
             WHERE s.rebind_status='active' AND c.status='complete'
               {source_filters}
             ORDER BY s.is_default DESC, s.server_name, s.catalog_instance_id
             LIMIT 1
        )
        SELECT
            COUNT(*)::BIGINT,
            COUNT(*) FILTER (
                WHERE p.status='ready'
                  AND p.analyzer_ver >= %s
                  AND p.media_signature IS NOT DISTINCT FROM
                      ('catalog-media:' || COALESCE(t.media_fp, ''))
            )::BIGINT,
            COUNT(*) FILTER (
                WHERE p.status IN ('pending', 'pending_interactive')
            )::BIGINT,
            COUNT(*) FILTER (WHERE p.status='failed')::BIGINT,
            COUNT(*) FILTER (
                WHERE p.status='skipped_no_file' AND NOT %s
            )::BIGINT,
            (SELECT published_generation FROM source)
          FROM source
          JOIN {table('catalog_tracks')} t
            ON t.catalog_instance_id=source.catalog_instance_id
           AND t.published_generation=source.published_generation
          LEFT JOIN {profile_table} p ON p.track_id=t.track_id
               {profile_source_join}
         WHERE t.available=TRUE AND t.analysis_eligible=TRUE
        """
    return sql, tuple(params)


def analysis_status_counts(catalog_instance_id=None, server_id=None):
    db = get_db()
    cur = db.cursor()
    cur.execute(*_analysis_status_counts_query(catalog_instance_id, server_id))
    row = cur.fetchone() or (0, 0, 0, 0, 0)
    cur.close()
    total, ready, pending, failed, skipped = (int(value or 0) for value in row[:5])
    return {
        "total_with_files": total,
        "ready_current": ready,
        "pending": pending,
        "failed": failed,
        "skipped": skipped,
        "needs_analysis": max(0, total - ready - pending - failed - skipped),
    }


def _store_profile_snapshots(cur, catalog_instance_id=None, min_age_seconds=0,
                             missing_only=False):
    if catalog_instance_id:
        targets = [str(catalog_instance_id)]
    else:
        cur.execute(
            f"""
            SELECT s.catalog_instance_id
              FROM {table('catalog_sources')} s
              JOIN {table('catalog_state')} c USING (catalog_instance_id)
              LEFT JOIN {table('status_summary')} ss USING (catalog_instance_id)
             WHERE NOT %s OR ss.profile_generation IS DISTINCT FROM c.published_generation
             ORDER BY s.catalog_instance_id
            """,
            (bool(missing_only),),
        )
        targets = [str(row[0]) for row in cur.fetchall()]
    stored = 0
    for target in targets:
        if min_age_seconds:
            age = status_model.profile_counts_age_seconds(cur, target)
            if age is not None and age < min_age_seconds:
                continue
        sql, params = _analysis_status_counts_query(catalog_instance_id=target)
        status_model.store_profile_counts(cur, target, sql, params)
        stored += 1
    return stored


def refresh_status_snapshot(db=None, catalog_instance_id=None, min_age_seconds=0,
                            publications=False):
    """Refresh the waveform counts that ``/settings/status`` reads (P2-1).

    Background work calls this after it changed profile state; the GET route
    only reads the snapshot. With ``min_age_seconds`` a snapshot younger than
    that is kept. ``publications`` first summarizes any published generation
    that has no summary (a failed post-commit refresh, a rebound source, an
    older worker's publication). Never raises: a failed refresh keeps the
    previous snapshot, and the route counts live when the snapshot describes
    another generation.
    """
    try:
        db = db or get_db()
    except Exception:
        db = None
    if db is None:
        return 0
    try:
        cur = db.cursor()
        try:
            if publications:
                # Committed per source and before the waveform count, so no
                # analysis_state row lock is held while counting.
                status_model.backfill_publication_summaries(cur, commit=db.commit)
                db.commit()
            stored = _store_profile_snapshots(cur, catalog_instance_id, min_age_seconds)
        finally:
            cur.close()
        db.commit()
        return stored
    except Exception:
        _rollback_if_possible(db)
        logger.warning(
            "lumae_analysis could not refresh the settings status counts", exc_info=True
        )
        return 0


def refresh_status_summaries(db):
    """Install and upgrade: summarize what is already published (P2-1).

    Runs in the install transaction; the caller commits. Only what has no
    summary yet is counted, so a re-run writes nothing.
    """
    cur = db.cursor()
    try:
        status_model.backfill_publication_summaries(cur)
        _store_profile_snapshots(cur, missing_only=True)
    finally:
        cur.close()


def _committed_profile_counts(source):
    """The committed waveform counts of a source, or None to count live."""
    db = None
    try:
        db = get_db()
        return status_model.profile_counts(db, source) if db is not None else None
    except Exception:
        _rollback_if_possible(db)
        logger.warning("lumae_analysis could not read the settings status counts", exc_info=True)
        return None


def queue_backfill_batch(
    limit=None,
    catalog_instance_id=None,
    server_id=None,
    include_failed=False,
):
    batch_limit = normalize_backfill_limit(limit or configured_backfill_limit())
    ids = (
        find_backfill_ids(
            batch_limit,
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
            include_failed=include_failed,
        )
        if catalog_instance_id or server_id
        else find_backfill_ids(batch_limit)
    )
    if ids:
        enqueue_profile_analysis(
            ids,
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
        )
    return {"queued": len(ids), "limit": batch_limit}


def profile_backfill_state(catalog_instance_id, db=None):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT server_id, status, processed_profiles, queued_profiles,
               last_error, started_at, completed_at, updated_at, next_retry_at
          FROM {profile_backfill_state_table()}
         WHERE catalog_instance_id=%s
        """,
        (catalog_instance_id,),
    )
    row = cur.fetchone()
    cur.close()
    if row is None:
        return None
    return {
        "catalog_instance_id": str(catalog_instance_id),
        "server_id": str(row[0]),
        "status": str(row[1]),
        "processed_profiles": int(row[2] or 0),
        "queued_profiles": int(row[3] or 0),
        "last_error": str(row[4]) if row[4] else None,
        "started_at": str(row[5]) if row[5] else None,
        "completed_at": str(row[6]) if row[6] else None,
        "updated_at": str(row[7]) if row[7] else None,
        # LUM-017 (P3-9): when this is set the worker is deliberately
        # cooling down after a transient failure, not idle or stuck.
        "next_retry_at": str(row[8]) if row[8] else None,
    }


def profile_backfill_is_active(state, now=None):
    if not state or state.get("status") not in ("queued", "running"):
        return False
    try:
        updated_at = datetime.fromisoformat(str(state["updated_at"]).replace("Z", "+00:00"))
        current = now or datetime.now(timezone.utc)
        if updated_at.tzinfo is None:
            updated_at = updated_at.replace(tzinfo=timezone.utc)
        return (current - updated_at).total_seconds() < BACKFILL_STALE_MINUTES * 60
    except (KeyError, TypeError, ValueError):
        return True


def _future_retry_at(value, now=None):
    """``value`` while that cooldown is still ahead of ``now``, else None."""
    if not value:
        return None
    try:
        at = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if at.tzinfo is None:
        at = at.replace(tzinfo=timezone.utc)
    return value if at > (now or datetime.now(timezone.utc)) else None


def claim_profile_backfill(source, db=None):
    """Atomically admit one durable background workflow per catalogue source."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {profile_backfill_state_table()}
            (catalog_instance_id, server_id, status, processed_profiles,
             queued_profiles, last_error, started_at, completed_at, updated_at)
        VALUES (%s, %s, 'queued', 0, 0, NULL, now(), NULL, now())
        ON CONFLICT (catalog_instance_id) DO UPDATE SET
            server_id=EXCLUDED.server_id, status='queued', processed_profiles=0,
            queued_profiles=0, last_error=NULL, started_at=now(),
            completed_at=NULL, retry_count=0, next_retry_at=NULL, updated_at=now()
        WHERE {profile_backfill_state_table()}.status NOT IN ('queued', 'running')
           OR {profile_backfill_state_table()}.updated_at
              < now() - interval '{BACKFILL_STALE_MINUTES} minutes'
        RETURNING catalog_instance_id
        """,
        (source["catalog_instance_id"], source["server_id"]),
    )
    claimed = cur.fetchone() is not None
    if claimed:
        arm_reconcile(db, "profile_backfill_admitted")
    db.commit()
    cur.close()
    return claimed


BACKFILL_ABORT_RETRY_SECONDS = 60


def claim_profile_backfill_batch(catalog_instance_id, db=None):
    """Claim one queued or interrupted batch for exclusive execution."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        UPDATE {profile_backfill_state_table()}
           SET status='running', last_error=NULL, next_retry_at=NULL, updated_at=now()
         WHERE catalog_instance_id=%s
           AND ((status='queued' AND (next_retry_at IS NULL OR next_retry_at <= now()))
                OR (status='failed' AND (next_retry_at IS NULL OR next_retry_at <= now()))
                OR (status='running' AND updated_at
                    < now() - interval '{BACKFILL_STALE_MINUTES} minutes'))
        RETURNING catalog_instance_id
        """,
        (catalog_instance_id,),
    )
    claimed = cur.fetchone() is not None
    db.commit()
    cur.close()
    return claimed


def heartbeat_profile_backfill(catalog_instance_id, db=None):
    """Keep a long bounded waveform batch from looking abandoned."""
    db = db or get_db()
    if db is None:
        return False
    try:
        cur = db.cursor()
        cur.execute(
            f"UPDATE {profile_backfill_state_table()} SET updated_at=now() "
            "WHERE catalog_instance_id=%s AND status='running'",
            (catalog_instance_id,),
        )
        cur.close()
        db.commit()
        return True
    except Exception:
        _rollback_if_possible(db)
        logger.exception("lumae_analysis could not heartbeat profile backfill")
        return False


def update_profile_backfill_state(
    catalog_instance_id,
    server_id,
    status,
    *,
    processed_increment=0,
    queued_profiles=0,
    last_error=None,
    completed=False,
    next_retry_at=None,
    retry_after_seconds=None,
    db=None,
):
    """``retry_after_seconds`` sets ``next_retry_at`` from the database clock
    when ``next_retry_at`` is not given."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {profile_backfill_state_table()}
            (catalog_instance_id, server_id, status, processed_profiles,
             queued_profiles, last_error, started_at, completed_at,
             next_retry_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, now(),
                CASE WHEN %s THEN now() ELSE NULL END,
                COALESCE(%s, now() + %s::float8 * interval '1 second'), now())
        ON CONFLICT (catalog_instance_id) DO UPDATE SET
            server_id=EXCLUDED.server_id,
            status=CASE WHEN EXCLUDED.status='complete'
                              AND {profile_backfill_state_table()}.refresh_wake_pending
                        THEN 'queued' ELSE EXCLUDED.status END,
            refresh_wake_pending=FALSE,
            processed_profiles={profile_backfill_state_table()}.processed_profiles
                + EXCLUDED.processed_profiles,
            queued_profiles=EXCLUDED.queued_profiles,
            last_error=EXCLUDED.last_error,
            completed_at=EXCLUDED.completed_at,
            -- A wake (a catalogue refresh, or the recovery arm of this
            -- batch's own admissions) runs now, except after an explicit
            -- retry delay: an aborted batch waits it out (LUM-007).
            next_retry_at=CASE WHEN {profile_backfill_state_table()}.refresh_wake_pending
                                    AND %s::float8 IS NULL
                                  THEN NULL ELSE EXCLUDED.next_retry_at END,
            updated_at=now()
        """,
        (
            catalog_instance_id,
            server_id,
            status,
            int(processed_increment or 0),
            int(queued_profiles or 0),
            str(last_error)[:2000] if last_error else None,
            bool(completed),
            next_retry_at,
            retry_after_seconds,
            retry_after_seconds,
        ),
    )
    db.commit()
    cur.close()


def enqueue_next_profile_backfill(server_id, catalog_instance_id):
    return enqueue_bounded(
        profile_backfill_task,
        server_id,
        catalog_instance_id,
        queue="default",
        timeout=PROFILE_BACKFILL_JOB_TIMEOUT_SECONDS,
    )


def start_profile_backfill(catalog_instance_id=None, server_id=None, enqueue_job=True):
    if maintenance_paused():
        return {
            "queued": False,
            "coalesced": True,
            "paused": True,
            "batch_size": configured_backfill_limit(),
        }
    source = resolve_profile_source(
        catalog_instance_id=catalog_instance_id,
        server_id=server_id,
    )
    if not claim_profile_backfill(source):
        return {"queued": False, "coalesced": True, "batch_size": configured_backfill_limit()}
    if not enqueue_job:
        return {
            "queued": True,
            "coalesced": False,
            "deferred": True,
            "batch_size": configured_backfill_limit(),
        }
    try:
        job = enqueue_next_profile_backfill(source["server_id"], source["catalog_instance_id"])
    except Exception as exc:
        logger.exception(
            "lumae_analysis could not queue the first profile batch; "
            "the durable watchdog will retry it"
        )
        return {
            "queued": True,
            "coalesced": False,
            "deferred": True,
            "batch_size": configured_backfill_limit(),
            "error": str(exc),
        }
    return {
        "queued": True,
        "coalesced": False,
        "batch_size": configured_backfill_limit(),
        "job_id": getattr(job, "id", None),
    }


def next_profile_retry_at(catalog_instance_id, db=None):
    """Earliest finite due retry for one exact source; no work is queued early."""
    db = db or get_db()
    with db.cursor() as cur:
        cur.execute(
            f"""SELECT MIN(CASE
                       WHEN p.status IN ('pending', 'pending_interactive')
                           THEN p.analyzed_at + interval '1 hour'
                       ELSE p.retry_after END)
                  FROM {source_profiles_table()} p
                  JOIN {table('catalog_sources')} s
                    ON s.catalog_instance_id=p.catalog_instance_id
                  JOIN {table('catalog_state')} c
                    ON c.catalog_instance_id=p.catalog_instance_id
                  JOIN {table('catalog_tracks')} t
                    ON t.catalog_instance_id=p.catalog_instance_id
                   AND t.published_generation=c.published_generation
                   AND t.track_id=p.track_id
                 WHERE p.catalog_instance_id=%(source)s
                   AND s.rebind_status='active'
                   AND t.available=TRUE
                   AND t.analysis_eligible=TRUE
                   AND (
                       p.status IN ('pending', 'pending_interactive')
                       OR {RETRY_ARMED_SQL}
                   )""",
            {**scheduler_params(ANALYZER_VERSION, SCHEMA_VERSION),
             "source": catalog_instance_id},
        )
        row = cur.fetchone()
    return row[0] if row else None


def profile_backfill_task(server_id, catalog_instance_id):
    """Process one small batch; the watchdog resumes a queued next batch."""
    if maintenance_paused():
        update_profile_backfill_state(
            catalog_instance_id,
            server_id,
            "queued",
            last_error=None,
        )
        return {"status": "paused", "processed": 0, "queued_next": False}
    if not claim_profile_backfill_batch(catalog_instance_id):
        return {
            "status": "coalesced",
            "processed": 0,
            "queued_next": False,
        }
    claimed_ids = []
    claim_tokens = {}
    try:
        _safe_progress("selecting volume and ramp batch")
        resolve_profile_source(
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
        )
        recover_stale_pending_profiles(catalog_instance_id)
        ids = find_backfill_ids(
            configured_backfill_limit(),
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
            include_failed=False,
        )
        if not ids:
            next_retry = next_profile_retry_at(catalog_instance_id)
            update_profile_backfill_state(
                catalog_instance_id, server_id,
                "queued" if next_retry else "complete",
                next_retry_at=next_retry, completed=not bool(next_retry),
            )
            return {"status": "waiting_retry" if next_retry else "complete",
                    "processed": 0, "queued_next": False}
        claimed_ids = ids
        claim_tokens = mark_pending(
            ids, catalog_instance_id=catalog_instance_id, priority="background"
        )
        ids = [track_id for track_id in ids if track_id in claim_tokens]
        result = analyze_tracks_task(
            ids,
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
            priority="background",
            attempt_tokens=claim_tokens,
        )
        next_ids = find_backfill_ids(
            1,
            catalog_instance_id=catalog_instance_id,
            server_id=server_id,
            include_failed=False,
        )
        if not next_ids:
            next_retry = next_profile_retry_at(catalog_instance_id)
            update_profile_backfill_state(
                catalog_instance_id, server_id,
                "queued" if next_retry else "complete",
                processed_increment=len(ids), next_retry_at=next_retry,
                completed=not bool(next_retry),
            )
            return {"status": "waiting_retry" if next_retry else "complete",
                    "processed": len(ids), "queued_next": False, **result}
        update_profile_backfill_state(
            catalog_instance_id,
            server_id,
            "queued",
            processed_increment=len(ids),
            queued_profiles=len(next_ids),
        )
        return {
            "status": "queued",
            "processed": len(ids),
            "queued_next": False,
            "deferred": True,
            **result,
        }
    except Exception as exc:
        if claimed_ids:
            try:
                release_pending(
                    claimed_ids,
                    catalog_instance_id=catalog_instance_id,
                    reason=f"Background enrichment batch failed: {exc}",
                    tokens=claim_tokens,
                    count_failure=False,
                )
            except Exception:
                logger.exception("lumae_analysis could not release a failed background batch")
        update_profile_backfill_state(
            catalog_instance_id,
            server_id,
            "failed",
            last_error=exc,
            completed=True,
            # Its rows are due at once (an uncounted release), so a persistent
            # error would abort a batch on every reconcile tick: retry the
            # batch after a fixed minute instead (LUM-007).
            retry_after_seconds=BACKFILL_ABORT_RETRY_SECONDS,
        )
        raise


def queue_whole_library(catalog_instance_id=None, server_id=None, include_failed=False):
    """Compatibility wrapper that starts one bounded durable workflow."""
    del include_failed
    return start_profile_backfill(
        catalog_instance_id=catalog_instance_id,
        server_id=server_id,
    )


def backfill_missing_profiles(limit=None, catalog_instance_id=None, server_id=None):
    requested_limit = limit or configured_backfill_limit()
    source = (
        resolve_profile_source(
            catalog_instance_id=catalog_instance_id, server_id=server_id,
        )["catalog_instance_id"]
        if catalog_instance_id or server_id else None
    )
    ids = (
        find_backfill_ids(
            requested_limit,
            catalog_instance_id=source,
            server_id=server_id,
        )
        if source
        else find_backfill_ids(requested_limit)
    )
    if source:
        tokens = mark_pending(ids, catalog_instance_id=source, priority="background")
        admitted = [track_id for track_id in ids if track_id in tokens]
        return analyze_tracks_task(
            admitted,
            catalog_instance_id=source,
            server_id=server_id,
            attempt_tokens=tokens,
        )
    return analyze_tracks_task(ids)


def relationship_preparation_task(server_id, catalog_instance_id):
    if maintenance_paused():
        return {"status": "paused", "reason": "maintenance_paused"}
    source = resolve_profile_source(
        catalog_instance_id=catalog_instance_id, server_id=server_id,
    )
    if source["catalog_instance_id"] != catalog_instance_id:
        raise CatalogScanError("Catalogue identity changed before relationship preparation")
    # The builder owns a session advisory lock across its checkpoint commits.
    return prepare_relationships(catalog_instance_id, progress=_safe_progress)


def start_relationship_preparation(
    catalog_instance_id=None, server_id=None, enqueue_job=True
):
    """Request one coalesced relationship build without delaying readiness."""
    if maintenance_paused():
        return {
            "queued": False,
            "coalesced": True,
            "paused": True,
            "reason": "maintenance_paused",
        }
    source = resolve_profile_source(
        catalog_instance_id=catalog_instance_id,
        server_id=server_id,
    )
    current = relationship_status(get_db(), source["catalog_instance_id"])
    catalog_generation = int(source["catalog"]["generation"])
    analysis_generation = int(source["analysis"]["generation"])
    already_current = (
        current.get("status") == "complete"
        and int(current.get("source_catalog_generation") or 0) == catalog_generation
        and int(current.get("source_analysis_generation") or 0) == analysis_generation
        and int(current.get("schema_version") or 0) == RELATIONSHIP_SCHEMA_VERSION
        and int(current.get("algorithm_version") or 0) == RELATIONSHIP_ALGORITHM_VERSION
    )
    if already_current:
        return {
            "queued": False,
            "coalesced": True,
            "reason": "already_current",
        }
    if not claim_relationship_preparation(get_db(), source["catalog_instance_id"]):
        return {
            "queued": False,
            "coalesced": True,
            "reason": "already_running",
        }
    if not enqueue_job:
        return {
            "queued": True,
            "coalesced": False,
            "deferred": True,
        }
    try:
        job = enqueue_bounded(
            relationship_preparation_task,
            source["server_id"],
            source["catalog_instance_id"],
            queue="default",
            timeout=RELATIONSHIP_JOB_TIMEOUT_SECONDS,
        )
    except Exception as exc:
        logger.exception(
            "lumae_analysis could not queue relationship preparation; "
            "the durable watchdog will retry it"
        )
        return {
            "queued": True,
            "coalesced": False,
            "deferred": True,
            "error": str(exc),
        }
    return {
        "queued": True,
        "coalesced": False,
        "job_id": getattr(job, "id", None),
    }


def preparation_state(catalog_instance_id, db=None):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        SELECT server_id, status, phase, queued_profiles, profile_jobs,
               target_plugin_version, target_catalog_builder_version,
               worker_plugin_version, worker_catalog_builder_version,
               last_error, started_at, completed_at, updated_at
          FROM {preparation_state_table()}
         WHERE catalog_instance_id=%s
        """,
        (catalog_instance_id,),
    )
    row = cur.fetchone()
    cur.close()
    if row is None:
        return None
    return {
        "catalog_instance_id": str(catalog_instance_id),
        "server_id": str(row[0]),
        "status": str(row[1]),
        "phase": str(row[2]),
        "queued_profiles": int(row[3] or 0),
        "profile_jobs": int(row[4] or 0),
        "target_plugin_version": str(row[5]) if row[5] else None,
        "target_catalog_builder_version": int(row[6]) if row[6] is not None else None,
        "worker_plugin_version": str(row[7]) if row[7] else None,
        "worker_catalog_builder_version": int(row[8]) if row[8] is not None else None,
        "last_error": str(row[9]) if row[9] else None,
        "started_at": str(row[10]) if row[10] else None,
        "completed_at": str(row[11]) if row[11] else None,
        "updated_at": str(row[12]) if row[12] else None,
    }


def preparation_attestation_is_current(state):
    """Legacy completed rows are accepted; newly claimed work must attest."""
    if not state or not state.get("target_plugin_version"):
        return True
    target_builder = int(state.get("target_catalog_builder_version") or 0)
    worker_builder = int(state.get("worker_catalog_builder_version") or 0)
    return (
        state.get("worker_plugin_version") == state.get("target_plugin_version")
        and worker_builder >= target_builder
    )


def assert_preparation_worker_current(catalog_instance_id):
    state = preparation_state(catalog_instance_id)
    if not state or not state.get("target_plugin_version"):
        return
    expected_plugin = str(state["target_plugin_version"])
    expected_builder = int(state.get("target_catalog_builder_version") or 0)
    if PLUGIN_VERSION != expected_plugin or CATALOG_BUILDER_VERSION < expected_builder:
        raise RuntimeError(
            "AudioMuse queued catalogue preparation for Lumae Analysis "
            f"{expected_plugin} (builder {expected_builder}), but this worker is still "
            f"running {PLUGIN_VERSION} (builder {CATALOG_BUILDER_VERSION}). "
            "Restart the AudioMuse workers; the repair watchdog will retry automatically."
        )


def preparation_is_active(state, now=None):
    if not state or state.get("status") not in ("queued", "running"):
        return False
    try:
        updated_at = datetime.fromisoformat(str(state["updated_at"]).replace("Z", "+00:00"))
        current = now or datetime.now(timezone.utc)
        if updated_at.tzinfo is None:
            updated_at = updated_at.replace(tzinfo=timezone.utc)
        return (current - updated_at).total_seconds() < PREPARATION_STALE_HOURS * 3600
    except (KeyError, TypeError, ValueError):
        return True


def claim_preparation(source, db=None):
    """Atomically admit one preparation run for an exact catalogue source."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {preparation_state_table()}
            (catalog_instance_id, server_id, status, phase, queued_profiles,
             profile_jobs, target_plugin_version, target_catalog_builder_version,
             worker_plugin_version, worker_catalog_builder_version,
             last_error, started_at, completed_at, updated_at)
        VALUES (%s, %s, 'queued', 'queued', 0, 0, %s, %s, NULL, NULL,
                NULL, now(), NULL, now())
        ON CONFLICT (catalog_instance_id) DO UPDATE SET
            server_id=EXCLUDED.server_id,
            status='queued', phase='queued', queued_profiles=0, profile_jobs=0,
            target_plugin_version=EXCLUDED.target_plugin_version,
            target_catalog_builder_version=EXCLUDED.target_catalog_builder_version,
            worker_plugin_version=NULL, worker_catalog_builder_version=NULL,
            last_error=NULL, started_at=now(), completed_at=NULL,
            retry_count=0, next_retry_at=NULL, updated_at=now()
        WHERE {preparation_state_table()}.status NOT IN ('queued', 'running')
           OR {preparation_state_table()}.updated_at < now() - interval '{PREPARATION_STALE_HOURS} hours'
        RETURNING catalog_instance_id
        """,
        (
            source["catalog_instance_id"],
            source["server_id"],
            PLUGIN_VERSION,
            CATALOG_BUILDER_VERSION,
        ),
    )
    claimed = cur.fetchone() is not None
    if claimed:
        arm_reconcile(db, "catalog_preparation_admitted")
    db.commit()
    cur.close()
    return claimed


def claim_preparation_run(catalog_instance_id, db=None):
    """Claim one queued or interrupted catalogue preparation."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        UPDATE {preparation_state_table()}
           SET status='running', phase='starting', last_error=NULL,
               started_at=COALESCE(started_at, now()), next_retry_at=NULL, updated_at=now()
         WHERE catalog_instance_id=%s
           AND (status='queued'
                OR (status='failed' AND (next_retry_at IS NULL OR next_retry_at <= now()))
                OR (status='running' AND updated_at
                    < now() - interval '{PREPARATION_STALE_HOURS} hours'))
        RETURNING catalog_instance_id
        """,
        (catalog_instance_id,),
    )
    claimed = cur.fetchone() is not None
    db.commit()
    cur.close()
    return claimed


def recover_stale_pending_profiles(catalog_instance_id, db=None):
    """Release claims older than PREPARATION_STALE_HOURS as a used attempt,
    locking the rows in track-ID order (as admission and release do)."""
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        WITH recovered AS MATERIALIZED (
            SELECT track_id FROM {source_profiles_table()}
             WHERE catalog_instance_id=%(source)s
               AND status IN ('pending', 'pending_interactive')
               AND analyzed_at < now() - interval '{PREPARATION_STALE_HOURS} hours'
             ORDER BY track_id COLLATE "C"
               FOR UPDATE
        ), updated AS (
            UPDATE {source_profiles_table()} p
               SET status='stale', last_error='queue_unavailable',
                   attempt_token=NULL, retry_category='queue_unavailable',
                   retry_count=p.retry_count+1,
                   retry_after=CASE WHEN p.retry_count+1 < %(retry_limit)s
                       THEN now() + {retry_delay_sql('p.retry_count')} ELSE NULL END,
                   retry_media_signature=p.attempt_media_signature,
                   retry_analyzer_ver=p.attempt_analyzer_ver,
                   retry_profile_schema_ver=p.attempt_profile_schema_ver
              FROM recovered
             WHERE p.catalog_instance_id=%(source)s AND p.track_id=recovered.track_id
         RETURNING 1
        )
        SELECT count(*) FROM updated
        """,
        {**scheduler_params(ANALYZER_VERSION, SCHEMA_VERSION),
         "source": catalog_instance_id},
    )
    row = cur.fetchone()
    recovered = max(0, int(row[0] if row else 0))
    db.commit()
    cur.close()
    return recovered


def update_preparation_state(
    catalog_instance_id,
    server_id,
    status,
    phase,
    queued_profiles=0,
    profile_jobs=0,
    last_error=None,
    completed=False,
    db=None,
):
    db = db or get_db()
    cur = db.cursor()
    cur.execute(
        f"""
        INSERT INTO {preparation_state_table()}
            (catalog_instance_id, server_id, status, phase, queued_profiles,
             profile_jobs, target_plugin_version, target_catalog_builder_version,
             worker_plugin_version, worker_catalog_builder_version,
             last_error, started_at, completed_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now(),
                CASE WHEN %s THEN now() ELSE NULL END, now())
        ON CONFLICT (catalog_instance_id) DO UPDATE SET
            server_id=EXCLUDED.server_id,
            status=EXCLUDED.status,
            phase=EXCLUDED.phase,
            queued_profiles=EXCLUDED.queued_profiles,
            profile_jobs=EXCLUDED.profile_jobs,
            target_plugin_version=COALESCE(
                {preparation_state_table()}.target_plugin_version,
                EXCLUDED.target_plugin_version
            ),
            target_catalog_builder_version=COALESCE(
                {preparation_state_table()}.target_catalog_builder_version,
                EXCLUDED.target_catalog_builder_version
            ),
            worker_plugin_version=EXCLUDED.worker_plugin_version,
            worker_catalog_builder_version=EXCLUDED.worker_catalog_builder_version,
            last_error=EXCLUDED.last_error,
            completed_at=EXCLUDED.completed_at,
            updated_at=now()
        """,
        (
            catalog_instance_id,
            server_id,
            status,
            phase,
            int(queued_profiles or 0),
            int(profile_jobs or 0),
            PLUGIN_VERSION,
            CATALOG_BUILDER_VERSION,
            PLUGIN_VERSION,
            CATALOG_BUILDER_VERSION,
            str(last_error)[:2000] if last_error else None,
            bool(completed),
        ),
    )
    db.commit()
    cur.close()


def finalize_preparation_if_settled(catalog_instance_id):
    state = preparation_state(catalog_instance_id)
    if not state or state["status"] not in ("running", "profiles_queued"):
        return state
    counts = analysis_status_counts(
        catalog_instance_id=catalog_instance_id,
        server_id=state["server_id"],
    )
    if counts["pending"] > 0:
        return state
    ready = (
        counts["needs_analysis"] == 0
        and counts["failed"] == 0
        and counts["skipped"] == 0
    )
    update_preparation_state(
        catalog_instance_id,
        state["server_id"],
        "ready" if ready else "needs_attention",
        "complete" if ready else "profiles_need_attention",
        queued_profiles=state["queued_profiles"],
        profile_jobs=state["profile_jobs"],
        last_error=None if ready else "One or more profiles could not be prepared.",
        completed=True,
    )
    return preparation_state(catalog_instance_id)


def prepare_lumae_task(server_id=None, catalog_instance_id=None):
    """Publish the app-ready catalogue first, then start optional enrichment."""
    if maintenance_paused():
        return {"status": "paused", "reason": "maintenance_paused"}
    resolved_server_id = server_id
    resolved_catalog_instance_id = catalog_instance_id
    try:
        resolved_server_id = resolved_server_id or get_core_adapter().active_server_id()
        source = resolve_profile_source(
            catalog_instance_id=resolved_catalog_instance_id,
            server_id=resolved_server_id,
        )
        resolved_catalog_instance_id = source["catalog_instance_id"]
        resolved_server_id = source["server_id"]
        if not claim_preparation_run(resolved_catalog_instance_id):
            return {
                "status": "coalesced",
                "reason": "already_running_or_not_requested",
                "catalog_instance_id": resolved_catalog_instance_id,
            }
        assert_preparation_worker_current(resolved_catalog_instance_id)
        _safe_progress("refreshing catalogue")
        update_preparation_state(
            resolved_catalog_instance_id,
            resolved_server_id,
            "running",
            "catalog_refresh",
        )
        catalog_result = refresh_catalog(server_id=resolved_server_id)
        if catalog_result["catalog_instance_id"] != resolved_catalog_instance_id:
            raise CatalogScanError("Catalogue identity changed during preparation")
        if (
            int(catalog_result.get("builder_version") or 0) < CATALOG_BUILDER_VERSION
            or catalog_result.get("refresh_required") is not False
        ):
            raise CatalogScanError(
                "Catalogue refresh finished without publishing the current builder version"
            )
        _safe_progress("projecting AudioMuse analysis")
        update_preparation_state(
            resolved_catalog_instance_id,
            resolved_server_id,
            "running",
            "analysis_projection",
        )
        projection_result = project_analysis(
            server_id=resolved_server_id,
            adapter=get_core_adapter(),
        )
        if projection_result["catalog_instance_id"] != resolved_catalog_instance_id:
            raise CatalogScanError("Analysis identity changed during preparation")
        update_preparation_state(
            resolved_catalog_instance_id,
            resolved_server_id,
            "ready",
            "catalog_ready",
            completed=True,
        )
        try:
            _safe_progress("admitting volume and ramp work")
            profile_result = start_profile_backfill(
                catalog_instance_id=resolved_catalog_instance_id,
                server_id=resolved_server_id,
                enqueue_job=False,
            )
        except Exception as exc:
            # The catalogue is already safe and usable. Enrichment failures
            # remain visible in their own state and never roll readiness back.
            logger.exception("lumae_analysis could not start background profile enrichment")
            profile_result = {"queued": False, "coalesced": False, "error": str(exc)}
        try:
            _safe_progress("admitting relationship work")
            relationship_result = start_relationship_preparation(
                catalog_instance_id=resolved_catalog_instance_id,
                server_id=resolved_server_id,
                enqueue_job=False,
            )
        except Exception as exc:
            logger.exception(
                "lumae_analysis could not start background relationship enrichment"
            )
            relationship_result = {
                "queued": False,
                "coalesced": False,
                "error": str(exc),
            }
        return {
            "catalog": catalog_result,
            "analysis": projection_result,
            "profiles": profile_result,
            "relationships": relationship_result,
            "preparation": preparation_state(resolved_catalog_instance_id),
        }
    except Exception as exc:
        if resolved_catalog_instance_id and resolved_server_id:
            update_preparation_state(
                resolved_catalog_instance_id,
                resolved_server_id,
                "failed",
                "failed",
                last_error=exc,
                completed=True,
            )
        raise


_READINESS_BLOCKER_LABELS = {
    "analysis_links_missing": "Some eligible tracks do not have AudioMuse analysis yet.",
    "analysis_links_need_repair": "Some source-analysis links are flagged for automatic repair.",
    "analysis_links_pending": "Some eligible tracks are still awaiting AudioMuse analysis.",
    "analysis_mapping_incomplete": "Some eligible provider tracks do not have an AudioMuse mapping yet.",
    "analysis_projection_incomplete": "The plugin analysis projection is not complete.",
    "catalog_generation_incomplete": "The provider catalogue generation is not complete.",
    "chromaprint_backfill_incomplete": "Full-library verification is still waiting for Chromaprint; affected collision groups remain usable but provisional.",
    "chromaprint_collection_disabled": "Chromaprint collection is disabled in AudioMuse.",
    "chromaprint_gate_disabled": "Chromaprint duplicate validation is disabled in AudioMuse.",
    "duration_tolerance_too_wide": "The AudioMuse duplicate duration tolerance is wider than one second.",
    "folder_gate_not_active": "The fp_4 folder-aware duplicate rule is not active.",
    "fp_4_not_active": "AudioMuse catalogue ID scheme fp_4 is not active.",
    "no_analysis_mappings": "No provider tracks have AudioMuse analysis mappings yet.",
    "per_link_evidence_unavailable": "This plugin cannot qualify AudioMuse analysis links individually.",
    "provisional_links_remaining": "Some usable source-analysis links still have provisional evidence.",
    "readiness_unavailable": "The plugin could not read AudioMuse repair diagnostics.",
    "sonic_evidence_incomplete": "Full per-track sonic evidence is not complete yet.",
    "source_rebind_required": "Lumae still needs to verify the AudioMuse source identity during app sync.",
}


from .settings_render import (
    _v3_readiness_sources,
    _render_basic_source_analysis_panel,
    render_v3_readiness_panel,
    render_relationship_status_panel,
    _published_track_count,
    render_source_preparation_sections,
    render_source_preparation_panel,
    render_provider_identity_panel,
    _readiness_availability,
    _readiness_age_text,
    _readiness_job,
    _readiness_stream_status,
    render_readiness_streams_panel,
    _reconcile_duration,
    _reconcile_event_summary,
    render_reconcile_status_panel,
    render_settings_status_panels,
    render_publication_repair_form,
    render_settings,
    _READINESS_AVAILABILITY_LABEL,
    _READINESS_AVAILABILITY_CLASS,
    _READINESS_JOB_LABEL,
)


@bp.get("/settings/status")
def settings_status():
    return _private_json({"panels": render_settings_status_panels(configured_backfill_limit())})


@bp.route("/settings", methods=["GET", "POST"])
def settings():
    message = None
    error = None
    if request.method == "POST":
        try:
            action = request.form.get("action")
            if action in ("pause_maintenance", "resume_maintenance"):
                paused = action == "pause_maintenance"
                set_setting("maintenance_paused", paused)
                _safe_reconcile_schedule(get_db(), paused=paused)
                message = (
                    "Background maintenance paused. Published Lumae data remains available."
                    if paused
                    else "Background maintenance resumed."
                )
            elif action == "save_collections":
                enabled = request.form.get("collection_manager_enabled") == "on"
                set_setting("collection_manager_enabled", enabled)
                sync_collections_menu(enabled)
                message = f"Living Collections {'enabled' if enabled else 'disabled'}."
            elif action in ("ack_v3_readiness", "clear_v3_readiness"):
                message = (
                    "Manual AudioMuse verification is no longer required. "
                    "Lumae now verifies sonic readiness automatically from current evidence."
                )
            elif action in ("prepare_lumae", "start_backfill", "catch_up", "queue_all"):
                batch_size = normalize_backfill_limit(
                    request.form.get("backfill_batch_size") or DEFAULT_BACKFILL_BATCH_SIZE
                )
                set_setting("backfill_batch_size", batch_size)
                source = resolve_profile_source(
                    catalog_instance_id=request.form.get("catalog_instance_id"),
                    server_id=request.form.get("server_id"),
                )
                catalog_instance_id = source["catalog_instance_id"]
                server_id = source["server_id"]
                if action == "prepare_lumae":
                    if not claim_preparation(source):
                        message = f"Preparation is already running for {source['name']}."
                    else:
                        try:
                            enqueue_bounded(
                                prepare_lumae_task,
                                server_id,
                                catalog_instance_id,
                                queue="default",
                                timeout=CATALOG_JOB_TIMEOUT_SECONDS,
                            )
                        except Exception:
                            logger.exception(
                                "lumae_analysis could not queue catalogue preparation; "
                                "the durable watchdog will retry it"
                            )
                        message = (
                            f"Preparing {source['name']}: library refresh and app sync index first, "
                            "then fair background volume and ramp work. Lumae can sync as soon as "
                            "the first two phases complete."
                        )
                else:
                    # Legacy catch_up/queue_all form submissions from an open
                    # 0.8.0 page intentionally map to the bounded 0.8.1 chain.
                    result = start_profile_backfill(
                        catalog_instance_id=catalog_instance_id,
                        server_id=server_id,
                    )
                    message = (
                        f"Background enrichment is already running for {source['name']}."
                        if result["coalesced"]
                        else f"Started background enrichment for {source['name']} in batches of "
                        f"{result['batch_size']}. Playback requests are prioritized separately."
                    )
            elif action == "retry_edge_profiles":
                # LUM-017 (P3-9): edge profiles had no settings-page retry path;
                # this reuses the exact enqueue the app-facing backfill API
                # already uses (P3-7's ``edge_backfill_candidates`` /
                # ``enqueue_edge_profiles``), just bounded to one batch here.
                source = resolve_profile_source(
                    catalog_instance_id=request.form.get("catalog_instance_id"),
                    server_id=request.form.get("server_id"),
                )
                ids = edge_backfill_candidates(get_db(), source["catalog_instance_id"], "", 100)
                result = enqueue_edge_profiles(
                    ids, source["catalog_instance_id"], source["server_id"]
                )
                if not result.get("available"):
                    message = "Edge profile upgrades are currently disabled or paused."
                else:
                    message = (
                        f"Queued {format_count(len(result.get('accepted') or []))} edge "
                        f"profile(s) for {source['name']}; "
                        f"{format_count(len(result.get('already_ready') or []))} were already ready."
                    )
            elif action == "retry_relationships":
                # LUM-017 (P3-9): relationships had no settings-page retry
                # path; this wires the existing coalesced request the app API
                # already uses (``start_relationship_preparation``).
                source = resolve_profile_source(
                    catalog_instance_id=request.form.get("catalog_instance_id"),
                    server_id=request.form.get("server_id"),
                )
                result = start_relationship_preparation(
                    catalog_instance_id=source["catalog_instance_id"],
                    server_id=source["server_id"],
                )
                if result.get("coalesced"):
                    message = (
                        f"Relationships for {source['name']}: "
                        f"{(result.get('reason') or 'already up to date').replace('_', ' ')}."
                    )
                else:
                    message = f"Queued a relationship rebuild for {source['name']}."
            elif action == "repair_profile_publications":
                result = repair_profile_publications()
                message = (
                    f"Withdrew {format_count(result['withdrawn'])} published profiles of "
                    "tracks no longer in the catalogue and republished "
                    f"{format_count(result['republished'])} ready profiles. Left: "
                    f"{format_count(result['profiles_orphaned'] or 0)} orphaned and "
                    f"{format_count(result['profiles_unpublished_ready'] or 0)} unpublished "
                    "ready profiles; run the repair again while either is above 0."
                )
            elif action == "save":
                batch_size = normalize_backfill_limit(
                    request.form.get("backfill_batch_size") or DEFAULT_BACKFILL_BATCH_SIZE
                )
                set_setting("backfill_batch_size", batch_size)
                message = "Lumae analysis settings saved."
        except (KeyError, ValueError, CatalogScanError, RuntimeError) as exc:
            error = str(exc)

    return render_settings(message=message, error=error)


@bp.route("/database-state", methods=["GET"])
def database_state_page():
    compatibility = detect_core()
    db = get_db()
    try:
        sources = []
        if db is not None:
            # Every read of this page runs under the diagnostic statement
            # timeout, in a savepoint that is rolled back (P3-10).
            with bounded_reads(db):
                sources = resolve_catalog_source(db)
        readiness = None
        if db is not None and compatibility.adapter == "v3_registry":
            policy = dedup_policy()

            def v3_readiness(source):
                return v3_release_readiness(db, compatibility, source, policy)

            readiness = v3_readiness
        snapshot = collect_database_state(
            db,
            compatibility,
            sources,
            readiness=readiness,
        )
    except Exception as exc:
        logger.warning(
            "lumae_analysis could not collect database state (%s)", type(exc).__name__
        )
        snapshot = {
            "captured_at": utc_now_iso(),
            "status": "unavailable",
            "core": compatibility.as_dict(),
            "sources": [],
            "errors": [safe_snapshot_error(exc)],
        }
    return render_page(
        render_database_state(snapshot),
        title="Lumae Database State",
    )


def register(ctx):
    ctx.add_blueprint(bp)
    ctx.set_settings_page("lumae_analysis.settings")
    if collections_enabled():
        ctx.add_menu_item(COLLECTIONS_MENU_LABEL, COLLECTIONS_MENU_ENDPOINT)
    ctx.on_install(migrate)
    ctx.on_flask_start(observe_provider_identities_on_start)
    if hasattr(ctx, "on_worker_start"):
        ctx.on_worker_start(report_edge_runtime_on_start)
    ctx.on_song_analyzed(analyze_song_hook)
    ctx.add_task("prepare", prepare_lumae_task, queue="default")
    ctx.add_task("profile_backfill", profile_backfill_task, queue="default")
    ctx.add_task("edge_backfill", edge_backfill_task, queue="default")
    ctx.add_task("analysis_projection", analysis_projection_task, queue="default")
    ctx.add_task("credits", credits_service.run_one, queue="default")
    ctx.add_task(
        "relationship_preparation", relationship_preparation_task, queue="default"
    )
    ctx.add_cron_task("catalog_reconcile", catalog_reconcile_task, queue="default")
    ctx.add_task("provider_identity_recheck", provider_identity_recheck_task, queue="default")
    ctx.add_cron_task("catalog_refresh", catalog_refresh_task, queue="default")
    ctx.add_cron_task(
        "provider_identity_recheck", provider_identity_recheck_task, queue="default"
    )
    ctx.add_cron_task("analysis_projection", analysis_projection_task, queue="default")
    ctx.add_cron_task("collection_retention", collection_retention_task, queue="default")
